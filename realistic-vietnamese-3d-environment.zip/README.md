# Hẻm 12 – Khu dân cư Việt Nam 3D (React + Vite + three.js)

Thế giới 3D thời gian thực. Toàn bộ texture, vật liệu, hình học và âm thanh đều sinh bằng code; không dùng asset ngoài.

## Vòng nâng cấp chất lượng (hiện tại)
- **Vật liệu có roughness thật**: mỗi texture (vữa, gạch men, gạch bông, gạch đỏ, ngói âm dương, nhựa đường, bê tông ván khuôn, gỗ, tôn, vải, ốp đá, terrazzo) có kênh roughness riêng, lấy từ điều kiện bề mặt (ẩm, mốc, bong sơn, vệt bánh xe, dầu).
- **Vi biến thiên cho vật đơn sắc**: mọi bề mặt màu đặc (`g:`, `r:`, `m:`) có roughness và bump vi mô dùng chung, tránh vẻ nhựa đồng nhất.
- **Kính**: giảm phản chiếu môi trường để cửa kính không thành mảng trắng.
- **Hình học**: nhân vật có thân dạng viên nang, khớp khuỷu và gối, mắt mũi, dép/giày, nón lá, mũ bảo hiểm; xe máy có lốp, vành, gương, pô, đèn; hộp bo góc (`b.rb`) và geometry tùy ý (`b.geo`, `b.lathe`) cho các vật thể mới.
- **Kiến trúc**: mái hắt bê tông trên mọi ô cửa, gờ viền từng tầng, ốp đá chân tường nhà hiện đại, cây có thân thuôn, cành và tán lớn hơn.
- **Môi trường**: vũng nước phản chiếu trên đường và trong hẻm (đậm hơn khi mưa), ổ cắm trên tường, dép và mũ bảo hiểm ở lối vào.
- **Ánh sáng**: GTAO (occlusion môi trường từ depth và normal) ở chất lượng cao; bloom đã được hạ ngưỡng từ 1.0 xuống 2.2 để hết lớp sương trắng làm mờ nội thất.

## Cấu trúc mã
- `src/world/textures.ts`: sinh texture (albedo, bump, roughness) bằng canvas.
- `src/world/materials.ts`: vật liệu theo khóa (`px:`, `pi:`, `tile:`, `stone:`, `terr:`, `g:`, `r:`, `m:`, `puddle:`...), trạng thái ướt, đêm.
- `src/world/builder.ts`: gom hình học theo vật liệu; có `box`, `rb`, `lathe`, `geo`, `cyl`, `leaves`.
- `house.ts`, `facade.ts`, `rooms.ts`: nhà ống, nhà cấp 4, nhà kiểu Pháp; cầu thang, giếng trời, WC, bếp, tum, ban công.
- `devices.ts`: cửa, cửa cuốn, công tắc, quạt, tivi, vòi nước, vòi sen, bếp ga, nồi cơm, tủ lạnh, điều hòa, máy giặt, radio, nhang.
- `furniture.ts`: nội thất, xe máy (`motorbike`).
- `people.ts`: cư dân theo lịch sinh hoạt, người đi bộ, người đi xe máy, người bán hàng.
- `neighborhood.ts`: đường, hẻm, sân chung, dây điện, cây, biển hiệu, xe đẩy.
- `sky.ts`, `audio.ts`, `engine.ts`, `player.ts`: chu kỳ ngày đêm, mưa, âm thanh tổng hợp, camera và va chạm, vòng lặp hiển thị.

## Điều khiển
WASD để đi, Shift để chạy, C để cúi; chuột để nhìn (kéo chuột nếu không khóa được con trỏ). E hoặc click để tương tác. T dừng hoặc chạy giờ, R bật mưa, G tham quan tự động, M tắt tiếng.

## Đã biết (chưa xử lý)
- Điểm xuất hiện ở phòng khách (góc nhìn 15:00) vẫn có một mảng sáng và vật cận sát camera; cần kiểm tra thêm vị trí va chạm quanh cửa chính.
- Khi đứng trong bếp, điểm dịch chuyển đến gần bàn bếp có thể rơi vào khối đặc; cần kiểm tra lại offset.
- Chưa đo hiệu năng trên GPU thật; số lượng nhân vật và mesh tăng đáng kể so với vòng trước.

## Ảnh kiểm chứng (`evidence/`)
- `upgrade_street_bikes_people.png`: đường phố với xe máy mới và nhân vật có khớp.
- `upgrade_alley_people.png`: hẻm với người đi bộ và xe máy.
- `bloom_off_test_interior.png`: nội thất khi tắt bloom, xác nhận nguyên nhân sương trắng.
- `after_bloom_interior_dusk.png`: nội thất sau khi hạ ngưỡng bloom.
- `after_bloom_street_day.png`: cảnh phố ban ngày sau khi chỉnh bloom.
