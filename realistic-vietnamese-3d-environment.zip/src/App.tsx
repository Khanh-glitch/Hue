import { useEffect, useRef, useState } from 'react';
import { Engine, type Hud } from './world/engine';

export default function App() {
  const mount = useRef<HTMLDivElement>(null);
  const eng = useRef<Engine | null>(null);
  const [hud, setHud] = useState<Hud | null>(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');

  useEffect(() => {
    if (!mount.current) return;
    let e: Engine | null = null;
    const id = setTimeout(() => {
      try {
        e = new Engine(mount.current!, setHud);
        eng.current = e; (window as any).__engine = e; setLoading(false);
      } catch (ex) { console.error(ex); setErr(String(ex)); setLoading(false); }
    }, 60);
    return () => { clearTimeout(id); e?.dispose(); };
  }, []);

  const started = hud?.started;
  const E = () => eng.current!;
  const btn = 'px-2.5 py-1 rounded-md text-xs font-medium bg-black/45 hover:bg-white/25 text-white border border-white/15 backdrop-blur transition';
  const places: [string, string][] = [['street', 'Đường'], ['alley', 'Hẻm'], ['court', 'Sân cuối hẻm'], ['living', 'Phòng khách'], ['kitchen', 'Bếp'], ['bedroom', 'Phòng ngủ'], ['roof', 'Sân thượng'], ['grocery', 'Tạp hóa'], ['cafe', 'Cà phê'], ['pho', 'Quán phở'], ['cap4', 'Nhà cấp 4']];
  const times: [number, string][] = [[5.6, 'Bình minh'], [8, 'Sáng'], [12.3, 'Trưa'], [17.2, 'Chiều'], [18.6, 'Hoàng hôn'], [21, 'Tối'], [23.8, 'Khuya']];

  return (
    <div className="fixed inset-0 bg-black overflow-hidden select-none" style={{ fontFamily: 'system-ui, "Segoe UI", Roboto, sans-serif' }}>
      <div ref={mount} className="absolute inset-0" />
      {loading && <div className="absolute inset-0 grid place-items-center bg-[#0d1117] text-amber-100"><div className="text-center"><div className="text-2xl font-light tracking-widest mb-3">ĐANG DỰNG KHU PHỐ…</div><div className="text-sm opacity-60">tạo vật liệu · dựng nhà · giăng dây điện</div></div></div>}
      {err && <div className="absolute inset-0 grid place-items-center text-red-300 p-8 text-center bg-black">{err}</div>}
      {!loading && !started && (
        <div className="absolute inset-0 grid place-items-center bg-gradient-to-b from-black/45 via-black/25 to-black/70">
          <div className="max-w-2xl text-center px-6 text-white">
            <div className="text-[11px] tracking-[0.45em] text-amber-200/80 mb-3">KHU DÂN CƯ VIỆT NAM · 3D THỜI GIAN THỰC</div>
            <h1 className="text-4xl md:text-6xl font-semibold leading-tight mb-4" style={{ textShadow: '0 2px 24px rgba(0,0,0,.6)' }}>Hẻm 12, đường Hoa Phượng</h1>
            <p className="text-sm md:text-base text-white/80 mb-6 leading-relaxed">Bước vào một khu phố có thật: nhà ống nhiều tầng, giếng trời, tum sân thượng, quán xá, dây điện chằng chịt và một con hẻm bê tông dẫn tới sân đa. Mở cửa, bật đèn, xả nước, nấu cơm, xem tivi, lên cầu thang chữ U ra sân thượng.</p>
            <div className="flex flex-wrap gap-3 justify-center mb-6">
              <button className="px-7 py-3 rounded-full bg-amber-400 text-black font-semibold hover:bg-amber-300 transition shadow-lg" onClick={() => E().begin(true)}>Bước vào khu phố</button>
              <button className="px-7 py-3 rounded-full bg-white/15 border border-white/30 hover:bg-white/25 transition" onClick={() => { E().begin(false); E().startTour(); }}>Tham quan tự động ngôi nhà</button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs text-white/70">
              <div className="bg-black/35 rounded-lg p-2"><b className="text-white">WASD</b> di chuyển · <b className="text-white">Shift</b> chạy</div>
              <div className="bg-black/35 rounded-lg p-2"><b className="text-white">Chuột</b> nhìn · kéo chuột nếu không khóa</div>
              <div className="bg-black/35 rounded-lg p-2"><b className="text-white">E / Click</b> tương tác</div>
              <div className="bg-black/35 rounded-lg p-2"><b className="text-white">T</b> dừng giờ · <b className="text-white">R</b> mưa · <b className="text-white">G</b> tham quan</div>
            </div>
          </div>
        </div>
      )}
      {started && hud && (
        <>
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
            <div className={`rounded-full transition-all ${hud.prompt ? 'w-3 h-3 bg-amber-300/90 ring-2 ring-white/60' : 'w-1.5 h-1.5 bg-white/70'}`} />
          </div>
          {hud.prompt && <div className="absolute left-1/2 top-[56%] -translate-x-1/2 px-4 py-1.5 rounded-full bg-black/60 text-white text-sm backdrop-blur border border-white/20 pointer-events-none"><span className="inline-block mr-2 px-1.5 rounded bg-white/90 text-black text-xs font-bold">E</span>{hud.prompt}</div>}
          <div className="absolute left-3 top-3 text-white pointer-events-none">
            <div className="text-xl font-semibold tabular-nums" style={{ textShadow: '0 1px 8px #000' }}>{hud.time}</div>
            <div className="text-xs opacity-80" style={{ textShadow: '0 1px 6px #000' }}>{hud.weather} · {hud.loc}</div>
            {hud.tour && <div className="mt-1 text-[11px] text-amber-200">Đang tham quan tự động — nhấn WASD để tự đi</div>}
          </div>
          <div className="absolute right-3 top-3 text-[11px] text-white/60 pointer-events-none">{hud.fps} fps</div>
          <div className="absolute left-0 right-0 bottom-3 flex flex-col items-center gap-2 px-2">
            <div className="flex flex-wrap justify-center gap-1.5">
              {times.map(([h, l]) => <button key={l} className={btn} onClick={() => E().setTime(h)}>{l}</button>)}
              <button className={btn} onClick={() => E().setRain(hud.rain > 0.3 ? 0 : 1)}>{hud.rain > 0.3 ? '☀ Tạnh mưa' : '🌧 Mưa'}</button>
              <button className={btn} onClick={() => E().setTimeScale(hud.timeScale > 0 ? 0 : 60)}>{hud.timeScale > 0 ? '⏸ Dừng giờ' : '▶ Chạy giờ'}</button>
              <button className={btn} onClick={() => E().toggleMute()}>{hud.muted ? '🔇' : '🔊'}</button>
              <button className={btn} onClick={() => E().applyQuality(hud.quality === 'high' ? 'med' : hud.quality === 'med' ? 'low' : 'high')}>Đồ họa: {hud.quality}</button>
              <button className={btn} onClick={() => E().startTour()}>Tham quan nhà</button>
            </div>
            <div className="flex flex-wrap justify-center gap-1.5">
              {places.map(([k, l]) => <button key={k} className={btn + ' !bg-amber-900/50'} onClick={() => E().teleport(k)}>{l}</button>)}
            </div>
          </div>
          <Joystick onMove={(x, y) => E().setMove(x, y)} />
        </>
      )}
    </div>
  );
}

function Joystick({ onMove }: { onMove: (x: number, y: number) => void }) {
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const base = useRef<HTMLDivElement>(null);
  const handle = (e: React.PointerEvent) => {
    const r = base.current!.getBoundingClientRect();
    let x = (e.clientX - r.left - r.width / 2) / (r.width / 2), y = (e.clientY - r.top - r.height / 2) / (r.height / 2);
    const l = Math.hypot(x, y); if (l > 1) { x /= l; y /= l; }
    setKnob({ x, y }); onMove(x, y);
  };
  return (
    <div ref={base} className="absolute left-5 bottom-28 w-24 h-24 rounded-full bg-white/10 border border-white/25 touch-none md:hidden"
      onPointerDown={(e) => { (e.target as HTMLElement).setPointerCapture(e.pointerId); handle(e); }} onPointerMove={(e) => e.buttons && handle(e)} onPointerUp={() => { setKnob({ x: 0, y: 0 }); onMove(0, 0); }}>
      <div className="absolute w-10 h-10 rounded-full bg-white/50" style={{ left: 28 + knob.x * 28, top: 28 + knob.y * 28 }} />
    </div>
  );
}
