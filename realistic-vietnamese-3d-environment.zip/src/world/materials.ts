import * as THREE from 'three';
import * as T from './textures';

const cache = new Map<string, THREE.Material>();
const texCache = new Map<string, T.TexSet>();
export const windUniform = { value: 0 };
const wettable: { m: THREE.MeshStandardMaterial; col: THREE.Color }[] = [];
const puddles: THREE.MeshStandardMaterial[] = [];
const emitters: { m: THREE.MeshStandardMaterial; base: number }[] = [];
let _ao: THREE.CanvasTexture | null = null, _ct: THREE.CanvasTexture | null = null;

function tex(name: string, f: () => T.TexSet): T.TexSet {
  let t = texCache.get(name);
  if (!t) { t = f(); texCache.set(name, t); }
  return t;
}
const microSet = () => tex('micro', () => T.microTex());

/** textured PBR surface. When the texture carries its own roughness map, roughness is absolute (scalar 1 × map). */
function std(ts: T.TexSet | null, color: string, rough: number, metal = 0, bump = 1.5, extra: THREE.MeshStandardMaterialParameters = {}) {
  const hasR = !!ts?.rough;
  return new THREE.MeshStandardMaterial({ map: ts?.map, bumpMap: ts?.bump, bumpScale: bump, roughnessMap: ts?.rough, roughness: hasR ? 1 : rough, color: new THREE.Color(color), metalness: metal, ...extra });
}
function sway(m: THREE.Material, cloth: boolean) {
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = windUniform;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nuniform float uTime;')
      .replace('#include <begin_vertex>', `#include <begin_vertex>
        vec4 wp_ = modelMatrix * vec4(position,1.0);
        float s_ = sin(uTime*1.6 + wp_.x*0.8 + wp_.z*0.6)*0.5 + sin(uTime*3.3 + wp_.y*1.7 + wp_.x*1.3)*0.25;
        float a_ = ${cloth ? '(1.0-uv.y)*0.16' : '0.045'};
        transformed.x += s_*a_; transformed.z += s_*a_*0.7;`);
  };
}

export function mat(key: string): THREE.Material {
  let m = cache.get(key);
  if (m) return m;
  const i = key.indexOf(':');
  const kind = i < 0 ? key : key.slice(0, i), arg = i < 0 ? '' : key.slice(i + 1);
  switch (kind) {
    case 'px': m = std(tex('plx', () => T.plasterTex(true, 1)), arg, 1, 0, 2.2); break;
    case 'pi': m = std(tex('pli', () => T.plasterTex(false, 4)), arg, 1, 0, 1.4); break;
    case 'tile': m = std(tex('tile', () => T.tilesTex(2, 1.2, { grout: 5, vary: 0.05, veins: 0.12, dirt: 0.12, seed: 3 })), arg, 1, 0, 1.2); break;
    case 'tileW': m = std(tex('tileW', () => T.tilesTex(4, 1.2, { grout: 4, vary: 0.04, dirt: 0.06, seed: 6 })), arg, 1, 0, 1.2); break;
    case 'mosaic': m = std(tex('mosaic', () => T.tilesTex(16, 0.8, { grout: 2, vary: 0.12, dirt: 0.14, seed: 9 })), arg, 1, 0, 1.2); break;
    case 'paver': m = std(tex('paver', () => T.tilesTex(4, 1.6, { grout: 6, vary: 0.16, dirt: 0.28, groutL: 0.35, seed: 11, res: 512, gloss: 0.6 })), arg, 1, 0, 2.5); break;
    case 'terr': m = std(tex('terr', () => T.terrazzoTex()), arg, 1, 0, 1.0); break;
    case 'stone': m = std(tex('stone', () => T.stoneTex()), arg, 1, 0, 2.2); break;
    case 'gb': m = std(tex('gb', () => T.gachBongTex()), '#ffffff', 1, 0, 1.0); break;
    case 'brick': m = std(tex('brick', () => T.brickTex()), arg || '#ffffff', 1, 0, 3); break;
    case 'conc': m = std(tex('conc', () => T.concreteTex()), arg || '#ffffff', 1, 0, 2); break;
    case 'roof': m = std(tex('roof', () => T.roofTileTex()), '#ffffff', 1, 0, 3.5, { side: THREE.DoubleSide }); break;
    case 'asph': m = std(tex('asph', () => T.asphaltTex()), '#ffffff', 1, 0, 2); break;
    case 'wood': m = std(tex('wood6', () => T.woodTex(6)), arg, 1, 0, 1.2); break;
    case 'woodF': m = std(tex('wood2', () => T.woodTex(2, 5)), arg, 1, 0, 1.0); break;
    case 'woodP': m = std(tex('wood1', () => T.woodTex(1, 7)), arg, 1, 0, 0.8); break;
    case 'tole': m = std(tex('tole', () => T.corrugatedTex()), arg, 1, 0.45, 3); break;
    case 'shut': m = std(tex('shut', () => T.shutterTex()), arg, 1, 0.5, 2.5); break;
    case 'cloth': m = std(tex('fab', () => T.fabricTex()), arg, 1, 0, 1); break;
    case 'metal': m = std(tex('brush', () => T.brushedTex()), arg, 1, 0.85, 0.5); break;
    case 'leaf': m = new THREE.MeshStandardMaterial({ map: T.leafCardTex(arg as 'green', arg.length), alphaTest: 0.45, side: THREE.DoubleSide, roughness: 0.75, color: '#e8ffe0' }); sway(m, false); break;
    case 'laundry': m = new THREE.MeshStandardMaterial({ color: arg, roughness: 0.95, side: THREE.DoubleSide }); sway(m, true); break;
    // glass: thin, slightly green, modest reflection (mirror-like panes washed out interiors at dusk)
    case 'glass': m = new THREE.MeshStandardMaterial({ color: '#d6ebf2', transparent: true, opacity: 0.16, roughness: 0.05, metalness: 0, envMapIntensity: 0.6, depthWrite: false }); break;
    case 'ao': m = new THREE.MeshBasicMaterial({ map: (_ao ??= T.aoStripTex()), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 }); break;
    case 'contact': m = new THREE.MeshBasicMaterial({ map: (_ct ??= T.contactTex()), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 }); break;
    case 'emit': { const e = new THREE.MeshStandardMaterial({ color: '#222', emissive: arg, emissiveIntensity: 1.6, roughness: 0.5 }); emitters.push({ m: e, base: 1.6 }); m = e; break; }
    case 'puddle': { const p = new THREE.MeshStandardMaterial({ color: '#1a2024', roughness: 0.03, metalness: 0, transparent: true, opacity: 0.25, depthWrite: false, envMapIntensity: 2.2 }); puddles.push(p); m = p; break; }
    case 'flag': {
      const c = document.createElement('canvas'); c.width = 192; c.height = 128; const x = c.getContext('2d')!;
      x.fillStyle = '#da251d'; x.fillRect(0, 0, 192, 128); x.fillStyle = '#ffff00'; x.beginPath();
      for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, r = k % 2 ? 15 : 38; x.lineTo(96 + Math.cos(a) * r, 64 + Math.sin(a) * r); }
      x.fill(); const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace;
      m = new THREE.MeshStandardMaterial({ map: tx, side: THREE.DoubleSide, roughness: 0.9 }); sway(m, true); break;
    }
    // solid colour surfaces get shared micro-roughness + fine bump so no plane reads as perfectly uniform CG
    case 'g': case 'r': case 'rubber': case 'ceramic': case 'm': case 'mr': {
      const ms = microSet();
      const rough = kind === 'g' ? 0.3 : kind === 'r' ? 0.92 : kind === 'rubber' ? 0.9 : kind === 'ceramic' ? 0.14 : kind === 'm' ? 0.35 : 0.6;
      const metal = kind === 'm' ? 0.85 : kind === 'mr' ? 0.6 : 0;
      m = new THREE.MeshStandardMaterial({ color: arg, roughness: rough, roughnessMap: ms.rough, metalness: metal, bumpMap: ms.bump, bumpScale: kind === 'ceramic' ? 0.05 : 0.25 });
      break;
    }
    default: m = new THREE.MeshStandardMaterial({ color: key, roughness: 0.65 });
  }
  if (['asph', 'paver', 'conc', 'stone', 'terr', 'tile', 'tileW', 'mosaic'].includes(kind)) {
    const s = m as THREE.MeshStandardMaterial; wettable.push({ m: s, col: s.color.clone() });
  }
  cache.set(key, m);
  return m;
}

/** rain: roughness collapses, colours darken, puddles fill */
export function setWet(w: number) {
  for (const o of wettable) {
    o.m.roughness = 1 - 0.72 * w;
    o.m.color.copy(o.col).multiplyScalar(1 - 0.35 * w);
    o.m.envMapIntensity = 0.55 + 1.2 * w;
  }
  for (const p of puddles) p.opacity = 0.18 + 0.5 * w;
}
export function setNightEmit(n: number) { for (const e of emitters) e.m.emissiveIntensity = e.base * n; }
export function setAnisotropy(a: number) { T.texCfg.aniso = a; }
export const solid = (hex: string, rough = 0.6, metal = 0) => new THREE.MeshStandardMaterial({ color: hex, roughness: rough, metalness: metal });
