import { useEffect, useRef, useState } from 'react';
import { HueWorldEngine, MovementMode } from './engine/HueWorldEngine';
import { AtmosphereId, LandmarkDef } from './world/hueWorldConfig';
import { HueHUD } from './components/HueHUD';

export function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<HueWorldEngine | null>(null);

  const [showIntro, setShowIntro] = useState(true);
  const [activeZone, setActiveZone] = useState<LandmarkDef | null>(null);
  const [selectedLandmarkId, setSelectedLandmarkId] = useState<string>('thien-mu');
  const [atmosphere, setAtmosphere] = useState<AtmosphereId>('morning');
  const [mode, setMode] = useState<MovementMode>('walk');
  const [muted, setMuted] = useState(true);
  const [nearBell, setNearBell] = useState(false);
  const [bellToast, setBellToast] = useState(false);
  const [cinemaMode, setCinemaMode] = useState(false);
  const bellTimerRef = useRef<number | null>(null);

  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;

    const engine = new HueWorldEngine(el, {
      onZoneChange: (lm) => setActiveZone(lm),
      onBellNear: (near) => setNearBell(near),
      onModeChange: (nextMode) => setMode(nextMode),
      onBellRung: () => {
        setBellToast(true);
        setMuted(engine.isMuted());
        if (bellTimerRef.current) window.clearTimeout(bellTimerRef.current);
        bellTimerRef.current = window.setTimeout(() => setBellToast(false), 4200);
      },
    });
    engineRef.current = engine;

    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.code === 'KeyH') {
        setCinemaMode((v) => !v);
      }
    };
    window.addEventListener('keydown', onKey);

    return () => {
      window.removeEventListener('keydown', onKey);
      if (bellTimerRef.current) window.clearTimeout(bellTimerRef.current);
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  const handleStartExplore = () => {
    setShowIntro(false);
    engineRef.current?.beginExploration();
  };

  const handleSelectLandmark = (id: string) => {
    setSelectedLandmarkId(id);
    setShowIntro(false);
    engineRef.current?.flyToLandmark(id);
  };

  const handleSelectAtmosphere = (id: AtmosphereId) => {
    setAtmosphere(id);
    engineRef.current?.setAtmosphere(id);
  };

  const handleSelectMode = (nextMode: MovementMode) => {
    setMode(nextMode);
    engineRef.current?.setMode(nextMode);
  };

  const handleToggleMute = () => {
    if (!engineRef.current) return;
    const isNowMuted = engineRef.current.toggleMute();
    setMuted(isNowMuted);
  };

  const handleRingBell = () => {
    engineRef.current?.ringTempleBell();
  };

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#0e1116]">
      <div ref={mountRef} className="h-full w-full cursor-grab active:cursor-grabbing" />
      <HueHUD
        showIntro={showIntro}
        onStartExplore={handleStartExplore}
        activeZone={activeZone}
        selectedLandmarkId={selectedLandmarkId}
        onSelectLandmark={handleSelectLandmark}
        atmosphere={atmosphere}
        onSelectAtmosphere={handleSelectAtmosphere}
        mode={mode}
        onSelectMode={handleSelectMode}
        muted={muted}
        onToggleMute={handleToggleMute}
        nearBell={nearBell}
        bellToast={bellToast}
        onRingBell={handleRingBell}
        cinemaMode={cinemaMode}
        onToggleCinema={() => setCinemaMode((v) => !v)}
      />
    </div>
  );
}

export default App;
