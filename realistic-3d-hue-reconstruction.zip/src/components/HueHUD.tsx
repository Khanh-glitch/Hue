import React, { useState } from 'react';
import {
  Bell,
  BookOpen,
  Compass,
  Eye,
  EyeOff,
  Footprints,
  Navigation,
  Ship,
  Sparkles,
  Sun,
  Volume2,
  VolumeX,
  Wind,
  X,
} from 'lucide-react';
import {
  ATMOSPHERE_PRESETS,
  AtmosphereId,
  HUE_LANDMARKS,
  LandmarkDef,
} from '../world/hueWorldConfig';
import { MovementMode } from '../engine/HueWorldEngine';

interface HueHUDProps {
  showIntro: boolean;
  onStartExplore: () => void;
  activeZone: LandmarkDef | null;
  selectedLandmarkId: string;
  onSelectLandmark: (id: string) => void;
  atmosphere: AtmosphereId;
  onSelectAtmosphere: (id: AtmosphereId) => void;
  mode: MovementMode;
  onSelectMode: (mode: MovementMode) => void;
  muted: boolean;
  onToggleMute: () => void;
  nearBell: boolean;
  bellToast: boolean;
  onRingBell: () => void;
  cinemaMode: boolean;
  onToggleCinema: () => void;
}

const ATMOSPHERE_ORDER: AtmosphereId[] = [
  'dawn',
  'morning',
  'sunset',
  'night',
  'drizzle',
];

export const HueHUD: React.FC<HueHUDProps> = ({
  showIntro,
  onStartExplore,
  activeZone,
  selectedLandmarkId,
  onSelectLandmark,
  atmosphere,
  onSelectAtmosphere,
  mode,
  onSelectMode,
  muted,
  onToggleMute,
  nearBell,
  bellToast,
  onRingBell,
  cinemaMode,
  onToggleCinema,
}) => {
  const [showDossier, setShowDossier] = useState(false);

  const displayLandmark =
    activeZone ??
    HUE_LANDMARKS.find((l) => l.id === selectedLandmarkId) ??
    HUE_LANDMARKS[0];

  if (showIntro) {
    return (
      <div className="pointer-events-none fixed inset-0 z-20 flex flex-col items-center justify-between bg-gradient-to-b from-[#0b0e13]/70 via-transparent to-[#0b0e13]/82 p-6 text-center sm:p-8">
        <div className="mt-2 flex flex-col items-center gap-3">
          <div className="flex items-center gap-3 rounded-full border border-[#d6b372]/35 bg-[#12161e]/60 px-5 py-1.5 text-[11px] tracking-[0.22em] text-[#e8cf9b] uppercase backdrop-blur-md">
            <Sparkles className="h-3.5 w-3.5 text-[#d6b372]" />
            <span>Không Gian Di Sản Cố Đô (Ngoài Kinh Thành)</span>
          </div>
          <h1 className="font-heritage text-3xl font-semibold tracking-wide text-[#f8f2e7] drop-shadow-[0_4px_24px_rgba(0,0,0,0.75)] sm:text-5xl">
            Xứ Huế Giữa Đôi Bờ Hương Giang
          </h1>
        </div>

        <div className="pointer-events-auto flex flex-col items-center gap-4">
          <p className="mx-auto max-w-2xl rounded-2xl border border-white/10 bg-[#0d1117]/45 px-5 py-2.5 text-xs leading-relaxed text-[#ede6d8] backdrop-blur-sm sm:text-sm">
            Bước vào thế giới 3D liền mạch của Chùa Thiên Mụ, Lăng Khải Định với nội điện khảm sành sứ, Hồ Lưu Khiêm &amp; Xung Khiêm Tạ, Cầu Trường Tiền, Cầu Ngói Thanh Toàn và Đồi Vọng Cảnh.
          </p>

          <button
            onClick={onStartExplore}
            className="group inline-flex cursor-pointer items-center gap-3 rounded-full border border-[#e3c283]/60 bg-[#9b6a2f]/85 px-8 py-3.5 text-sm font-medium tracking-wider text-[#fff9ee] shadow-[0_10px_35px_rgba(0,0,0,0.55)] backdrop-blur-md transition hover:scale-[1.02] hover:bg-[#b57c37]"
          >
            <Compass className="h-4 w-4 transition-transform duration-500 group-hover:rotate-45" />
            <span>Bước Vào Không Gian Khám Phá</span>
          </button>

          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 rounded-2xl border border-white/10 bg-[#0d1117]/65 px-6 py-2.5 text-xs text-[#d6cec0] backdrop-blur-md">
          <span>
            <strong className="text-[#e8cf9b]">Kéo chuột</strong> để xoay góc nhìn
          </span>
          <span>
            <strong className="text-[#e8cf9b]">WASD / Mũi tên</strong> di chuyển
          </span>
          <span>
            <strong className="text-[#e8cf9b]">F</strong> đổi Đi Bộ / Bay Tự Do
          </span>
          <span>
            <strong className="text-[#e8cf9b]">G</strong> thỉnh Đại Hồng Chung
          </span>
          <span>
            <strong className="text-[#e8cf9b]">H</strong> ẩn giao diện
          </span>
          </div>
        </div>
      </div>
    );
  }

  if (cinemaMode) {
    return (
      <button
        onClick={onToggleCinema}
        title="Hiện giao diện (H)"
        className="fixed right-5 top-5 z-30 flex cursor-pointer items-center gap-2 rounded-full border border-white/15 bg-[#10141b]/65 px-3.5 py-2 text-xs text-[#f2eadc] backdrop-blur-md transition hover:bg-[#1a202c]/80"
      >
        <Eye className="h-3.5 w-3.5 text-[#d6b372]" />
        <span>Hiện giao diện</span>
      </button>
    );
  }

  return (
    <div className="pointer-events-none fixed inset-0 z-20 flex flex-col justify-between p-4 sm:p-5">
      {/* Top Row: Active Zone Plaque + Utility Buttons */}
      <div className="flex items-start justify-between gap-4">
        {/* Top-Left Heritage Plaque */}
        <div className="pointer-events-auto max-w-md">
          <div className="rounded-2xl border border-[#d6b372]/25 bg-[#10141c]/72 px-4 py-3 shadow-2xl backdrop-blur-md">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-[10px] tracking-[0.18em] text-[#d6b372] uppercase">
                <Navigation className="h-3 w-3" />
                <span>{activeZone ? 'Đang Khám Phá' : 'Di Tích Đã Chọn'}</span>
              </div>
              <button
                onClick={() => setShowDossier((v) => !v)}
                className="flex cursor-pointer items-center gap-1.5 rounded-full border border-[#d6b372]/30 bg-[#d6b372]/10 px-2.5 py-0.5 text-[11px] text-[#ecd5a7] transition hover:bg-[#d6b372]/25"
              >
                <BookOpen className="h-3 w-3" />
                <span>{showDossier ? 'Thu gọn' : 'Tư liệu'}</span>
              </button>
            </div>
            <h2 className="font-heritage mt-0.5 text-xl font-semibold text-[#faf3e8] sm:text-2xl">
              {displayLandmark.name}
            </h2>
            <p className="text-xs text-[#cbbda6]">{displayLandmark.subtitle}</p>

            {showDossier && (
              <div className="mt-3 space-y-2 border-t border-white/10 pt-2.5 text-xs leading-relaxed text-[#e6dfd2]">
                <div className="flex flex-wrap gap-2 text-[11px]">
                  <span className="rounded-md bg-white/8 px-2 py-0.5 text-[#e8cf9b]">
                    {displayLandmark.era}
                  </span>
                  <span className="rounded-md bg-white/8 px-2 py-0.5 text-[#b9d0c8]">
                    {displayLandmark.locationLabel}
                  </span>
                </div>
                <p>{displayLandmark.description}</p>
                <p className="rounded-lg border border-[#d6b372]/20 bg-[#1a1f29]/75 px-2.5 py-1.5 text-[11px] text-[#dfd1b8]">
                  <strong className="text-[#e8cf9b]">Vật liệu &amp; bề mặt:</strong>{' '}
                  {displayLandmark.materialsNote}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Top-Right Ambient Audio, Bell & Cinema Mode */}
        <div className="pointer-events-auto flex flex-wrap items-center justify-end gap-2">
          <button
            onClick={onRingBell}
            className={`flex cursor-pointer items-center gap-2 rounded-full border px-3.5 py-2 text-xs font-medium backdrop-blur-md transition ${
              nearBell
                ? 'border-[#e5c17b]/70 bg-[#8d5c24]/85 text-[#fff6e5] shadow-[0_0_24px_rgba(229,193,123,0.4)]'
                : 'border-white/15 bg-[#10141c]/70 text-[#e9e0d0] hover:bg-[#1b2230]/85'
            }`}
            title="Thỉnh Đại Hồng Chung Chùa Thiên Mụ (Phím G)"
          >
            <Bell className="h-3.5 w-3.5 text-[#e5c17b]" />
            <span className="hidden sm:inline">Thỉnh Đại Hồng Chung</span>
          </button>

          <button
            onClick={onToggleMute}
            className="flex cursor-pointer items-center gap-1.5 rounded-full border border-white/15 bg-[#10141c]/70 px-3 py-2 text-xs text-[#e9e0d0] backdrop-blur-md transition hover:bg-[#1b2230]/85"
            title={muted ? 'Bật âm thanh thiên nhiên Huế' : 'Tắt âm thanh'}
          >
            {muted ? (
              <VolumeX className="h-3.5 w-3.5 text-[#a7a095]" />
            ) : (
              <Volume2 className="h-3.5 w-3.5 text-[#8cc8b5]" />
            )}
            <span className="hidden md:inline">{muted ? 'Tắt tiếng' : 'Hương Giang'}</span>
          </button>

          <button
            onClick={onToggleCinema}
            className="flex cursor-pointer items-center gap-1.5 rounded-full border border-white/15 bg-[#10141c]/70 px-3 py-2 text-xs text-[#e9e0d0] backdrop-blur-md transition hover:bg-[#1b2230]/85"
            title="Ẩn giao diện ngắm cảnh (Phím H)"
          >
            <EyeOff className="h-3.5 w-3.5 text-[#d6b372]" />
          </button>
        </div>
      </div>

      {/* Subtle Bell Resonance Notification */}
      {bellToast && (
        <div className="pointer-events-none mx-auto rounded-full border border-[#e5c17b]/45 bg-[#161a22]/80 px-5 py-2 text-xs tracking-wide text-[#f7e7c5] shadow-lg backdrop-blur-md">
          Tiếng Đại Hồng Chung Thiên Mụ vang vọng đôi bờ Sông Hương…
        </div>
      )}

      {/* Bottom Compact Control Dock */}
      <div className="pointer-events-auto mx-auto flex w-full max-w-5xl flex-col gap-2">
        {/* Landmark Quick-Jump Ribbon */}
        <div className="hue-scroll flex items-center gap-1.5 overflow-x-auto rounded-2xl border border-white/12 bg-[#0f131b]/72 p-1.5 shadow-xl backdrop-blur-md">
          {HUE_LANDMARKS.map((lm) => {
            const isSelected =
              activeZone?.id === lm.id ||
              (!activeZone && selectedLandmarkId === lm.id);
            return (
              <button
                key={lm.id}
                onClick={() => onSelectLandmark(lm.id)}
                className={`shrink-0 cursor-pointer rounded-xl px-3 py-1.5 text-xs transition ${
                  isSelected
                    ? 'bg-[#b37e37]/90 font-medium text-[#fff8eb] shadow-md'
                    : 'text-[#ddd5c7] hover:bg-white/10'
                }`}
              >
                {lm.name.split(' (')[0].split(' & ')[0]}
              </button>
            );
          })}
        </div>

        {/* Movement Modes & Atmosphere Presets Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-white/12 bg-[#0f131b]/72 px-3 py-2 shadow-xl backdrop-blur-md">
          {/* Movement Modes */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => onSelectMode('walk')}
              className={`flex cursor-pointer items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs transition ${
                mode === 'walk'
                  ? 'bg-[#315d55] font-medium text-[#f1faf6]'
                  : 'text-[#d2cabd] hover:bg-white/10'
              }`}
            >
              <Footprints className="h-3.5 w-3.5" />
              <span>Đi Bộ</span>
            </button>
            <button
              onClick={() => onSelectMode('fly')}
              className={`flex cursor-pointer items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs transition ${
                mode === 'fly'
                  ? 'bg-[#315d55] font-medium text-[#f1faf6]'
                  : 'text-[#d2cabd] hover:bg-white/10'
              }`}
            >
              <Wind className="h-3.5 w-3.5" />
              <span>Bay Tự Do</span>
            </button>
            <button
              onClick={() => onSelectMode('boat')}
              className={`flex cursor-pointer items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs transition ${
                mode === 'boat'
                  ? 'bg-[#315d55] font-medium text-[#f1faf6]'
                  : 'text-[#d2cabd] hover:bg-white/10'
              }`}
            >
              <Ship className="h-3.5 w-3.5" />
              <span>Du Thuyền Sông Hương</span>
            </button>
          </div>

          {/* Atmosphere Presets */}
          <div className="hue-scroll flex items-center gap-1 overflow-x-auto">
            <Sun className="mr-1 hidden h-3.5 w-3.5 shrink-0 text-[#d6b372] sm:block" />
            {ATMOSPHERE_ORDER.map((id) => {
              const p = ATMOSPHERE_PRESETS[id];
              const active = atmosphere === id;
              return (
                <button
                  key={id}
                  onClick={() => onSelectAtmosphere(id)}
                  title={p.subtitle}
                  className={`shrink-0 cursor-pointer rounded-xl px-2.5 py-1.5 text-xs transition ${
                    active
                      ? 'border border-[#e5c17b]/55 bg-[#d6b372]/22 font-medium text-[#fae7c2]'
                      : 'text-[#cfc7ba] hover:bg-white/10'
                  }`}
                >
                  {p.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Close Dossier helper on Escape or mobile if needed */}
      {showDossier && (
        <button
          onClick={() => setShowDossier(false)}
          className="sr-only"
          aria-label="Close dossier"
        >
          <X />
        </button>
      )}
    </div>
  );
};
