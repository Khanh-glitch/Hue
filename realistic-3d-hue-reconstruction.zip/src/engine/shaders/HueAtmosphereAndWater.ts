import * as THREE from 'three';
import { Reflector } from 'three/examples/jsm/objects/Reflector.js';
import {
  AtmospherePreset,
  WATER_LEVEL_RIVER,
  WATER_LEVEL_TU_DUC,
  WORLD_SIZE,
} from '../../world/hueWorldConfig';

export interface AtmosphereAndWaterSystem {
  skyMesh: THREE.Mesh;
  riverWater: Reflector;
  lakeWater: Reflector;
  sunLight: THREE.DirectionalLight;
  hemiLight: THREE.HemisphereLight;
  applyAtmosphere: (
    preset: AtmospherePreset,
    renderer: THREE.WebGLRenderer,
    scene: THREE.Scene,
  ) => void;
  update: (elapsed: number, cameraPos: THREE.Vector3) => void;
}

const SKY_VERTEX_SHADER = /* glsl */ `
varying vec3 vWorldDir;
void main() {
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorldDir = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

const SKY_FRAGMENT_SHADER = /* glsl */ `
uniform vec3 uSkyZenith;
uniform vec3 uSkyHorizon;
uniform vec3 uFogColor;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uTime;
uniform float uStars;
uniform float uHaze;

varying vec3 vWorldDir;

float hash21(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}

float noise2(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(hash21(i + vec2(0.0, 0.0)), hash21(i + vec2(1.0, 0.0)), u.x),
    mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), u.x),
    u.y
  );
}

float fbm(vec2 p) {
  float s = 0.0;
  float a = 0.5;
  for (int i = 0; i < 4; i++) {
    s += a * noise2(p);
    p *= 2.04;
    a *= 0.5;
  }
  return s;
}

void main() {
  vec3 dir = normalize(vWorldDir);
  float y = dir.y;

  float horizonBlend = 1.0 - pow(max(y, 0.0), 0.46);
  vec3 sky = mix(uSkyZenith, uSkyHorizon, horizonBlend);

  float hazeBand = exp(-abs(y) * 7.5);
  sky = mix(sky, uFogColor, hazeBand * uHaze);
  if (y < 0.0) {
    sky = mix(sky, uFogColor, clamp(-y * 4.5, 0.0, 1.0));
  }

  // Sun / Moon disc & Mie atmospheric scattering
  float sunDot = max(dot(dir, normalize(uSunDir)), 0.0);
  float disc = smoothstep(0.9992, 0.9997, sunDot);
  float glow = pow(sunDot, 160.0) * 0.75;
  float halo = pow(sunDot, 14.0) * 0.24;
  float horizonWarmth = pow(sunDot, 4.0) * hazeBand * 0.34;
  sky += uSunColor * (disc * 2.8 + glow + halo + horizonWarmth);

  // Soft Hue drifting clouds
  if (y > 0.02) {
    vec2 cloudUv = dir.xz / (y + 0.16) * 0.85 + vec2(uTime * 0.006, uTime * 0.0025);
    float c = fbm(cloudUv * 1.4);
    float cloudMask = smoothstep(0.49, 0.78, c) * smoothstep(0.02, 0.22, y);
    vec3 cloudCol = mix(uSkyHorizon * 1.08, uSunColor * 1.15, pow(sunDot, 3.0) * 0.55);
    sky = mix(sky, cloudCol, cloudMask * 0.42 * (1.0 - uStars * 0.65));
  }

  // Night stars
  if (uStars > 0.02 && y > 0.03) {
    vec3 cell = floor(dir * 260.0);
    float sh = hash21(cell.xy + cell.z * 17.3);
    float star = step(0.9965, sh) * smoothstep(0.03, 0.28, y);
    float twinkle = 0.7 + 0.3 * sin(uTime * 2.4 + sh * 100.0);
    sky += vec3(0.85, 0.9, 1.0) * star * twinkle * uStars * 0.95;
  }

  gl_FragColor = vec4(sky, 1.0);
}
`;

function createHueWaterShader(flowSpeed: number, rippleScale: number) {
  return {
    name: 'HuePlanarWaterShader',
    uniforms: {
      color: { value: null },
      tDiffuse: { value: null },
      textureMatrix: { value: null },
      uTime: { value: 0 },
      uSunDir: { value: new THREE.Vector3(0.4, 0.6, 0.4).normalize() },
      uSunColor: { value: new THREE.Color(0xffe7be) },
      uWaterShallow: { value: new THREE.Color(0x285e58) },
      uWaterDeep: { value: new THREE.Color(0x102e34) },
      uFogColor: { value: new THREE.Color(0xc9d5da) },
      uFogDensity: { value: 0.00145 },
      uFlowSpeed: { value: flowSpeed },
      uRippleScale: { value: rippleScale },
    },
    vertexShader: /* glsl */ `
      uniform mat4 textureMatrix;
      varying vec4 vUv;
      varying vec3 vWorldPos;
      void main() {
        vUv = textureMatrix * vec4(position, 1.0);
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldPos = wp.xyz;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform sampler2D tDiffuse;
      uniform float uTime;
      uniform vec3 uSunDir;
      uniform vec3 uSunColor;
      uniform vec3 uWaterShallow;
      uniform vec3 uWaterDeep;
      uniform vec3 uFogColor;
      uniform float uFogDensity;
      uniform float uFlowSpeed;
      uniform float uRippleScale;

      varying vec4 vUv;
      varying vec3 vWorldPos;

      float waveHeight(vec2 p, float t) {
        float w1 = sin(p.x * 0.32 + p.y * 0.21 + t * 1.35) * 0.45;
        float w2 = cos(p.x * -0.58 + p.y * 0.64 - t * 1.75) * 0.28;
        float w3 = sin(p.x * 1.45 + p.y * 1.12 + t * 2.4) * 0.14;
        float w4 = cos(p.x * 2.9 - p.y * 2.4 - t * 3.1) * 0.06;
        return w1 + w2 + w3 + w4;
      }

      void main() {
        vec2 p = vWorldPos.xz * uRippleScale + vec2(-uTime * uFlowSpeed, uTime * uFlowSpeed * 0.22);
        float eps = 0.08;
        float h0 = waveHeight(p, uTime);
        float hx = waveHeight(p + vec2(eps, 0.0), uTime);
        float hz = waveHeight(p + vec2(0.0, eps), uTime);

        vec3 normal = normalize(vec3((h0 - hx) * 0.36, 1.0, (h0 - hz) * 0.36));
        vec3 viewDir = normalize(cameraPosition - vWorldPos);

        // Projected planar reflection with wave normal distortion
        vec4 projCoord = vUv;
        projCoord.xy += normal.xz * (0.045 * projCoord.w);
        vec3 reflCol = texture2DProj(tDiffuse, projCoord).rgb;

        // Schlick Fresnel (F0 = 0.022)
        float ndotv = clamp(dot(normal, viewDir), 0.0, 1.0);
        float fresnel = 0.03 + 0.95 * pow(1.0 - ndotv, 4.2);

        // Water body jade-emerald tint varying gently with camera grazing & ripple trough
        vec3 waterBody = mix(uWaterDeep, uWaterShallow, 0.4 + 0.35 * (1.0 - ndotv) + 0.15 * h0);
        vec3 col = mix(waterBody, reflCol, clamp(fresnel * 0.92 + 0.12, 0.0, 0.95));

        // GGX-inspired crisp sun/moon shimmer path on river ripples
        vec3 sunD = normalize(uSunDir);
        vec3 halfVec = normalize(viewDir + sunD);
        float ndoth = max(dot(normal, halfVec), 0.0);
        float spec = pow(ndoth, 220.0) * 1.65 + pow(ndoth, 36.0) * 0.16;
        col += uSunColor * spec * max(sunD.y * 1.5, 0.15);

        // Exponential squared fog matching scene.fog
        float dist = length(cameraPosition - vWorldPos);
        float fogFactor = 1.0 - exp(-pow(dist * uFogDensity, 2.0));
        col = mix(col, uFogColor, clamp(fogFactor, 0.0, 1.0));

        gl_FragColor = vec4(col, 1.0);
      }
    `,
  };
}

export function createHueAtmosphereAndWater(
  scene: THREE.Scene,
): AtmosphereAndWaterSystem {
  // 1. Procedural Sky Dome (radius 1300m)
  const skyGeo = new THREE.SphereGeometry(1300, 40, 24);
  const skyMat = new THREE.ShaderMaterial({
    uniforms: {
      uSkyZenith: { value: new THREE.Color(0x2c67a8) },
      uSkyHorizon: { value: new THREE.Color(0xd9d8cc) },
      uFogColor: { value: new THREE.Color(0xc9d5da) },
      uSunDir: { value: new THREE.Vector3(0.4, 0.6, 0.4).normalize() },
      uSunColor: { value: new THREE.Color(0xffe7be) },
      uTime: { value: 0 },
      uStars: { value: 0 },
      uHaze: { value: 0.62 },
    },
    vertexShader: SKY_VERTEX_SHADER,
    fragmentShader: SKY_FRAGMENT_SHADER,
    side: THREE.BackSide,
    depthWrite: false,
  });
  const skyMesh = new THREE.Mesh(skyGeo, skyMat);
  skyMesh.frustumCulled = false;
  scene.add(skyMesh);

  // 2. Main Sun/Moon Directional Shadow Light & Ambient Hemisphere Light
  const sunLight = new THREE.DirectionalLight(0xffe7be, 3.0);
  sunLight.castShadow = true;
  sunLight.shadow.mapSize.set(2048, 2048);
  sunLight.shadow.camera.near = 20;
  sunLight.shadow.camera.far = 750;
  const shadowExtent = 210;
  sunLight.shadow.camera.left = -shadowExtent;
  sunLight.shadow.camera.right = shadowExtent;
  sunLight.shadow.camera.top = shadowExtent;
  sunLight.shadow.camera.bottom = -shadowExtent;
  sunLight.shadow.bias = -0.00045;
  sunLight.shadow.normalBias = 0.035;
  scene.add(sunLight);
  scene.add(sunLight.target);

  const hemiLight = new THREE.HemisphereLight(0x98c2ea, 0x4a4337, 0.92);
  scene.add(hemiLight);

  // 3. Planar-Reflective Sông Hương & Kênh Như Ý Water Plane (y = 0)
  const riverGeo = new THREE.PlaneGeometry(WORLD_SIZE + 260, WORLD_SIZE + 260);
  const riverWater = new Reflector(riverGeo, {
    clipBias: 0.003,
    textureWidth: 512,
    textureHeight: 512,
    color: 0x285e58,
    multisample: 0,
    shader: createHueWaterShader(0.55, 0.65),
  });
  riverWater.rotation.x = -Math.PI * 0.5;
  riverWater.position.y = WATER_LEVEL_RIVER;
  scene.add(riverWater);

  // 4. Planar-Reflective Hồ Lưu Khiêm (Lăng Tự Đức Lotus Lake, y = 4.0)
  const lakeGeo = new THREE.CircleGeometry(52, 48);
  const lakeWater = new Reflector(lakeGeo, {
    clipBias: 0.003,
    textureWidth: 448,
    textureHeight: 448,
    color: 0x264d42,
    multisample: 0,
    shader: createHueWaterShader(0.16, 1.05),
  });
  lakeWater.rotation.x = -Math.PI * 0.5;
  lakeWater.position.set(-72, WATER_LEVEL_TU_DUC, 175);
  scene.add(lakeWater);

  // Prevent recursive reflection feedback & skip off-range planar passes
  let isRenderingReflection = false;
  let lastLakeFrame = -1;
  let frameIdx = 0;
  const origRiverRender = riverWater.onBeforeRender;
  const origLakeRender = lakeWater.onBeforeRender;
  const lakeCenter = new THREE.Vector3(-72, WATER_LEVEL_TU_DUC, 175);

  riverWater.onBeforeRender = function (renderer, sc, cam, geo, mat, grp) {
    if (isRenderingReflection) return;
    isRenderingReflection = true;
    const prevLakeVis = lakeWater.visible;
    lakeWater.visible = false;
    origRiverRender.call(this, renderer, sc, cam, geo, mat, grp);
    lakeWater.visible = prevLakeVis;
    isRenderingReflection = false;
  };

  lakeWater.onBeforeRender = function (renderer, sc, cam, geo, mat, grp) {
    if (isRenderingReflection) return;
    if (cam.position.distanceTo(lakeCenter) > 195 && lastLakeFrame >= 0) return;
    lastLakeFrame = frameIdx;
    isRenderingReflection = true;
    const prevRiverVis = riverWater.visible;
    riverWater.visible = false;
    origLakeRender.call(this, renderer, sc, cam, geo, mat, grp);
    riverWater.visible = prevRiverVis;
    isRenderingReflection = false;
  };

  // Dedicated offscreen sky-only scene for PMREM environment lighting generation
  const envScene = new THREE.Scene();
  const envSky = new THREE.Mesh(new THREE.SphereGeometry(50, 24, 16), skyMat);
  envScene.add(envSky);

  const sunDirVec = new THREE.Vector3();
  let pmrem: THREE.PMREMGenerator | null = null;
  let currentEnvRT: THREE.WebGLRenderTarget | null = null;

  const applyAtmosphere = (
    preset: AtmospherePreset,
    renderer: THREE.WebGLRenderer,
    targetScene: THREE.Scene,
  ) => {
    const phi = THREE.MathUtils.degToRad(90 - preset.sunElevation);
    const theta = THREE.MathUtils.degToRad(preset.sunAzimuth);
    sunDirVec.setFromSphericalCoords(1, phi, theta).normalize();

    skyMat.uniforms.uSkyZenith.value.set(preset.skyZenith);
    skyMat.uniforms.uSkyHorizon.value.set(preset.skyHorizon);
    skyMat.uniforms.uFogColor.value.set(preset.fogColor);
    skyMat.uniforms.uSunDir.value.copy(sunDirVec);
    skyMat.uniforms.uSunColor.value.set(preset.sunColor);
    skyMat.uniforms.uStars.value = preset.stars;

    sunLight.color.set(preset.sunColor);
    sunLight.intensity = preset.sunIntensity;
    hemiLight.color.set(preset.ambientSky);
    hemiLight.groundColor.set(preset.ambientGround);
    hemiLight.intensity = preset.ambientIntensity;

    targetScene.fog = new THREE.FogExp2(preset.fogColor, preset.fogDensity);
    renderer.toneMappingExposure = preset.exposure;

    [riverWater, lakeWater].forEach((water) => {
      const u = (water.material as THREE.ShaderMaterial).uniforms;
      u.uSunDir.value.copy(sunDirVec);
      u.uSunColor.value.set(preset.sunColor);
      u.uWaterShallow.value.set(preset.waterShallow);
      u.uWaterDeep.value.set(preset.waterDeep);
      u.uFogColor.value.set(preset.fogColor);
      u.uFogDensity.value = preset.fogDensity;
    });

    // Sync PBR sky reflections across gilt bronze, glazed ngói lưu ly, steel, and mosaic shards
    if (!pmrem) {
      pmrem = new THREE.PMREMGenerator(renderer);
      pmrem.compileEquirectangularShader();
    }
    if (currentEnvRT) currentEnvRT.dispose();
    currentEnvRT = pmrem.fromScene(envScene, 0.04);
    targetScene.environment = currentEnvRT.texture;
    targetScene.environmentIntensity = preset.id === 'night' ? 0.55 : 0.85;
  };

  const update = (elapsed: number, cameraPos: THREE.Vector3) => {
    frameIdx++;
    skyMat.uniforms.uTime.value = elapsed;
    (riverWater.material as THREE.ShaderMaterial).uniforms.uTime.value = elapsed;
    (lakeWater.material as THREE.ShaderMaterial).uniforms.uTime.value = elapsed;

    // Keep shadow frustum centered near camera so close-up architectural details always receive crisp shadows!
    const snap = 4.0;
    const sx = Math.round(cameraPos.x / snap) * snap;
    const sz = Math.round(cameraPos.z / snap) * snap;
    sunLight.target.position.set(sx, 6, sz);
    sunLight.position.set(
      sx + sunDirVec.x * 260,
      6 + sunDirVec.y * 260,
      sz + sunDirVec.z * 260,
    );
    sunLight.target.updateMatrixWorld();
  };

  return {
    skyMesh,
    riverWater,
    lakeWater,
    sunLight,
    hemiLight,
    applyAtmosphere,
    update,
  };
}
