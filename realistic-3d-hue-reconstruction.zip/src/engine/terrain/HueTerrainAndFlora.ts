import * as THREE from 'three';
import {
  fbm2D,
  getCanalCenterX,
  getCanalHalfWidth,
  getPathFactor,
  getRiverCenterZ,
  getRiverHalfWidth,
  getTerrainHeight,
  getTuDucLakeFactor,
  smoothstep,
  WORLD_SIZE,
} from '../../world/hueWorldConfig';

export interface TerrainAndFloraResult {
  group: THREE.Group;
  updateWind: (elapsed: number) => void;
  setRainWetness: (wetness: number) => void;
}

function fract(v: number): number {
  return v - Math.floor(v);
}

function hash2T(x: number, y: number, seed: number): number {
  return fract(Math.sin(x * 127.1 + y * 311.7 + seed * 74.7) * 43758.5453123);
}

function tileableNoise(u: number, v: number, freq: number, seed: number): number {
  const x = u * freq;
  const y = v * freq;
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const x0 = ((ix % freq) + freq) % freq;
  const x1 = (x0 + 1) % freq;
  const y0 = ((iy % freq) + freq) % freq;
  const y1 = (y0 + 1) % freq;
  const a = hash2T(x0, y0, seed);
  const b = hash2T(x1, y0, seed);
  const c = hash2T(x0, y1, seed);
  const d = hash2T(x1, y1, seed);
  return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uz(uy);
}

function uz(v: number): number {
  return v;
}

function tileableFbm(u: number, v: number, freq: number, octaves: number, seed: number): number {
  let sum = 0;
  let amp = 0.5;
  let f = freq;
  let norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += amp * tileableNoise(u, v, f, seed + i * 19);
    norm += amp;
    amp *= 0.5;
    f *= 2;
  }
  return sum / norm;
}

function createTerrainDetailTextures(): {
  map: THREE.DataTexture;
  normalMap: THREE.DataTexture;
  roughnessMap: THREE.DataTexture;
} {
  const size = 256;
  const height = new Float32Array(size * size);
  const albedo = new Uint8Array(size * size * 4);
  const rough = new Uint8Array(size * size * 4);

  for (let y = 0; y < size; y++) {
    const v = y / size;
    for (let x = 0; x < size; x++) {
      const u = x / size;
      // Pure multi-scale organic FBM — zero periodic sine stripes!
      const coarse = tileableFbm(u, v, 6, 4, 17);
      const medium = tileableFbm(u, v, 18, 3, 53);
      const micro = tileableNoise(u, v, 64, 97);
      const hVal = coarse * 0.45 + medium * 0.35 + micro * 0.2;
      height[y * size + x] = hVal;

      // Subtle neutral-warm multiplicative grain so vertex colors stay rich & natural
      const shade = 212 + (hVal - 0.5) * 76;
      const clampB = (n: number) => Math.max(150, Math.min(255, Math.round(n)));
      const idx = (y * size + x) * 4;
      albedo[idx] = clampB(shade * 1.0);
      albedo[idx + 1] = clampB(shade * 1.01);
      albedo[idx + 2] = clampB(shade * 0.96);
      albedo[idx + 3] = 255;

      const rv = Math.max(185, Math.min(250, Math.round(220 + (micro - 0.5) * 40)));
      rough[idx] = rv;
      rough[idx + 1] = rv;
      rough[idx + 2] = rv;
      rough[idx + 3] = 255;
    }
  }

  const nData = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const sample = (sx: number, sy: number) =>
        height[((sy + size) % size) * size + ((sx + size) % size)];
      const dx = sample(x + 1, y) - sample(x - 1, y);
      const dy = sample(x, y + 1) - sample(x, y - 1);
      let nx = -dx * 1.65;
      let ny = -dy * 1.65;
      let nz = 1;
      const inv = 1 / Math.hypot(nx, ny, nz);
      nx *= inv;
      ny *= inv;
      nz *= inv;
      const idx = (y * size + x) * 4;
      nData[idx] = Math.round((nx * 0.5 + 0.5) * 255);
      nData[idx + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      nData[idx + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      nData[idx + 3] = 255;
    }
  }

  const setup = (tex: THREE.DataTexture, srgb: boolean) => {
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(64, 64);
    tex.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
    tex.magFilter = THREE.LinearFilter;
    tex.minFilter = THREE.LinearMipmapLinearFilter;
    tex.generateMipmaps = true;
    tex.anisotropy = 8;
    tex.needsUpdate = true;
    return tex;
  };

  return {
    map: setup(new THREE.DataTexture(albedo, size, size, THREE.RGBAFormat), true),
    normalMap: setup(new THREE.DataTexture(nData, size, size, THREE.RGBAFormat), false),
    roughnessMap: setup(new THREE.DataTexture(rough, size, size, THREE.RGBAFormat), false),
  };
}

function isClearedForArchitecture(x: number, z: number): boolean {
  if (Math.abs(z - getRiverCenterZ(x)) < getRiverHalfWidth(x) + 4.0) return true;
  if (z > getRiverCenterZ(x) + 10 && Math.abs(x - getCanalCenterX(z)) < getCanalHalfWidth() + 3.8)
    return true;
  if (getPathFactor(x, z) > 0.22) return true;
  if (x > -245 && x < -175 && z > -162 && z < -40) return true;
  if (x > -66 && x < -24 && z > -126 && z < -90) return true;
  if (Math.abs(x - 195) < 17 && Math.abs(z) < 92) return true;
  if (x > 228 && x < 294 && z > 188 && z < 240) return true;
  if (getTuDucLakeFactor(x, z) > 0.06) return true;
  if (x > -148 && x < -26 && z > 132 && z < 208) return true;
  if (Math.hypot(x + 220, z - 94) < 12) return true;
  if (x > 8 && x < 72 && z > 234 && z < 382) return true;
  return false;
}

function attachWindSway(
  mat: THREE.MeshStandardMaterial,
  uniforms: { uTime: { value: number } },
  amp = 0.22,
  heightStart = 1.2,
) {
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uWindTime = uniforms.uTime;
    shader.vertexShader =
      `uniform float uWindTime;\n` +
      shader.vertexShader.replace(
        '#include <begin_vertex>',
        `
        #include <begin_vertex>
        float hMask = max(0.0, position.y - ${heightStart.toFixed(2)});
        #ifdef USE_INSTANCING
          vec4 instPos = instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
          float phase = instPos.x * 0.13 + instPos.z * 0.17;
        #else
          float phase = 0.0;
        #endif
        float gust = sin(uWindTime * 1.4 + phase) * 0.65 + sin(uWindTime * 2.9 + phase * 1.7) * 0.35;
        transformed.x += gust * ${amp.toFixed(3)} * hMask * 0.16;
        transformed.z += cos(uWindTime * 1.15 + phase) * ${amp.toFixed(3)} * hMask * 0.11;
        `,
      );
  };
}

export function buildHueTerrainAndFlora(): TerrainAndFloraResult {
  const root = new THREE.Group();
  root.name = 'HueTerrainAndFlora';
  const windUniforms = { uTime: { value: 0 } };

  // -------------------------------------------------------------------------
  // 1. Sculpted Continuous Hue Terrain Mesh (260 x 260 segments)
  // -------------------------------------------------------------------------
  const segs = 260;
  const geo = new THREE.PlaneGeometry(WORLD_SIZE, WORLD_SIZE, segs, segs);
  geo.rotateX(-Math.PI * 0.5);

  const pos = geo.attributes.position as THREE.BufferAttribute;
  const colors = new Float32Array(pos.count * 3);

  const cBed = new THREE.Color(0x363427);
  const cGrass = new THREE.Color(0x4b6a37);
  const cLush = new THREE.Color(0x375629);
  const cPineFloor = new THREE.Color(0x524c32);
  const cLaterite = new THREE.Color(0x886a4c);
  const cStonePath = new THREE.Color(0x86877f);
  const cSlopeRock = new THREE.Color(0x585a53);
  const tmpCol = new THREE.Color();

  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const y = getTerrainHeight(x, z);
    pos.setY(i, y);

    const hx = getTerrainHeight(x + 1.8, z);
    const hz = getTerrainHeight(x, z + 1.8);
    const slope = Math.hypot(hx - y, hz - y) / 1.8;

    const n = fbm2D(x * 0.032, z * 0.032, 3) * 0.5 + 0.5;
    const pathW = getPathFactor(x, z);
    const riverDist = Math.abs(z - getRiverCenterZ(x)) - getRiverHalfWidth(x);

    tmpCol.copy(cGrass).lerp(cLush, n);

    const pineZone = smoothstep(105, 195, z) * 0.72 + smoothstep(10, 22, y) * 0.45;
    tmpCol.lerp(cPineFloor, Math.min(0.85, pineZone));

    if (slope > 0.42) {
      tmpCol.lerp(cLaterite, Math.min(0.82, (slope - 0.42) * 1.15));
      tmpCol.lerp(cSlopeRock, smoothstep(0.68, 1.15, slope) * 0.58);
    }

    if (y < 0.75 || (getTuDucLakeFactor(x, z) > 0.2 && y < 4.5)) {
      tmpCol.lerp(cBed, smoothstep(0.9, -0.8, y));
    } else if (riverDist > 0 && riverDist < 6) {
      tmpCol.lerp(cLush, 0.45);
    }

    if (pathW > 0.05) {
      tmpCol.lerp(cStonePath, pathW * 0.85);
    }

    colors[i * 3] = tmpCol.r;
    colors[i * 3 + 1] = tmpCol.g;
    colors[i * 3 + 2] = tmpCol.b;
  }

  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();

  const detailMaps = createTerrainDetailTextures();
  const terrainMat = new THREE.MeshStandardMaterial({
    vertexColors: true,
    map: detailMaps.map,
    normalMap: detailMaps.normalMap,
    normalScale: new THREE.Vector2(0.75, 0.75),
    roughnessMap: detailMaps.roughnessMap,
    roughness: 0.94,
    metalness: 0.02,
  });

  const terrainMesh = new THREE.Mesh(geo, terrainMat);
  terrainMesh.receiveShadow = true;
  root.add(terrainMesh);

  // -------------------------------------------------------------------------
  // 2. Distant Núi Ngự Bình & Dãy Trường Sơn Atmospheric Horizon Ridges
  // -------------------------------------------------------------------------
  const mountainMat = new THREE.MeshStandardMaterial({
    color: 0x384d4b,
    roughness: 0.96,
  });

  [560, 750].forEach((rad, ringIdx) => {
    const segsM = 128;
    const mGeo = new THREE.RingGeometry(rad - 55, rad + 185, segsM, 5);
    mGeo.rotateX(-Math.PI * 0.5);
    const mp = mGeo.attributes.position as THREE.BufferAttribute;

    for (let i = 0; i < mp.count; i++) {
      const mx = mp.getX(i);
      const mz = mp.getZ(i);
      const r = Math.hypot(mx, mz);
      const t = (r - (rad - 55)) / 240;
      const profile = Math.sin(Math.min(1, Math.max(0, t)) * Math.PI);
      const ang = Math.atan2(mz, mx);

      const ridgeH =
        (ringIdx === 0 ? 48 : 88) +
        36 * Math.sin(ang * 5 + ringIdx) +
        22 * Math.cos(ang * 11 - 0.7) +
        14 * fbm2D(mx * 0.005, mz * 0.005, 3);
      const riverGap =
        1 - 0.62 * Math.exp(-Math.pow(Math.sin(ang), 2) * 8) * (mx > 0 ? 1 : 0.35);

      mp.setY(i, -6 + profile * Math.max(12, ridgeH) * riverGap);
    }
    mGeo.computeVertexNormals();
    root.add(new THREE.Mesh(mGeo, mountainMat));
  });

  // -------------------------------------------------------------------------
  // 3. Instanced Huế Botanical Ecosystem (Organic Multi-Cluster Silhouettes!)
  // -------------------------------------------------------------------------
  const rand = (idx: number, salt: number) => fract(Math.sin(idx * 127.1 + salt * 311.7) * 43758.5453);

  // --- A. Thông Huế (Tall Slender Red-Barked Pines with Asymmetric Umbrella Tufts) ---
  const pineTrunkMat = new THREE.MeshStandardMaterial({ color: 0x543c2c, roughness: 0.92 });
  const pineNeedleMat = new THREE.MeshStandardMaterial({ color: 0x2d5431, roughness: 0.86 });
  attachWindSway(pineNeedleMat, windUniforms, 0.22, 4.0);

  const pineTransforms: { x: number; y: number; z: number; s: number; rot: number }[] = [];
  for (let i = 0; i < 1100 && pineTransforms.length < 440; i++) {
    const x = (rand(i, 1) - 0.5) * 840;
    const z = (rand(i, 2) - 0.5) * 840;
    if (isClearedForArchitecture(x, z)) continue;
    const hillBias = z > 65 || (z < -125 && x < -120);
    if (!hillBias && rand(i, 3) > 0.24) continue;
    const y = getTerrainHeight(x, z);
    if (y < 2.0) continue;
    pineTransforms.push({
      x,
      y,
      z,
      s: 0.84 + rand(i, 4) * 0.65,
      rot: rand(i, 5) * Math.PI * 2,
    });
  }

  if (pineTransforms.length > 0) {
    const pCount = pineTransforms.length;
    const trunkGeo = new THREE.CylinderGeometry(0.14, 0.31, 11.2, 7);
    trunkGeo.translate(0, 5.6, 0);
    const trunkInst = new THREE.InstancedMesh(trunkGeo, pineTrunkMat, pCount);
    trunkInst.castShadow = true;

    // 4 organic displaced needle bough tufts high on the trunk (authentic Hue Pine!)
    const tuftConfigs = [
      { rx: -1.1, ry: 8.8, rz: 0.6, sx: 2.25, sy: 0.95, sz: 2.05 },
      { rx: 1.25, ry: 9.8, rz: -0.5, sx: 2.1, sy: 0.9, sz: 2.2 },
      { rx: -0.3, ry: 10.8, rz: -1.0, sx: 1.9, sy: 0.85, sz: 1.85 },
      { rx: 0.2, ry: 11.7, rz: 0.2, sx: 2.15, sy: 1.0, sz: 2.05 },
    ];
    const tuftMeshes = tuftConfigs.map((cfg, cIdx) => {
      const g = new THREE.IcosahedronGeometry(1.0, 2);
      const gp = g.attributes.position as THREE.BufferAttribute;
      for (let vi = 0; vi < gp.count; vi++) {
        const vx = gp.getX(vi);
        const vy = gp.getY(vi);
        const vz = gp.getZ(vi);
        const lump =
          1 + 0.24 * Math.sin(vx * 4.3 + cIdx) * Math.cos(vz * 4.7 - vy * 3.2);
        gp.setXYZ(vi, vx * cfg.sx * lump, vy * cfg.sy * lump, vz * cfg.sz * lump);
      }
      g.computeVertexNormals();
      g.translate(cfg.rx, cfg.ry, cfg.rz);
      const im = new THREE.InstancedMesh(g, pineNeedleMat, pCount);
      im.castShadow = true;
      return im;
    });

    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const sc = new THREE.Vector3();
    const posV = new THREE.Vector3();
    const tint = new THREE.Color();

    pineTransforms.forEach((p, idx) => {
      posV.set(p.x, p.y - 0.15, p.z);
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), p.rot);
      sc.set(p.s, p.s, p.s);
      m.compose(posV, q, sc);
      trunkInst.setMatrixAt(idx, m);
      tint.setHSL(0.34 + (rand(idx, 9) - 0.5) * 0.04, 0.32, 0.23 + (rand(idx, 10) - 0.5) * 0.06);
      tuftMeshes.forEach((tm) => {
        tm.setMatrixAt(idx, m);
        tm.setColorAt(idx, tint);
      });
    });
    trunkInst.instanceMatrix.needsUpdate = true;
    root.add(trunkInst);
    tuftMeshes.forEach((tm) => {
      tm.instanceMatrix.needsUpdate = true;
      root.add(tm);
    });
  }

  // --- B. Hoa Sứ / Cây Đại (Gnarled Silver-Barked Temple Frangipani near Thiên Mụ & Kim Long) ---
  const frangiBarkMat = new THREE.MeshStandardMaterial({ color: 0x8f8a80, roughness: 0.86 });
  const frangiLeafMat = new THREE.MeshStandardMaterial({ color: 0x4b7438, roughness: 0.74 });
  const frangiBloomMat = new THREE.MeshStandardMaterial({ color: 0xfff8e6, roughness: 0.55 });
  attachWindSway(frangiLeafMat, windUniforms, 0.18, 1.5);

  const frangiSpots: [number, number, number][] = [
    [-218, -96, 1.05],
    [-202, -96, 1.0],
    [-222, -79, 0.92],
    [-198, -79, 0.95],
    [-226, -108, 1.1],
    [-194, -108, 1.08],
    [-216, -64, 0.85],
    [-204, -64, 0.88],
    [-55, -102, 0.95],
    [-35, -102, 0.92],
    [-52, -118, 0.98],
  ];

  frangiSpots.forEach(([fx, fz, fs], idx) => {
    const fy = getTerrainHeight(fx, fz);
    const tree = new THREE.Group();
    tree.position.set(fx, fy - 0.1, fz);
    tree.rotation.y = idx * 1.4;

    const mainTrunk = new THREE.Mesh(
      new THREE.CylinderGeometry(0.16 * fs, 0.28 * fs, 2.2 * fs, 7),
      frangiBarkMat,
    );
    mainTrunk.position.y = 1.1 * fs;
    mainTrunk.rotation.z = 0.12;
    mainTrunk.castShadow = true;
    tree.add(mainTrunk);

    for (let b = 0; b < 5; b++) {
      const ba = (b / 5) * Math.PI * 2 + idx * 0.7;
      const limb = new THREE.Mesh(
        new THREE.CylinderGeometry(0.08 * fs, 0.14 * fs, 2.2 * fs, 6),
        frangiBarkMat,
      );
      limb.position.set(Math.sin(ba) * 0.8 * fs, 2.55 * fs, Math.cos(ba) * 0.8 * fs);
      limb.rotation.z = -Math.sin(ba) * 0.65;
      limb.rotation.x = Math.cos(ba) * 0.65;
      limb.castShadow = true;
      tree.add(limb);

      for (let sub = 0; sub < 2; sub++) {
        const sa = ba + (sub - 0.5) * 0.45;
        const sr = (1.35 + sub * 0.45) * fs;
        const canopy = new THREE.Mesh(
          new THREE.DodecahedronGeometry(1.05 * fs, 1),
          frangiLeafMat,
        );
        canopy.scale.set(1.25, 0.55, 1.25);
        canopy.position.set(Math.sin(sa) * sr, (3.45 + sub * 0.3) * fs, Math.cos(sa) * sr);
        canopy.castShadow = true;
        tree.add(canopy);
      }

      const bloom = new THREE.Mesh(new THREE.SphereGeometry(0.2 * fs, 6, 6), frangiBloomMat);
      bloom.position.set(Math.sin(ba) * 1.65 * fs, 4.0 * fs, Math.cos(ba) * 1.65 * fs);
      tree.add(bloom);
    }
    root.add(tree);
  });

  // --- C. Phượng Vĩ & Liễu Rủ (Multi-Cluster Organic Canopies & Forked Trunks!) ---
  const willowLeafMat = new THREE.MeshStandardMaterial({ color: 0x456e35, roughness: 0.8 });
  const flamboyantMat = new THREE.MeshStandardMaterial({ color: 0xc93b2b, roughness: 0.75 });
  attachWindSway(willowLeafMat, windUniforms, 0.3, 1.5);
  attachWindSway(flamboyantMat, windUniforms, 0.24, 2.0);

  const riverTrees: { x: number; z: number; isFlamboyant: boolean; s: number; rot: number }[] = [];
  for (let i = 0; i < 200 && riverTrees.length < 78; i++) {
    const x = -285 + (i / 200) * 590 + (rand(i, 12) - 0.5) * 16;
    const side = i % 2 === 0 ? -1 : 1;
    const z = getRiverCenterZ(x) + side * (getRiverHalfWidth(x) + 8 + rand(i, 13) * 18);
    if (isClearedForArchitecture(x, z)) continue;
    const y = getTerrainHeight(x, z);
    if (y < 1.2) continue;
    riverTrees.push({
      x,
      z,
      isFlamboyant: Math.abs(x - 195) < 105 && i % 3 === 0,
      s: 0.85 + rand(i, 14) * 0.55,
      rot: rand(i, 15) * Math.PI * 2,
    });
  }
  for (let i = 0; i < 18; i++) {
    const a = (i / 18) * Math.PI * 2;
    const lx = -72 + Math.cos(a) * 52;
    const lz = 175 + Math.sin(a) * 34;
    if (!isClearedForArchitecture(lx, lz)) {
      riverTrees.push({ x: lx, z: lz, isFlamboyant: false, s: 0.95, rot: a });
    }
  }

  riverTrees.forEach((rt, idx) => {
    const y = getTerrainHeight(rt.x, rt.z);
    const grp = new THREE.Group();
    grp.position.set(rt.x, y - 0.1, rt.z);
    grp.rotation.y = rt.rot;

    const trunk = new THREE.Mesh(
      new THREE.CylinderGeometry(0.14 * rt.s, 0.28 * rt.s, 3.4 * rt.s, 7),
      pineTrunkMat,
    );
    trunk.position.y = 1.6 * rt.s;
    trunk.rotation.z = ((idx % 3) - 1) * 0.08;
    trunk.castShadow = true;
    grp.add(trunk);

    const leafM = rt.isFlamboyant ? flamboyantMat : willowLeafMat;
    const puffs = rt.isFlamboyant
      ? [
          [0, 4.1, 0, 2.3, 0.68, 2.1],
          [-1.3, 3.7, 0.9, 1.8, 0.62, 1.7],
          [1.4, 3.8, -0.8, 1.75, 0.62, 1.65],
          [0.3, 4.5, 1.1, 1.6, 0.58, 1.55],
        ]
      : [
          [0, 4.1, 0, 2.0, 1.15, 2.0],
          [-1.15, 3.4, 0.75, 1.45, 1.25, 1.45],
          [1.2, 3.3, -0.7, 1.5, 1.3, 1.5],
          [0.4, 3.5, 1.15, 1.4, 1.25, 1.4],
          [-0.5, 3.6, -1.1, 1.35, 1.15, 1.35],
        ];

    puffs.forEach(([px, py, pz, sx, sy, sz]) => {
      const puff = new THREE.Mesh(new THREE.DodecahedronGeometry(1.0, 1), leafM);
      puff.position.set(px * rt.s, py * rt.s, pz * rt.s);
      puff.scale.set(sx * rt.s, sy * rt.s, sz * rt.s);
      puff.castShadow = true;
      grp.add(puff);
    });
    root.add(grp);
  });

  // --- D. Lau Sậy Bờ Sông & Wild Hillside Grass Tufts (Instanced!) ---
  const reedMat = new THREE.MeshStandardMaterial({ color: 0x5c7a3b, roughness: 0.82 });
  attachWindSway(reedMat, windUniforms, 0.34, 0.15);

  const reedGeo = new THREE.ConeGeometry(0.06, 1.85, 4);
  reedGeo.translate(0, 0.92, 0);
  const reedMatrices: THREE.Matrix4[] = [];
  const rm = new THREE.Matrix4();
  const rq = new THREE.Quaternion();
  const rs = new THREE.Vector3();
  const rp = new THREE.Vector3();

  for (let i = 0; i < 680; i++) {
    const x = (rand(i, 21) - 0.5) * 680;
    const side = i % 2 === 0 ? 1 : -1;
    const z = getRiverCenterZ(x) + side * (getRiverHalfWidth(x) - 1.5 + rand(i, 22) * 5.2);
    if (Math.abs(x + 210) < 12 && z < 0) continue;
    if (Math.abs(x - 195) < 12) continue;
    const y = getTerrainHeight(x, z);
    if (y < -0.25 || y > 1.7) continue;

    rp.set(x, y, z);
    rq.setFromAxisAngle(new THREE.Vector3(0, 1, 0), rand(i, 23) * Math.PI * 2);
    const sc = 0.7 + rand(i, 24) * 0.7;
    rs.set(sc, sc, sc);
    rm.compose(rp, rq, rs);
    reedMatrices.push(rm.clone());
  }

  // Also add lush hillside grass tufts near monuments & trails
  for (let i = 0; i < 900; i++) {
    const x = (rand(i, 41) - 0.5) * 600;
    const z = (rand(i, 42) - 0.5) * 680;
    if (isClearedForArchitecture(x, z)) continue;
    const y = getTerrainHeight(x, z);
    if (y < 1.3) continue;
    rp.set(x, y, z);
    rq.setFromAxisAngle(new THREE.Vector3(0, 1, 0), rand(i, 43) * Math.PI * 2);
    const sc = 0.35 + rand(i, 44) * 0.35;
    rs.set(sc * 1.4, sc * 0.55, sc * 1.4);
    rm.compose(rp, rq, rs);
    reedMatrices.push(rm.clone());
  }

  if (reedMatrices.length > 0) {
    const reedInst = new THREE.InstancedMesh(reedGeo, reedMat, reedMatrices.length);
    reedMatrices.forEach((mat, idx) => reedInst.setMatrixAt(idx, mat));
    reedInst.instanceMatrix.needsUpdate = true;
    root.add(reedInst);
  }

  const updateWind = (elapsed: number) => {
    windUniforms.uTime.value = elapsed;
  };

  const setRainWetness = (wetness: number) => {
    terrainMat.roughness = THREE.MathUtils.lerp(0.94, 0.58, wetness);
  };

  return { group: root, updateWind, setRainWetness };
}
