import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import {
  ATMOSPHERE_PRESETS,
  AtmosphereId,
  getWalkableHeight,
  HUE_LANDMARKS,
  LandmarkDef,
  WORLD_SIZE,
} from '../world/hueWorldConfig';
import { createHueMaterialFoundry, HueMaterialSet } from './materials/HueMaterialFoundry';
import { buildHueTerrainAndFlora } from './terrain/HueTerrainAndFlora';
import { createHueAtmosphereAndWater } from './shaders/HueAtmosphereAndWater';
import { buildThienMuComplex } from '../world/monuments/buildThienMuComplex';
import { buildKhaiDinhTomb } from '../world/monuments/buildKhaiDinhTomb';
import { buildTuDucLakeComplex } from '../world/monuments/buildTuDucLakeComplex';
import { buildTrangTienBridge } from '../world/monuments/buildTrangTienBridge';
import { buildThanhToanAndVillage } from '../world/monuments/buildThanhToanAndVillage';
import { buildKimLongGardenAndBoats } from '../world/monuments/buildKimLongGardenAndBoats';
import { LanternHandle } from '../world/monuments/hueArchitecturalHelpers';
import { createHueParticles } from './HueParticles';
import { HueAmbientAudio } from './audio/HueAmbientAudio';

export type MovementMode = 'walk' | 'fly' | 'boat';

export interface EngineCallbacks {
  onZoneChange?: (landmark: LandmarkDef | null) => void;
  onBellNear?: (near: boolean) => void;
  onModeChange?: (mode: MovementMode) => void;
  onBellRung?: () => void;
}

export class HueWorldEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private composer: EffectComposer;
  private bloomPass: UnrealBloomPass;

  private mats: HueMaterialSet;
  private audio = new HueAmbientAudio();
  private callbacks: EngineCallbacks;

  private allLanterns: LanternHandle[] = [];
  private interiorLights: THREE.PointLight[] = [];
  private hoaDangGroup!: THREE.Group;
  private hoaDangLights: THREE.PointLight[] = [];
  private bellMesh!: THREE.Group;
  private bellPosition = new THREE.Vector3();
  private bellSwingAmp = 0;
  private bellSwingPhase = 0;

  private updateWind!: (t: number) => void;
  private setTerrainWetness!: (w: number) => void;
  private updateAtmos!: (t: number, camPos: THREE.Vector3) => void;
  private applyAtmosPreset!: (
    preset: (typeof ATMOSPHERE_PRESETS)[AtmosphereId],
    renderer: THREE.WebGLRenderer,
    scene: THREE.Scene,
  ) => void;
  private updateBoats!: (t: number) => void;
  private updateParticles!: (dt: number, t: number, camPos: THREE.Vector3) => void;
  private setRainIntensity!: (r: number) => void;
  private leadBoatGroup!: THREE.Group;

  private currentAtmos: AtmosphereId = 'morning';
  private mode: MovementMode = 'walk';
  private introActive = true;
  private disposed = false;
  private loopPaused = false;
  private rafId = 0;
  private timer = new THREE.Timer();
  private elapsed = 0;

  // Player / Camera state
  private yaw = 0;
  private pitch = 0.08;
  private velocity = new THREE.Vector3();
  private onGround = true;
  private keys = new Set<string>();
  private isDragging = false;
  private lastPointer = { x: 0, y: 0 };

  // Smooth camera transition glide
  private tween: {
    active: boolean;
    t: number;
    dur: number;
    fromPos: THREE.Vector3;
    toPos: THREE.Vector3;
    fromQuat: THREE.Quaternion;
    toQuat: THREE.Quaternion;
  } = {
    active: false,
    t: 0,
    dur: 1.05,
    fromPos: new THREE.Vector3(),
    toPos: new THREE.Vector3(),
    fromQuat: new THREE.Quaternion(),
    toQuat: new THREE.Quaternion(),
  };

  private activeZoneId: string | null = null;
  private discoveredZones = new Set<string>();
  private wasNearBell = false;

  constructor(container: HTMLElement, callbacks: EngineCallbacks = {}) {
    this.container = container;
    this.callbacks = callbacks;

    // 1. Renderer setup with ACES Filmic & PCFSoftShadowMap
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.06;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();

    this.camera = new THREE.PerspectiveCamera(
      52,
      container.clientWidth / Math.max(1, container.clientHeight),
      0.22,
      1900,
    );

    // 2. Post-processing Composer (Render -> Soft Bloom -> Output ACES/sRGB)
    const size = new THREE.Vector2(container.clientWidth, container.clientHeight);
    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.bloomPass = new UnrealBloomPass(size, 0.16, 0.4, 1.05);
    this.composer.addPass(this.bloomPass);
    this.composer.addPass(new OutputPass());

    // 3. Materials, Sky, Water, Terrain & All Huế Heritage Landmarks
    this.mats = createHueMaterialFoundry();

    const atmos = createHueAtmosphereAndWater(this.scene);
    this.updateAtmos = atmos.update;
    this.applyAtmosPreset = atmos.applyAtmosphere;

    const terrain = buildHueTerrainAndFlora();
    this.scene.add(terrain.group);
    this.updateWind = terrain.updateWind;
    this.setTerrainWetness = terrain.setRainWetness;

    const thienMu = buildThienMuComplex(this.mats);
    this.scene.add(thienMu.group);
    this.bellMesh = thienMu.bellMesh;
    this.bellPosition.copy(thienMu.bellPosition);
    this.allLanterns.push(...thienMu.lanterns);

    const khaiDinh = buildKhaiDinhTomb(this.mats);
    this.scene.add(khaiDinh.group);
    this.allLanterns.push(...khaiDinh.lanterns);
    this.interiorLights.push(...khaiDinh.interiorLights);

    const tuDuc = buildTuDucLakeComplex(this.mats);
    this.scene.add(tuDuc.group);
    this.allLanterns.push(...tuDuc.lanterns);

    const trangTien = buildTrangTienBridge(this.mats);
    this.scene.add(trangTien.group);
    this.allLanterns.push(...trangTien.lanterns);

    const thanhToan = buildThanhToanAndVillage(this.mats);
    this.scene.add(thanhToan.group);
    this.allLanterns.push(...thanhToan.lanterns);

    const kimLong = buildKimLongGardenAndBoats(this.mats);
    this.scene.add(kimLong.group);
    this.allLanterns.push(...kimLong.lanterns);
    this.hoaDangGroup = kimLong.hoaDangGroup;
    this.hoaDangLights = kimLong.hoaDangLights;
    this.updateBoats = kimLong.updateBoats;
    this.leadBoatGroup = kimLong.boats[0].group;

    // Atmospheric Particles (incense smoke + sunbeam dust motes + Mưa Bụi)
    const particles = createHueParticles([
      khaiDinh.incenseOrigin,
      new THREE.Vector3(-210, 11.4, -145), // Điện Đại Hùng incense
      new THREE.Vector3(260, 4.6, 213.5), // Cầu Ngói altar incense
    ]);
    this.scene.add(particles.group);
    this.updateParticles = particles.update;
    this.setRainIntensity = particles.setRainIntensity;

    // 4. Initial Atmosphere & Scenic Opening Angle overlooking Sông Hương & Tháp Phước Duyên
    this.setAtmosphere('morning');
    this.setCameraPose(
      new THREE.Vector3(-174, 11.2, -16),
      new THREE.Vector3(-210, 17.5, -104),
    );

    this.bindEvents();
    this.exposeDebugHook();
    this.animate();
  }

  private setCameraPose(pos: THREE.Vector3, lookTarget: THREE.Vector3) {
    this.camera.position.copy(pos);
    this.camera.lookAt(lookTarget);
    const euler = new THREE.Euler().setFromQuaternion(this.camera.quaternion, 'YXZ');
    this.yaw = euler.y;
    this.pitch = euler.x;
    this.velocity.set(0, 0, 0);
  }

  public beginExploration() {
    this.introActive = false;
    this.flyToLandmark('thien-mu');
  }

  public setAtmosphere(id: AtmosphereId) {
    this.currentAtmos = id;
    const preset = ATMOSPHERE_PRESETS[id];
    this.applyAtmosPreset(preset, this.renderer, this.scene);
    this.setRainIntensity(preset.rainIntensity);
    this.setTerrainWetness(preset.rainIntensity);
    this.mats.setRainWetness(preset.rainIntensity);

    // Tune lantern emissive glow & floating Hoa Đăng visibility
    const glow = preset.lanternGlow;
    this.allLanterns.forEach((l) => {
      l.mat.emissiveIntensity = 0.55 + glow * 1.1;
      if (l.light) l.light.intensity = l.baseIntensity * glow;
    });

    // Cung Thiên Định interior stays warmly lit with rich jewel-tone contrast
    this.interiorLights.forEach((pt, idx) => {
      pt.intensity = (idx === 0 ? 5.2 : 6.4) * (id === 'night' ? 1.35 : 1.0);
    });

    const showHoaDang = id === 'sunset' || id === 'night' || id === 'dawn';
    this.hoaDangGroup.visible = showHoaDang;
    this.hoaDangLights.forEach((pt) => {
      pt.intensity = id === 'night' ? 2.4 : 1.1;
    });

    // Bloom softly stronger during night/sunset lanterns
    this.bloomPass.strength = id === 'night' ? 0.34 : id === 'sunset' ? 0.24 : 0.14;
  }

  public setMode(nextMode: MovementMode) {
    this.mode = nextMode;
    this.introActive = false;
    this.tween.active = false;
    this.velocity.set(0, 0, 0);
    if (nextMode === 'walk') {
      const groundY = getWalkableHeight(this.camera.position.x, this.camera.position.z);
      if (this.camera.position.y < groundY + 1.5) {
        this.camera.position.y = groundY + 1.72;
      }
    }
    this.callbacks.onModeChange?.(nextMode);
  }

  public flyToLandmark(landmarkId: string) {
    const lm = HUE_LANDMARKS.find((l) => l.id === landmarkId);
    if (!lm) return;

    this.introActive = false;
    if (this.mode === 'boat') {
      this.setMode('walk');
    }

    const toPos = new THREE.Vector3(...lm.position);
    const lookTarget = new THREE.Vector3(...lm.lookAt);

    const dummyCam = new THREE.PerspectiveCamera();
    dummyCam.position.copy(toPos);
    dummyCam.lookAt(lookTarget);

    this.tween.active = true;
    this.tween.t = 0;
    this.tween.dur = 1.05;
    this.tween.fromPos.copy(this.camera.position);
    this.tween.toPos.copy(toPos);
    this.tween.fromQuat.copy(this.camera.quaternion);
    this.tween.toQuat.copy(dummyCam.quaternion);
    this.velocity.set(0, 0, 0);
  }

  public toggleMute(): boolean {
    return this.audio.toggleMute();
  }

  public isMuted(): boolean {
    return this.audio.isMuted();
  }

  public ringTempleBell() {
    this.bellSwingAmp = 0.24;
    this.bellSwingPhase = 0;
    this.audio.ringDaiHongChung();
    this.callbacks.onBellRung?.();
  }

  private bindEvents() {
    const dom = this.renderer.domElement;

    const onResize = () => {
      if (this.disposed) return;
      const w = this.container.clientWidth;
      const h = Math.max(1, this.container.clientHeight);
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
      this.composer.setSize(w, h);
      this.bloomPass.resolution.set(w, h);
    };
    window.addEventListener('resize', onResize);

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      const code = e.code;
      this.keys.add(code);
      if (code === 'KeyF') {
        this.setMode(this.mode === 'fly' ? 'walk' : 'fly');
      } else if (code === 'KeyG') {
        this.ringTempleBell();
      } else if (code === 'Space' && this.mode === 'walk' && this.onGround) {
        this.velocity.y = 6.2;
        this.onGround = false;
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      this.keys.delete(e.code);
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    const onPointerDown = (e: PointerEvent) => {
      this.isDragging = true;
      this.lastPointer = { x: e.clientX, y: e.clientY };
      this.tween.active = false;
      if (this.introActive) this.introActive = false;
    };
    const onPointerMove = (e: PointerEvent) => {
      if (document.pointerLockElement === dom) {
        this.yaw -= e.movementX * 0.0024;
        this.pitch = THREE.MathUtils.clamp(
          this.pitch - e.movementY * 0.0024,
          -Math.PI * 0.46,
          Math.PI * 0.46,
        );
        return;
      }
      if (!this.isDragging) return;
      const dx = e.clientX - this.lastPointer.x;
      const dy = e.clientY - this.lastPointer.y;
      this.lastPointer = { x: e.clientX, y: e.clientY };
      this.yaw -= dx * 0.0036;
      this.pitch = THREE.MathUtils.clamp(
        this.pitch - dy * 0.0034,
        -Math.PI * 0.46,
        Math.PI * 0.46,
      );
    };
    const onPointerUp = () => {
      this.isDragging = false;
    };

    const onWheel = (e: WheelEvent) => {
      // Smooth forward/backward dolly on scroll
      const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
      if (this.mode === 'walk') forward.y = 0;
      forward.normalize();
      this.camera.position.addScaledVector(forward, -e.deltaY * 0.025);
    };

    dom.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    dom.addEventListener('wheel', onWheel, { passive: true });

    // Store cleanup on instance
    this.cleanupListeners = () => {
      window.removeEventListener('resize', onResize);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      dom.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      dom.removeEventListener('wheel', onWheel);
    };
  }

  private cleanupListeners: () => void = () => {};

  private exposeDebugHook() {
    (window as unknown as Record<string, unknown>).__HUE_DEBUG__ = {
      teleportTo: (pos: [number, number, number], lookAt: [number, number, number]) => {
        this.introActive = false;
        this.tween.active = false;
        this.setMode('fly');
        this.setCameraPose(new THREE.Vector3(...pos), new THREE.Vector3(...lookAt));
        this.updateAtmos(this.elapsed, this.camera.position);
        this.composer.render();
      },
      setAtmosphere: (id: AtmosphereId) => {
        this.setAtmosphere(id);
        this.composer.render();
      },
      setMode: (mode: MovementMode) => this.setMode(mode),
      flyToLandmark: (id: string) => this.flyToLandmark(id),
      setLoopPaused: (paused: boolean) => {
        this.loopPaused = paused;
        if (!paused) this.animate();
        else this.composer.render();
      },
      renderOnce: () => this.composer.render(),
      getState: () => ({
        position: this.camera.position.toArray(),
        atmos: this.currentAtmos,
        mode: this.mode,
      }),
    };
  }

  private updateCameraAndMovement(dt: number) {
    if (this.introActive) {
      // Serene opening aerial drift across Sông Hương framing Tháp Phước Duyên cleanly
      const angle = this.elapsed * 0.075;
      const cx = -172 + Math.sin(angle) * 22;
      const cz = -14 + Math.cos(angle) * 12;
      const cy = 11.4 + Math.sin(this.elapsed * 0.25) * 0.9;
      this.camera.position.set(cx, cy, cz);
      this.camera.lookAt(-210, 17.2, -104);
      return;
    }

    if (this.tween.active) {
      this.tween.t += dt / this.tween.dur;
      const t = Math.min(1, this.tween.t);
      // Cubic ease-in-out
      const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
      this.camera.position.lerpVectors(this.tween.fromPos, this.tween.toPos, ease);
      this.camera.quaternion.slerpQuaternions(
        this.tween.fromQuat,
        this.tween.toQuat,
        ease,
      );
      if (t >= 1) {
        this.tween.active = false;
        const euler = new THREE.Euler().setFromQuaternion(this.camera.quaternion, 'YXZ');
        this.yaw = euler.y;
        this.pitch = euler.x;
      }
      return;
    }

    // Apply user look rotation
    const euler = new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ');
    this.camera.quaternion.setFromEuler(euler);

    if (this.mode === 'boat') {
      // Ride smoothly on the bow deck of the lead Thuyền Rồng!
      const bowLocal = new THREE.Vector3(4.5, 2.35, 0);
      bowLocal.applyMatrix4(this.leadBoatGroup.matrixWorld);
      this.camera.position.copy(bowLocal);
      return;
    }

    const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(this.camera.quaternion);
    const sprint = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight');

    if (this.mode === 'fly') {
      const speed = sprint ? 42 : 17;
      const move = new THREE.Vector3();
      if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) move.add(forward);
      if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) move.sub(forward);
      if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) move.add(right);
      if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) move.sub(right);
      if (this.keys.has('Space') || this.keys.has('KeyE')) move.y += 1;
      if (this.keys.has('KeyQ') || this.keys.has('KeyC')) move.y -= 1;

      if (move.lengthSq() > 0) move.normalize();
      this.velocity.lerp(move.multiplyScalar(speed), Math.min(1, dt * 8));
      this.camera.position.addScaledVector(this.velocity, dt);

      const minH = getWalkableHeight(this.camera.position.x, this.camera.position.z) + 0.8;
      if (this.camera.position.y < minH) this.camera.position.y = minH;
    } else {
      // Walk mode with smooth stair climbing & gentle ground following
      forward.y = 0;
      forward.normalize();
      right.y = 0;
      right.normalize();

      const speed = sprint ? 14.5 : 7.5;
      const move = new THREE.Vector3();
      if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) move.add(forward);
      if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) move.sub(forward);
      if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) move.add(right);
      if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) move.sub(right);

      if (move.lengthSq() > 0) move.normalize();
      this.velocity.x = THREE.MathUtils.lerp(this.velocity.x, move.x * speed, Math.min(1, dt * 10));
      this.velocity.z = THREE.MathUtils.lerp(this.velocity.z, move.z * speed, Math.min(1, dt * 10));

      const nextX = this.camera.position.x + this.velocity.x * dt;
      const nextZ = this.camera.position.z + this.velocity.z * dt;

      // Prevent stepping off into deep river riverbed in walk mode
      const nextFloor = getWalkableHeight(nextX, nextZ);
      if (nextFloor > -0.35) {
        this.camera.position.x = nextX;
        this.camera.position.z = nextZ;
      }

      const targetY = getWalkableHeight(this.camera.position.x, this.camera.position.z) + 1.72;
      if (this.onGround) {
        this.camera.position.y = THREE.MathUtils.lerp(
          this.camera.position.y,
          targetY,
          Math.min(1, dt * 14),
        );
      } else {
        this.velocity.y -= 17.5 * dt;
        this.camera.position.y += this.velocity.y * dt;
        if (this.camera.position.y <= targetY) {
          this.camera.position.y = targetY;
          this.velocity.y = 0;
          this.onGround = true;
        }
      }
    }

    // Clamp to playable Hue valley bounds
    const bound = WORLD_SIZE * 0.45;
    this.camera.position.x = THREE.MathUtils.clamp(this.camera.position.x, -bound, bound);
    this.camera.position.z = THREE.MathUtils.clamp(this.camera.position.z, -bound, bound);
  }

  private checkLandmarksAndProximity() {
    let found: LandmarkDef | null = null;
    const cp = this.camera.position;
    for (const lm of HUE_LANDMARKS) {
      const dist = Math.hypot(cp.x - lm.zoneCenter[0], cp.z - lm.zoneCenter[2]);
      if (dist <= lm.zoneRadius) {
        // Prefer interior Cung Thiên Định over general Khải Định when inside chamber!
        if (!found || lm.zoneRadius < found.zoneRadius) {
          found = lm;
        }
      }
    }

    const nextId = found?.id ?? null;
    if (nextId !== this.activeZoneId) {
      this.activeZoneId = nextId;
      this.callbacks.onZoneChange?.(found);
      if (found && !this.discoveredZones.has(found.id)) {
        this.discoveredZones.add(found.id);
        this.audio.playDiscoveryChime();
      }
    }

    const nearBell = cp.distanceTo(this.bellPosition) < 28;
    if (nearBell !== this.wasNearBell) {
      this.wasNearBell = nearBell;
      this.callbacks.onBellNear?.(nearBell);
    }
  }

  private animate = () => {
    if (this.disposed || this.loopPaused) return;
    this.rafId = requestAnimationFrame(this.animate);

    this.timer.update();
    const dt = Math.min(0.05, this.timer.getDelta());
    this.elapsed += dt;

    this.updateBoats(this.elapsed);
    this.updateCameraAndMovement(dt);
    this.updateWind(this.elapsed);
    this.updateAtmos(this.elapsed, this.camera.position);
    this.updateParticles(dt, this.elapsed, this.camera.position);

    // Subtle bell oscillation after ringing Đại Hồng Chung
    if (this.bellSwingAmp > 0.001) {
      this.bellSwingPhase += dt * 4.2;
      this.bellMesh.rotation.x = Math.sin(this.bellSwingPhase) * this.bellSwingAmp;
      this.bellSwingAmp *= Math.exp(-dt * 0.45);
    } else {
      this.bellMesh.rotation.x = 0;
    }

    // Subtle candle flicker inside Cung Thiên Định
    this.interiorLights.forEach((pt, idx) => {
      const base = idx === 0 ? 5.2 : 6.4;
      const mult = this.currentAtmos === 'night' ? 1.35 : 1.0;
      pt.intensity =
        base *
        mult *
        (0.95 + 0.05 * Math.sin(this.elapsed * 7.5 + idx * 2.1));
    });

    this.checkLandmarksAndProximity();
    this.composer.render();
  };

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.rafId);
    this.cleanupListeners();
    this.composer.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
