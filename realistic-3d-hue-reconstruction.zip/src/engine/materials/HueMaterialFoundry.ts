import * as THREE from 'three';

function fract(v: number): number {
  return v - Math.floor(v);
}

function hash2D(x: number, y: number, seed = 1): number {
  const n = Math.sin(x * 127.1 + y * 311.7 + seed * 74.7) * 43758.5453123;
  return fract(n);
}

function tileableNoise(u: number, v: number, freq: number, seed = 1): number {
  const x = u * freq;
  const y = v * freq;
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);

  const x0 = ((ix % freq) + freq) % freq;
  const x1 = (x0 + 1) % freq;
  const y0 = ((iy % freq) + freq) % freq;
  const y1 = (y0 + 1) % freq;

  const a = hash2D(x0, y0, seed);
  const b = hash2D(x1, y0, seed);
  const c = hash2D(x0, y1, seed);
  const d = hash2D(x1, y1, seed);
  return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy;
}

function tileableFbm(u: number, v: number, baseFreq: number, octaves = 4, seed = 1): number {
  let sum = 0;
  let amp = 0.5;
  let freq = baseFreq;
  let norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += amp * tileableNoise(u, v, freq, seed + i * 17);
    norm += amp;
    amp *= 0.5;
    freq *= 2;
  }
  return sum / norm;
}

function clampByte(n: number): number {
  return Math.max(0, Math.min(255, Math.round(n)));
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function smoothstep(e0: number, e1: number, x: number): number {
  const t = Math.max(0, Math.min(1, (x - e0) / (e1 - e0)));
  return t * t * (3 - 2 * t);
}

interface PBRMaps {
  map: THREE.DataTexture;
  normalMap: THREE.DataTexture;
  roughnessMap: THREE.DataTexture;
}

function buildNormalFromHeight(
  height: Float32Array,
  size: number,
  strength: number,
): THREE.DataTexture {
  const data = new Uint8Array(size * size * 4);
  const sample = (x: number, y: number) => {
    const wx = ((x % size) + size) % size;
    const wy = ((y % size) + size) % size;
    return height[wy * size + wx];
  };

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const tl = sample(x - 1, y - 1);
      const t = sample(x, y - 1);
      const tr = sample(x + 1, y - 1);
      const l = sample(x - 1, y);
      const r = sample(x + 1, y);
      const bl = sample(x - 1, y + 1);
      const b = sample(x, y + 1);
      const br = sample(x + 1, y + 1);

      const dX = (tr + 2 * r + br) - (tl + 2 * l + bl);
      const dY = (bl + 2 * b + br) - (tl + 2 * t + tr);

      let nx = -dX * strength;
      let ny = -dY * strength;
      let nz = 1.0;
      const invLen = 1 / Math.hypot(nx, ny, nz);
      nx *= invLen;
      ny *= invLen;
      nz *= invLen;

      const idx = (y * size + x) * 4;
      data[idx] = clampByte((nx * 0.5 + 0.5) * 255);
      data[idx + 1] = clampByte((ny * 0.5 + 0.5) * 255);
      data[idx + 2] = clampByte((nz * 0.5 + 0.5) * 255);
      data[idx + 3] = 255;
    }
  }

  const tex = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.NoColorSpace;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.generateMipmaps = true;
  tex.needsUpdate = true;
  return tex;
}

function finalizeTexture(
  data: Uint8Array,
  size: number,
  srgb: boolean,
  repeatX = 1,
  repeatY = 1,
): THREE.DataTexture {
  const tex = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.generateMipmaps = true;
  tex.anisotropy = 8;
  tex.needsUpdate = true;
  return tex;
}

function makeMaps(
  size: number,
  normalStrength: number,
  repeatX: number,
  repeatY: number,
  sampler: (
    u: number,
    v: number,
  ) => { r: number; g: number; b: number; h: number; rough: number },
): PBRMaps {
  const albedo = new Uint8Array(size * size * 4);
  const roughData = new Uint8Array(size * size * 4);
  const height = new Float32Array(size * size);

  for (let y = 0; y < size; y++) {
    const v = y / size;
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const res = sampler(u, v);
      const i = y * size + x;
      const idx = i * 4;
      height[i] = res.h;
      albedo[idx] = clampByte(res.r);
      albedo[idx + 1] = clampByte(res.g);
      albedo[idx + 2] = clampByte(res.b);
      albedo[idx + 3] = 255;

      const rv = clampByte(res.rough * 255);
      roughData[idx] = rv;
      roughData[idx + 1] = rv;
      roughData[idx + 2] = rv;
      roughData[idx + 3] = 255;
    }
  }

  const map = finalizeTexture(albedo, size, true, repeatX, repeatY);
  const roughnessMap = finalizeTexture(roughData, size, false, repeatX, repeatY);
  const normalMap = buildNormalFromHeight(height, size, normalStrength);
  normalMap.repeat.set(repeatX, repeatY);
  normalMap.anisotropy = 8;
  return { map, normalMap, roughnessMap };
}

export interface HueMaterialSet {
  // Chùa Thiên Mụ materials
  hueBrick: THREE.MeshStandardMaterial;
  hueLimeRose: THREE.MeshStandardMaterial;
  hueLimeWall: THREE.MeshStandardMaterial;
  phapLamJade: THREE.MeshPhysicalMaterial;
  phapLamCobalt: THREE.MeshPhysicalMaterial;
  ngoiTerracotta: THREE.MeshStandardMaterial;

  // Lăng Tự Đức & Cầu Ngói & Nhà Rường materials
  ngoiLuuLyGold: THREE.MeshPhysicalMaterial;
  ngoiLuuLyGreen: THREE.MeshPhysicalMaterial;
  goLimAged: THREE.MeshStandardMaterial;
  goLimLacquered: THREE.MeshPhysicalMaterial;
  sonSonThepVang: THREE.MeshPhysicalMaterial;

  // Stone & Masonry
  daThanh: THREE.MeshStandardMaterial;
  daThanhStairs: THREE.MeshStandardMaterial;
  daHocMortar: THREE.MeshStandardMaterial;

  // Lăng Khải Định materials
  khaiDinhConcrete: THREE.MeshStandardMaterial;
  khaiDinhRelief: THREE.MeshStandardMaterial;
  khaiDinhDarkTrim: THREE.MeshStandardMaterial;
  porcelainMosaicWall: THREE.MeshPhysicalMaterial;
  porcelainMosaicWallWide: THREE.MeshPhysicalMaterial;
  porcelainMosaicBuuTan: THREE.MeshPhysicalMaterial;
  porcelainMosaicCeiling: THREE.MeshPhysicalMaterial;
  marbleTileFloor: THREE.MeshPhysicalMaterial;
  giltBronze: THREE.MeshStandardMaterial;
  antiqueBronzeBell: THREE.MeshStandardMaterial;

  // Cầu Trường Tiền & Village
  eiffelSilverSteel: THREE.MeshStandardMaterial;
  eiffelWroughtIron: THREE.MeshStandardMaterial;
  ochreVillagePlaster: THREE.MeshStandardMaterial;
  bambooWoven: THREE.MeshStandardMaterial;

  // Utility dynamic weather hook
  setRainWetness: (wetness: number) => void;
}

export function createHueMaterialFoundry(): HueMaterialSet {
  const disposableTextures: THREE.Texture[] = [];
  const track = (maps: PBRMaps) => {
    disposableTextures.push(maps.map, maps.normalMap, maps.roughnessMap);
    return maps;
  };

  // 1. Gạch Vồ Cổ Chùa Thiên Mụ (512x512)
  const brickMaps = track(
    makeMaps(512, 3.6, 2, 2, (u, v) => {
      const cols = 6;
      const rows = 14;
      const gy = v * rows;
      const row = Math.floor(gy);
      const fy = gy - row;
      const gx = u * cols + (row % 2) * 0.5;
      const col = Math.floor(gx);
      const fx = gx - col;

      const mortarX = smoothstep(0.0, 0.06, fx) * (1 - smoothstep(0.94, 1.0, fx));
      const mortarY = smoothstep(0.0, 0.11, fy) * (1 - smoothstep(0.89, 1.0, fy));
      const brickMask = mortarX * mortarY;

      const idHash = hash2D(((col % cols) + cols) % cols, row % rows, 11);
      const grain = tileableFbm(u, v, 16, 4, 21);
      const fine = tileableFbm(u, v, 64, 3, 47);
      const rainStreak = tileableFbm(u * 2.5, v * 0.35, 8, 3, 73);
      const moss = smoothstep(0.57, 0.78, tileableFbm(u, v, 6, 4, 93) + (1 - brickMask) * 0.18);

      // Authentic weathered brown-terracotta brick palette from thien_mu.jpg
      let br = 128 + (idHash - 0.5) * 42 + (grain - 0.5) * 34;
      let bg = 82 + (idHash - 0.5) * 26 + (grain - 0.5) * 24;
      let bb = 68 + (idHash - 0.5) * 18 + (grain - 0.5) * 18;

      // Kiln soot patches
      if (idHash > 0.78) {
        br *= 0.72;
        bg *= 0.72;
        bb *= 0.74;
      }

      // Pale lime mortar
      const mr = 166 + (fine - 0.5) * 22;
      const mg = 158 + (fine - 0.5) * 20;
      const mb = 144 + (fine - 0.5) * 18;

      let r = lerp(mr, br, brickMask);
      let g = lerp(mg, bg, brickMask);
      let b = lerp(mb, bb, brickMask);

      // Vertical tropical weathering stain
      const stain = smoothstep(0.45, 0.82, rainStreak);
      r *= 1 - stain * 0.25;
      g *= 1 - stain * 0.23;
      b *= 1 - stain * 0.22;

      // Olive moss patina
      r = lerp(r, 64, moss * 0.65);
      g = lerp(g, 79, moss * 0.65);
      b = lerp(b, 44, moss * 0.65);

      const h = brickMask * (0.65 + (grain - 0.5) * 0.22 + (fine - 0.5) * 0.14);
      const rough = lerp(0.94, 0.78 + (fine - 0.5) * 0.12, brickMask);
      return { r, g, b, h, rough: Math.min(0.98, rough + moss * 0.1) };
    }),
  );

  // 2. Vôi Vữa Hồng Phai (Tháp Phước Duyên frames)
  const limeRoseMaps = track(
    makeMaps(512, 2.2, 1, 1, (u, v) => {
      const f = tileableFbm(u, v, 8, 4, 31);
      const f2 = tileableFbm(u, v, 32, 3, 59);
      const crack = 1 - smoothstep(0.0, 0.04, Math.abs(tileableFbm(u, v, 12, 3, 81) - 0.5));
      const darkMoss = smoothstep(0.62, 0.82, tileableFbm(u, v, 6, 4, 99));

      let r = 186 + (f - 0.5) * 34 - crack * 45;
      let g = 132 + (f - 0.5) * 26 - crack * 35;
      let b = 122 + (f - 0.5) * 24 - crack * 30;

      r = lerp(r, 72, darkMoss * 0.72);
      g = lerp(g, 82, darkMoss * 0.72);
      b = lerp(b, 58, darkMoss * 0.72);

      return {
        r,
        g,
        b,
        h: 0.5 + (f2 - 0.5) * 0.35 - crack * 0.25,
        rough: 0.86 + (f2 - 0.5) * 0.08,
      };
    }),
  );

  // 3. Tường Vôi Vữa Cổ (Chùa & Nhà Vườn)
  const limeWallMaps = track(
    makeMaps(512, 2.4, 2, 2, (u, v) => {
      const n1 = tileableFbm(u, v, 6, 4, 15);
      const n2 = tileableFbm(u, v, 24, 3, 39);
      const drip = tileableFbm(u * 2, v * 0.25, 6, 3, 62);
      const mossBottom = smoothstep(0.15, 0.65, 1 - v) * smoothstep(0.35, 0.72, n1);

      let r = 194 + (n1 - 0.5) * 28 - drip * 26;
      let g = 186 + (n1 - 0.5) * 26 - drip * 24;
      let b = 166 + (n1 - 0.5) * 24 - drip * 25;

      r = lerp(r, 68, mossBottom * 0.78);
      g = lerp(g, 84, mossBottom * 0.78);
      b = lerp(b, 48, mossBottom * 0.78);

      return { r, g, b, h: 0.5 + (n2 - 0.5) * 0.4, rough: 0.88 };
    }),
  );

  // 4. Pháp Lam Men Ngọc & Men Chàm (Tháp Phước Duyên plaques & Cù Dao)
  const buildPhapLam = (baseR: number, baseG: number, baseB: number, seed: number) =>
    track(
      makeMaps(256, 2.5, 1, 1, (u, v) => {
        const border =
          u < 0.09 || u > 0.91 || v < 0.09 || v > 0.91
            ? 1
            : u < 0.13 || u > 0.87 || v < 0.13 || v > 0.87
              ? 0.5
              : 0;
        const swirl = Math.sin(u * Math.PI * 6) * Math.cos(v * Math.PI * 6);
        const craze = 1 - smoothstep(0.0, 0.035, Math.abs(tileableFbm(u, v, 14, 3, seed) - 0.5));
        const sheen = tileableFbm(u, v, 10, 3, seed + 5);

        let r = baseR + (sheen - 0.5) * 26;
        let g = baseG + (sheen - 0.5) * 26;
        let b = baseB + (sheen - 0.5) * 24;

        // Gilt floral / dragon border motif
        if (border > 0.7) {
          r = 188;
          g = 152;
          b = 78;
        } else if (border > 0.3) {
          r = 228;
          g = 216;
          b = 186;
        } else if (Math.abs(swirl) > 0.72) {
          r = lerp(r, 220, 0.4);
          g = lerp(g, 206, 0.4);
          b = lerp(b, 165, 0.4);
        }

        // Subtle enamel crazing
        r -= craze * 18;
        g -= craze * 18;
        b -= craze * 16;

        return {
          r,
          g,
          b,
          h: 0.5 + border * 0.25 + (swirl > 0.7 ? 0.15 : 0) - craze * 0.1,
          rough: border > 0.7 ? 0.32 : 0.18 + craze * 0.22,
        };
      }),
    );

  const phapLamJadeMaps = buildPhapLam(62, 134, 128, 107);
  const phapLamCobaltMaps = buildPhapLam(38, 78, 138, 119);

  // 5. Ngói Ống Lưu Ly & Ngói Âm Dương (Cylindrical Ribbed Roof Tiles!)
  const buildTileMaps = (
    r0: number,
    g0: number,
    b0: number,
    glazed: boolean,
    repeatX: number,
    repeatY: number,
    seed: number,
  ) =>
    track(
      makeMaps(512, 4.4, repeatX, repeatY, (u, v) => {
        const ribs = 10;
        const courses = 8;
        const rx = u * ribs;
        const ribIdx = Math.floor(rx);
        const fx = rx - ribIdx;
        // Semi-cylindrical rib profile: ridge at fx=0.5, trough at fx=0/1
        const cyl = Math.sin(fx * Math.PI);
        const cy = v * courses;
        const courseIdx = Math.floor(cy);
        const fy = cy - courseIdx;
        // Stepped tile overlap lip at fy ~ 0
        const lip = smoothstep(0.0, 0.12, fy);

        const tileHash = hash2D(ribIdx % ribs, courseIdx % courses, seed);
        const grain = tileableFbm(u, v, 24, 3, seed + 13);
        const moss = smoothstep(
          0.56,
          0.84,
          tileableFbm(u, v, 6, 4, seed + 29) + (1 - cyl) * 0.28,
        );

        let r = r0 + (tileHash - 0.5) * 28 + (grain - 0.5) * 18;
        let g = g0 + (tileHash - 0.5) * 22 + (grain - 0.5) * 16;
        let b = b0 + (tileHash - 0.5) * 16 + (grain - 0.5) * 14;

        // Trough shadow & drip edge darkening
        const troughShade = 0.62 + 0.38 * cyl;
        const lipShade = 0.72 + 0.28 * lip;
        r *= troughShade * lipShade;
        g *= troughShade * lipShade;
        b *= troughShade * lipShade;

        // Tropical moss inside tile valleys
        r = lerp(r, 56, moss * 0.65);
        g = lerp(g, 74, moss * 0.65);
        b = lerp(b, 42, moss * 0.65);

        const h = cyl * 0.65 + (1 - fy) * 0.35;
        const baseRough = glazed ? 0.22 + (1 - cyl) * 0.25 : 0.78;
        return { r, g, b, h, rough: lerp(baseRough, 0.92, moss * 0.85) };
      }),
    );

  const ngoiGoldMaps = buildTileMaps(204, 114, 32, true, 4, 2, 201); // Hoàng Lưu Ly (Lăng Tự Đức)
  const ngoiGreenMaps = buildTileMaps(44, 112, 86, true, 4, 2, 211); // Thanh Lưu Ly (Cầu Ngói)
  const ngoiTerraMaps = buildTileMaps(118, 68, 52, false, 3, 2, 223); // Ngói đất nung cổ (Thiên Mụ)

  // 6. Gỗ Lim Huế (Anisotropic aged dark ironwood)
  const goLimMaps = track(
    makeMaps(512, 2.6, 1, 2, (u, v) => {
      const fiber = tileableFbm(u * 6, v * 0.5, 8, 4, 307);
      const ring = Math.sin((u * 14 + fiber * 2.5) * Math.PI * 2) * 0.5 + 0.5;
      const fine = tileableFbm(u * 12, v, 16, 3, 317);

      const r = 68 + ring * 22 + (fine - 0.5) * 14;
      const g = 46 + ring * 16 + (fine - 0.5) * 10;
      const b = 34 + ring * 11 + (fine - 0.5) * 8;

      return {
        r,
        g,
        b,
        h: 0.5 + ring * 0.3 + (fine - 0.5) * 0.2,
        rough: 0.56 + (1 - ring) * 0.18,
      };
    }),
  );

  // 7. Đá Thanh Huế (Sedimentary bluish-grey chisel-cut stone)
  const daThanhMaps = track(
    makeMaps(512, 2.8, 2, 2, (u, v) => {
      const f1 = tileableFbm(u, v, 8, 4, 401);
      const f2 = tileableFbm(u, v, 32, 3, 409);
      const strata = tileableFbm(u * 0.5, v * 3, 8, 3, 419);
      const lichen = smoothstep(0.68, 0.88, tileableFbm(u, v, 10, 4, 431));
      const moss = smoothstep(0.64, 0.85, tileableFbm(u, v, 6, 4, 443));

      let r = 108 + (f1 - 0.5) * 26 + (strata - 0.5) * 16;
      let g = 113 + (f1 - 0.5) * 26 + (strata - 0.5) * 16;
      let b = 116 + (f1 - 0.5) * 24 + (strata - 0.5) * 14;

      // Pale grey-cream lichen flecks
      r = lerp(r, 174, lichen * 0.55);
      g = lerp(g, 172, lichen * 0.55);
      b = lerp(b, 152, lichen * 0.55);

      // Damp olive moss
      r = lerp(r, 62, moss * 0.62);
      g = lerp(g, 76, moss * 0.62);
      b = lerp(b, 46, moss * 0.62);

      return {
        r,
        g,
        b,
        h: 0.5 + (f1 - 0.5) * 0.3 + (f2 - 0.5) * 0.25,
        rough: lerp(0.66, 0.9, moss * 0.7),
      };
    }),
  );

  // 8. Đá Hộc Viền Vữa (Polygonal rubble masonry from khai_dinh.jpg & Hồ Lưu Khiêm walls)
  const daHocMaps = track(
    makeMaps(512, 3.6, 3, 2, (u, v) => {
      const grid = 7;
      const gu = u * grid;
      const gv = v * grid;
      const cu = Math.floor(gu);
      const cv = Math.floor(gv);

      let minD1 = 99;
      let minD2 = 99;
      let cellHash = 0;

      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          const nu = (((cu + dx) % grid) + grid) % grid;
          const nv = (((cv + dy) % grid) + grid) % grid;
          const jx = cu + dx + 0.2 + 0.6 * hash2D(nu, nv, 501);
          const jy = cv + dy + 0.2 + 0.6 * hash2D(nu, nv, 509);
          const dist = Math.hypot(gu - jx, gv - jy);
          if (dist < minD1) {
            minD2 = minD1;
            minD1 = dist;
            cellHash = hash2D(nu, nv, 521);
          } else if (dist < minD2) {
            minD2 = dist;
          }
        }
      }

      const edge = minD2 - minD1;
      const stoneMask = smoothstep(0.022, 0.058, edge);
      const grain = tileableFbm(u, v, 28, 4, 541);
      const soot = smoothstep(0.3, 0.78, tileableFbm(u, v, 8, 4, 547));
      const moss = smoothstep(0.58, 0.84, tileableFbm(u, v, 6, 4, 563));

      // Natural weathered bluish-charcoal stone blocks with subdued lime mortar
      let sr = 78 + (cellHash - 0.5) * 24 + (grain - 0.5) * 18 - soot * 14;
      let sg = 80 + (cellHash - 0.5) * 20 + (grain - 0.5) * 16 - soot * 12;
      let sb = 78 + (cellHash - 0.5) * 18 + (grain - 0.5) * 14 - soot * 10;

      sr = lerp(sr, 56, moss * 0.52);
      sg = lerp(sg, 72, moss * 0.52);
      sb = lerp(sb, 46, moss * 0.52);

      const mr = 114 + (grain - 0.5) * 16 - soot * 16;
      const mg = 112 + (grain - 0.5) * 14 - soot * 14;
      const mb = 104 + (grain - 0.5) * 14 - soot * 12;

      return {
        r: lerp(mr, sr, stoneMask),
        g: lerp(mg, sg, stoneMask),
        b: lerp(mb, sb, stoneMask),
        h: stoneMask * (0.74 + (grain - 0.5) * 0.24),
        rough: lerp(0.92, 0.78, stoneMask),
      };
    }),
  );

  // 9. Bê Tông Rêu Đen Lăng Khải Định (Balanced weathered charcoal limestone patina)
  const khaiDinhMaps = track(
    makeMaps(512, 2.6, 2, 2, (u, v) => {
      const f1 = tileableFbm(u, v, 8, 4, 601);
      const f2 = tileableFbm(u, v, 28, 4, 607);
      const f3 = tileableFbm(u, v, 14, 3, 613);
      const patina = smoothstep(0.32, 0.74, f1 * 0.65 + f3 * 0.35);

      const r = lerp(136, 72, patina) + (f2 - 0.5) * 16;
      const g = lerp(134, 73, patina) + (f2 - 0.5) * 16;
      const b = lerp(128, 70, patina) + (f2 - 0.5) * 15;

      return {
        r,
        g,
        b,
        h: 0.5 + (f2 - 0.5) * 0.3 + (1 - patina) * 0.12,
        rough: lerp(0.76, 0.94, patina),
      };
    }),
  );

  // 10. Phù Điêu Rồng Mây Lăng Khải Định (Refined grey carved limestone relief, isotropic grain)
  const khaiDinhReliefMaps = track(
    makeMaps(512, 3.6, 1, 1, (u, v) => {
      const warpX = tileableFbm(u, v, 6, 3, 619) * 0.28;
      const warpY = tileableFbm(u + 0.3, v + 0.7, 6, 3, 629) * 0.28;
      const carving = tileableFbm(u + warpX, v + warpY, 12, 4, 631);
      const micro = tileableFbm(u, v, 32, 3, 641);
      const ridge = smoothstep(0.36, 0.68, carving);
      const mold = smoothstep(0.32, 0.75, (1 - ridge) * 0.6 + micro * 0.4);

      const r = lerp(142, 66, mold) + (micro - 0.5) * 14;
      const g = lerp(140, 68, mold) + (micro - 0.5) * 14;
      const b = lerp(134, 65, mold) + (micro - 0.5) * 14;

      return {
        r,
        g,
        b,
        h: ridge * 0.68 + (micro - 0.5) * 0.2,
        rough: lerp(0.72, 0.94, mold),
      };
    }),
  );

  // 11. Nghệ Thuật Khảm Sành Sứ & Thủy Tinh Màu (Cung Thiên Định Crown Jewel!)
  const buildPorcelainMosaic = (
    mode: 'wall' | 'wallWide' | 'buutan' | 'ceiling',
  ) =>
    track(
      makeMaps(
        512,
        3.8,
        mode === 'wallWide' ? 6 : mode === 'wall' ? 2 : 1,
        mode === 'wallWide' ? 2 : mode === 'wall' ? 2 : 1,
        (u, v) => {
          const cells = mode === 'buutan' ? 22 : 26;
          const gu = u * cells;
          const gv = v * cells;
          const cu = Math.floor(gu);
          const cv = Math.floor(gv);

          let minD1 = 99;
          let minD2 = 99;
          let bestSeed = 0;
          let tiltX = 0;
          let tiltY = 0;

          for (let dy = -1; dy <= 1; dy++) {
            for (let dx = -1; dx <= 1; dx++) {
              const nu = (((cu + dx) % cells) + cells) % cells;
              const nv = (((cv + dy) % cells) + cells) % cells;
              const jx = cu + dx + 0.18 + 0.64 * hash2D(nu, nv, 701);
              const jy = cv + dy + 0.18 + 0.64 * hash2D(nu, nv, 709);
              const dist = Math.hypot(gu - jx, gv - jy);
              if (dist < minD1) {
                minD2 = minD1;
                minD1 = dist;
                bestSeed = hash2D(nu, nv, 719);
                tiltX = hash2D(nu, nv, 727) - 0.5;
                tiltY = hash2D(nu, nv, 733) - 0.5;
              } else if (dist < minD2) {
                minD2 = dist;
              }
            }
          }

          const edge = minD2 - minD1;
          const shardMask = smoothstep(0.04, 0.1, edge);

          // Ornamental floral/dragon color zones using warped organic curves
          const warp = tileableFbm(u, v, 4, 3, 743) * 0.45;
          const motif =
            Math.sin((u + warp) * Math.PI * 4) * Math.cos((v + warp) * Math.PI * 4);
          const borderBand =
            u < 0.07 || u > 0.93 || v < 0.07 || v > 0.93;

          let sr = 198;
          let sg = 190;
          let sb = 175;

          if (mode === 'buutan') {
            const fold = Math.sin(u * Math.PI * 10 + v * 2.2);
            if (fold > 0.42) {
              sr = 212;
              sg = 158;
              sb = 42;
            } else if (fold > -0.1) {
              sr = 26;
              sg = 124;
              sb = 92;
            } else if (fold > -0.55) {
              sr = 164;
              sg = 38;
              sb = 36;
            } else {
              sr = 34;
              sg = 74;
              sb = 166;
            }
          } else if (mode === 'ceiling') {
            const cloud = tileableFbm(u, v, 5, 4, 751);
            if (Math.abs(motif) > 0.36) {
              sr = 194;
              sg = 148;
              sb = 52;
            } else if (cloud > 0.5) {
              sr = 58;
              sg = 88;
              sb = 118;
            } else {
              sr = 32;
              sg = 40;
              sb = 58;
            }
          } else {
            if (borderBand) {
              sr = 186;
              sg = 132;
              sb = 38;
            } else if (motif > 0.3) {
              // Deep emerald & celadon porcelain
              sr = 24 + bestSeed * 24;
              sg = 118 + bestSeed * 36;
              sb = 82 + bestSeed * 24;
            } else if (motif < -0.28) {
              // Deep cobalt & Ming sapphire porcelain
              sr = 24 + bestSeed * 20;
              sg = 58 + bestSeed * 26;
              sb = 156 + bestSeed * 40;
            } else if (bestSeed > 0.76) {
              // Ruby & coral cinnabar glass
              sr = 168;
              sg = 38;
              sb = 36;
            } else if (bestSeed > 0.55) {
              // Imperial ochre amber
              sr = 198;
              sg = 144;
              sb = 42;
            } else {
              // Warm antique ivory / crackle ceramic
              sr = 198 + (bestSeed - 0.3) * 24;
              sg = 190 + (bestSeed - 0.3) * 24;
              sb = 172 + (bestSeed - 0.3) * 22;
            }
          }

          // Darker recessed lime mortar grout so ceramic shards pop vividly
          const groutR = 78;
          const groutG = 72;
          const groutB = 64;

          const lx = ((gu - cu) - 0.5) * tiltX;
          const ly = ((gv - cv) - 0.5) * tiltY;
          const shardH = 0.68 + bestSeed * 0.2 + lx * 0.32 + ly * 0.32;

          return {
            r: lerp(groutR, sr, shardMask),
            g: lerp(groutG, sg, shardMask),
            b: lerp(groutB, sb, shardMask),
            h: shardMask * shardH,
            rough: lerp(0.92, 0.16 + bestSeed * 0.1, shardMask),
          };
        },
      ),
    );

  const mosaicWallMaps = buildPorcelainMosaic('wall');
  const mosaicWallWideMaps = buildPorcelainMosaic('wallWide');
  const mosaicBuuTanMaps = buildPorcelainMosaic('buutan');
  const mosaicCeilingMaps = buildPorcelainMosaic('ceiling');

  // 12. Đá Hoa Cẩm Thạch Cung Thiên Định (Checkered colonial-imperial marble tile floor)
  const marbleMaps = track(
    makeMaps(512, 1.5, 5, 5, (u, v) => {
      const n = 4;
      const ix = Math.floor(u * n);
      const iy = Math.floor(v * n);
      const fx = u * n - ix;
      const fy = v * n - iy;
      const grout = smoothstep(0.0, 0.03, fx) * (1 - smoothstep(0.97, 1.0, fx)) *
        smoothstep(0.0, 0.03, fy) * (1 - smoothstep(0.97, 1.0, fy));
      const checker = (ix + iy) % 2 === 0;
      const vein = smoothstep(0.42, 0.54, tileableFbm(u * 2, v * 2, 6, 4, 809));
      const base = checker ? 216 : 64;
      const accent = checker ? 168 : 112;
      const val = lerp(base, accent, vein * 0.45);
      return {
        r: lerp(95, val, grout),
        g: lerp(92, val * 0.98, grout),
        b: lerp(88, val * 0.94, grout),
        h: grout * 0.7,
        rough: lerp(0.75, 0.24, grout),
      };
    }),
  );

  // 13. Thép Nhũ Bạc Đinh Tán Cầu Trường Tiền
  const steelMaps = track(
    makeMaps(256, 2.2, 2, 1, (u, v) => {
      const f = tileableFbm(u, v, 12, 3, 907);
      const rust = smoothstep(0.68, 0.9, tileableFbm(u, v, 8, 4, 919));
      const rivetX = Math.abs((u * 8) % 1 - 0.5);
      const rivetY = Math.abs((v * 4) % 1 - 0.5);
      const rivet = 1 - smoothstep(0.1, 0.2, Math.hypot(rivetX, rivetY));

      let r = 178 + (f - 0.5) * 24 + rivet * 18;
      let g = 182 + (f - 0.5) * 24 + rivet * 18;
      let b = 186 + (f - 0.5) * 22 + rivet * 16;

      r = lerp(r, 128, rust * 0.55);
      g = lerp(g, 82, rust * 0.55);
      b = lerp(b, 58, rust * 0.55);

      return {
        r,
        g,
        b,
        h: 0.45 + rivet * 0.45 + (f - 0.5) * 0.1,
        rough: lerp(0.38, 0.82, rust),
      };
    }),
  );

  // 14. Vôi Vàng Làng Quê & Mây Tre Đan
  const ochreMaps = track(
    makeMaps(256, 2.0, 1, 1, (u, v) => {
      const f = tileableFbm(u, v, 8, 4, 953);
      const moss = smoothstep(0.66, 0.88, f);
      return {
        r: lerp(218 + (f - 0.5) * 28, 86, moss * 0.6),
        g: lerp(176 + (f - 0.5) * 22, 92, moss * 0.6),
        b: lerp(102 + (f - 0.5) * 18, 54, moss * 0.6),
        h: 0.5 + (f - 0.5) * 0.25,
        rough: 0.86,
      };
    }),
  );

  const bambooMaps = track(
    makeMaps(256, 3.0, 3, 2, (u, v) => {
      const wx = Math.floor(u * 12);
      const wy = Math.floor(v * 12);
      const fx = u * 12 - wx;
      const fy = v * 12 - wy;
      const over = (wx + wy) % 2 === 0;
      const strip = over ? Math.sin(fx * Math.PI) : Math.sin(fy * Math.PI);
      const f = tileableFbm(u, v, 16, 2, 977);
      return {
        r: 138 * (0.65 + 0.35 * strip) + (f - 0.5) * 20,
        g: 106 * (0.65 + 0.35 * strip) + (f - 0.5) * 16,
        b: 64 * (0.65 + 0.35 * strip) + (f - 0.5) * 12,
        h: strip * 0.7 + 0.15,
        rough: 0.72,
      };
    }),
  );

  // Instantiate calibrated Materials
  const hueBrick = new THREE.MeshStandardMaterial({
    ...brickMaps,
    normalScale: new THREE.Vector2(1.15, 1.15),
  });
  const hueLimeRose = new THREE.MeshStandardMaterial({
    ...limeRoseMaps,
    normalScale: new THREE.Vector2(0.85, 0.85),
  });
  const hueLimeWall = new THREE.MeshStandardMaterial({
    ...limeWallMaps,
    normalScale: new THREE.Vector2(0.9, 0.9),
  });
  const phapLamJade = new THREE.MeshPhysicalMaterial({
    ...phapLamJadeMaps,
    clearcoat: 0.9,
    clearcoatRoughness: 0.14,
    normalScale: new THREE.Vector2(0.8, 0.8),
  });
  const phapLamCobalt = new THREE.MeshPhysicalMaterial({
    ...phapLamCobaltMaps,
    clearcoat: 0.92,
    clearcoatRoughness: 0.12,
    normalScale: new THREE.Vector2(0.8, 0.8),
  });
  const ngoiTerracotta = new THREE.MeshStandardMaterial({
    ...ngoiTerraMaps,
    normalScale: new THREE.Vector2(1.35, 1.35),
  });
  const ngoiLuuLyGold = new THREE.MeshPhysicalMaterial({
    ...ngoiGoldMaps,
    clearcoat: 0.52,
    clearcoatRoughness: 0.28,
    envMapIntensity: 0.62,
    normalScale: new THREE.Vector2(1.45, 1.45),
  });
  const ngoiLuuLyGreen = new THREE.MeshPhysicalMaterial({
    ...ngoiGreenMaps,
    clearcoat: 0.55,
    clearcoatRoughness: 0.26,
    envMapIntensity: 0.62,
    normalScale: new THREE.Vector2(1.45, 1.45),
  });
  const goLimAged = new THREE.MeshStandardMaterial({
    ...goLimMaps,
    normalScale: new THREE.Vector2(0.9, 0.9),
  });
  const goLimLacquered = new THREE.MeshPhysicalMaterial({
    color: 0x5c1a16,
    roughness: 0.34,
    clearcoat: 0.72,
    clearcoatRoughness: 0.18,
    normalMap: goLimMaps.normalMap,
    normalScale: new THREE.Vector2(0.55, 0.55),
  });
  const sonSonThepVang = new THREE.MeshPhysicalMaterial({
    color: 0xd9a842,
    metalness: 0.78,
    roughness: 0.28,
    clearcoat: 0.6,
    normalMap: khaiDinhReliefMaps.normalMap,
    normalScale: new THREE.Vector2(0.8, 0.8),
  });
  const daThanh = new THREE.MeshStandardMaterial({
    ...daThanhMaps,
    normalScale: new THREE.Vector2(1.05, 1.05),
  });
  const daThanhStairs = new THREE.MeshStandardMaterial({
    ...daThanhMaps,
    roughness: 0.82,
    normalScale: new THREE.Vector2(1.15, 1.15),
  });
  const daHocMortar = new THREE.MeshStandardMaterial({
    ...daHocMaps,
    normalScale: new THREE.Vector2(1.45, 1.45),
  });
  const khaiDinhConcrete = new THREE.MeshStandardMaterial({
    ...khaiDinhMaps,
    normalScale: new THREE.Vector2(1.2, 1.2),
  });
  const khaiDinhRelief = new THREE.MeshStandardMaterial({
    ...khaiDinhReliefMaps,
    normalScale: new THREE.Vector2(1.55, 1.55),
  });
  const khaiDinhDarkTrim = new THREE.MeshStandardMaterial({
    color: 0x3b3d3a,
    roughness: 0.88,
    normalMap: khaiDinhMaps.normalMap,
    normalScale: new THREE.Vector2(1.0, 1.0),
  });
  const porcelainMosaicWall = new THREE.MeshPhysicalMaterial({
    ...mosaicWallMaps,
    clearcoat: 0.9,
    clearcoatRoughness: 0.14,
    envMapIntensity: 0.65,
    normalScale: new THREE.Vector2(1.35, 1.35),
  });
  const porcelainMosaicWallWide = new THREE.MeshPhysicalMaterial({
    ...mosaicWallWideMaps,
    clearcoat: 0.9,
    clearcoatRoughness: 0.14,
    envMapIntensity: 0.65,
    normalScale: new THREE.Vector2(1.35, 1.35),
  });
  const porcelainMosaicBuuTan = new THREE.MeshPhysicalMaterial({
    ...mosaicBuuTanMaps,
    clearcoat: 0.95,
    clearcoatRoughness: 0.1,
    envMapIntensity: 0.72,
    normalScale: new THREE.Vector2(1.4, 1.4),
  });
  const porcelainMosaicCeiling = new THREE.MeshPhysicalMaterial({
    ...mosaicCeilingMaps,
    clearcoat: 0.7,
    clearcoatRoughness: 0.22,
    envMapIntensity: 0.55,
    normalScale: new THREE.Vector2(1.1, 1.1),
  });
  const marbleTileFloor = new THREE.MeshPhysicalMaterial({
    ...marbleMaps,
    clearcoat: 0.65,
    clearcoatRoughness: 0.2,
    normalScale: new THREE.Vector2(0.55, 0.55),
  });
  const giltBronze = new THREE.MeshStandardMaterial({
    color: 0xd6a442,
    metalness: 0.88,
    roughness: 0.26,
  });
  const antiqueBronzeBell = new THREE.MeshStandardMaterial({
    color: 0x4b4232,
    metalness: 0.72,
    roughness: 0.42,
    normalMap: khaiDinhReliefMaps.normalMap,
    normalScale: new THREE.Vector2(0.6, 0.6),
  });
  const eiffelSilverSteel = new THREE.MeshStandardMaterial({
    ...steelMaps,
    metalness: 0.72,
    roughness: 0.44,
    normalScale: new THREE.Vector2(0.95, 0.95),
  });
  const eiffelWroughtIron = new THREE.MeshStandardMaterial({
    color: 0x3a4046,
    metalness: 0.68,
    roughness: 0.5,
  });
  const ochreVillagePlaster = new THREE.MeshStandardMaterial({
    ...ochreMaps,
    normalScale: new THREE.Vector2(0.85, 0.85),
  });
  const bambooWoven = new THREE.MeshStandardMaterial({
    ...bambooMaps,
    normalScale: new THREE.Vector2(1.0, 1.0),
  });

  const porousMats: THREE.MeshStandardMaterial[] = [
    hueBrick,
    hueLimeRose,
    hueLimeWall,
    ngoiTerracotta,
    daThanh,
    daThanhStairs,
    daHocMortar,
    khaiDinhConcrete,
    khaiDinhRelief,
    ochreVillagePlaster,
  ];

  const setRainWetness = (wetness: number) => {
    const w = Math.max(0, Math.min(1, wetness));
    for (const m of porousMats) {
      // Damp Hue stone & terracotta becomes subtly richer and glossier in drizzle
      m.roughness = lerp(1.0, 0.48, w);
      m.envMapIntensity = lerp(0.85, 1.65, w);
    }
    eiffelSilverSteel.roughness = lerp(0.44, 0.24, w);
  };

  return {
    hueBrick,
    hueLimeRose,
    hueLimeWall,
    phapLamJade,
    phapLamCobalt,
    ngoiTerracotta,
    ngoiLuuLyGold,
    ngoiLuuLyGreen,
    goLimAged,
    goLimLacquered,
    sonSonThepVang,
    daThanh,
    daThanhStairs,
    daHocMortar,
    khaiDinhConcrete,
    khaiDinhRelief,
    khaiDinhDarkTrim,
    porcelainMosaicWall,
    porcelainMosaicWallWide,
    porcelainMosaicBuuTan,
    porcelainMosaicCeiling,
    marbleTileFloor,
    giltBronze,
    antiqueBronzeBell,
    eiffelSilverSteel,
    eiffelWroughtIron,
    ochreVillagePlaster,
    bambooWoven,
    setRainWetness,
  };
}
