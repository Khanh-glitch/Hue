# Hẻm 12 – Khu dân cư Việt Nam 3D (React + Vite + three.js)

Thế giới 3D thời gian thực, đi bộ góc nhìn thứ nhất: phố, hẻm bê tông, sân chung, nhà ống nhiều tầng, quán xá, nội thất, cư dân sinh hoạt theo giờ, ngày/đêm, mưa, âm thanh tổng hợp. Hình học, âm thanh và phần lớn bề mặt sinh bằng code; bộ texture PBR quét thật (CC0) nằm trong `src/assets/tex`.

## Vòng nâng cấp này: từ "3D dựng bằng máy" sang "vật chất có thật"

Cách làm: dựng trình duyệt headless, đi vào phố, hẻm, bếp, phòng ngủ, chụp, tìm chỗ còn giả, truy nguyên nhân, sửa, chụp lại. Ảnh nằm trong `evidence/` (`00_before_*` trước, `01/02_after_*` sau).

### 1. Vật liệu: bỏ nhiễu thủ tục, dùng bề mặt quét thật
- **Poly Haven (CC0)**: vữa tường ngoài và trong, bê tông, nhựa đường, gạch lát vỉa hè, gạch sàn, gạch đỏ, ngói đất nung, ốp đá, gỗ ván và gỗ veneer, vải lanh, đất. Mỗi bộ có albedo, **normal map** và **roughness map** riêng (`src/world/textures.ts › realTex`).
- Albedo được chuẩn hóa độ sáng, giảm bão hòa và nén tương phản (tiền xử lý bằng `sharp`) để **màu sơn vẫn do khóa vật liệu quyết định** (`px:#e7d8b5`…), còn hạt, lỗ rỗ, vết loang và độ nhám là của vật liệu thật.
- Giữ bản thủ tục ở nơi đặc thù Việt Nam hoặc tốt hơn bản quét: gạch bông, terrazzo, tôn múi, cửa cuốn, mosaic, gạch ốp bếp.
- **Shader phong hóa theo tọa độ thế giới** (`materials.ts › weather`): phá lặp texture bằng biến thiên đa tầng; vùng bắn nước bẩn dần từ chân tường lên; tảo ở chân tường ẩm; vệt nước mưa chảy dọc tường dưới mái hắt và ban công; roughness dao động theo bụi. Một chương trình shader dùng chung, uniform riêng từng vật liệu.
- Màu đặc (`g:`, `r:`, `m:`) cũng có biến thiên vĩ mô và bụi nhẹ.
- Bùn đất và sạn tích tụ ngắt quãng dọc mép đường, rãnh hẻm, chân tường (`dirt:`).

### 2. Hình học
- **Sửa lỗi gốc ở `Builder.cyl()`**: thân trụ có thứ tự đỉnh ngược nên mặt ngoài bị culling. Lỗi này khiến ghế đẩu hở, nồi, bánh xe, thân cây, cột điện và ống nước tối và rỗng. Sửa một chỗ, toàn thế giới đặc lại.
- **Kiến trúc nội thất**: len chân tường dày 12 cm có gờ bậc; phào trần hai tầng quanh mọi phòng (`trimX/trimZ` trong `builder.ts`).
- **Mặt tiền**: ống thoát nước PVC có kẹp, hộp công tơ điện có cửa sổ kính và ống luồn dây, dàn nóng điều hòa có lưới quạt đặt trên ban công (`facade.ts › facadeHardware`).
- **Quạt trần**: cánh ExtrudeGeometry vát cạnh và hơi võng, tay sắt, thân tiện, chóa đèn, dây kéo.
- **Rèm**: nếp gấp tăng dần về gấu, vòng treo, vải dệt thật có normal map.
- **Tivi**: viền bo góc, lưng thu nhỏ, cổ và chân đế, đèn LED chờ.
- **Xe máy**: phuộc trước ống lồng, giảm xóc sau, đầu xe, sàn để chân.
- **Người**: vai nối thân, xương chậu, cổ áo, lông mày, miệng, tóc sau gáy, búi tóc nữ, túi đeo chéo.

### 3. Ánh sáng và hậu kỳ
- Trần nhà từng nâu bẩn vì `HemisphereLight` có màu nền nâu đất, trần quay xuống chỉ nhận màu đó. Trong nhà, màu nền được kéo về trung tính ấm (phản xạ từ gạch sáng và tường) theo hệ số `indoor`.
- Thêm pass lọc NaN/Inf và chặn HDR trước bloom như lớp bảo vệ rẻ.

## Nguồn
- Poly Haven (CC0): https://polyhaven.com/textures (API `api.polyhaven.com`, bản 1K).

## Cấu trúc mã
- `src/world/textures.ts`: texture thủ tục và `realTex` nạp bộ PBR quét thật.
- `src/world/materials.ts`: vật liệu theo khóa (`px:`, `pi:`, `tile:`, `brick:`, `conc:`, `paver:`, `dirt:`, `g:`, `r:`, `m:`, `puddle:`…), shader phong hóa, trạng thái ướt, đêm.
- `src/world/builder.ts`: gom hình học theo vật liệu; tường có ô cửa, len chân tường, phào trần; `box`, `rb`, `lathe`, `geo`, `cyl`, `leaves`.
- `house.ts`, `facade.ts`, `rooms.ts`: nhà ống, nhà cấp 4, nhà kiểu Pháp; cầu thang, giếng trời, WC, bếp, tum, ban công.
- `devices.ts`, `furniture.ts`, `people.ts`, `neighborhood.ts`, `sky.ts`, `audio.ts`, `engine.ts`, `player.ts`.

## Điều khiển
WASD để đi, Shift để chạy, C để cúi; chuột để nhìn (kéo chuột nếu không khóa được con trỏ). E hoặc click để tương tác. T dừng hoặc chạy giờ, R bật mưa, G tham quan tự động, M tắt tiếng.

## Hạn chế đã biết
- `dist/index.html` khoảng 6,5 MB vì nhúng 4 MB texture JPEG; chưa dùng nén KTX2.
- Chưa đo hiệu năng trên GPU thật. Môi trường thử chỉ có renderer phần mềm (SwiftShader), nên ảnh đêm hoặc mưa ở độ phân giải đầy đủ làm tiến trình GPU phần mềm bị ngắt. Cùng cảnh render đúng ở 640×360 (`02_after_*`).
- Chưa có detail normal phụ cho tường ở khoảng cách rất gần; tôn múi, gạch bông, mosaic vẫn là texture thủ tục.
- Tủ đông và một số khối trắng trong quán tạp hóa vẫn là hộp đơn giản; người vẫn là hình khối cách điệu, chưa phải mesh có da thịt.
- Điểm xuất hiện ở phòng khách và vị trí dịch chuyển trong bếp cần kiểm tra thêm va chạm (từ vòng trước).
