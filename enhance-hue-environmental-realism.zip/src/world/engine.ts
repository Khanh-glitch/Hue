import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { GTAOPass } from 'three/examples/jsm/postprocessing/GTAOPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { Physics } from './physics';
import { Interactions } from './interact';
import { Player } from './player';
import { SkySys, makeEnvMap } from './sky';
import { AudioSys } from './audio';
import { buildNeighborhood } from './neighborhood';
import { buildLife, type Life } from './people';
import { windUniform, setWet, setNightEmit, setAnisotropy } from './materials';
import type { Ctx, RoomLight } from './types';
import type { House } from './house';
import { clamp, mulberry32 } from './util';

export interface Hud { time: string; hour: number; loc: string; prompt: string | null; indoor: boolean; fps: number; rain: number; sitting: string | null; tour: boolean; started: boolean; timeScale: number; muted: boolean; quality: string; weather: string }

export class Engine {
  renderer: THREE.WebGLRenderer; scene = new THREE.Scene(); camera: THREE.PerspectiveCamera;
  composer: EffectComposer | null = null; bloom: UnrealBloomPass | null = null; gtao: GTAOPass | null = null;
  phys = new Physics(); inter = new Interactions(); audio = new AudioSys();
  player: Player; sky: SkySys; ctx: Ctx; life: Life | null = null;
  houses: House[] = [];
  env = { hour: 17.2, night: 0, rain: 0, sun: 1 };
  rainTarget = 0; timeScale = 60; clock = new THREE.Clock();
  pool: THREE.PointLight[] = []; lampPool: THREE.PointLight[] = [];
  rain: THREE.LineSegments; rainU = { uTime: { value: 0 }, uCam: { value: new THREE.Vector3() }, uOp: { value: 0 } };
  indoor = 0; openness = 0; started = false; running = false; quality = 'high';
  hud: Hud; onHud: (h: Hud) => void; hudT = 0; frames = 0; fpsT = 0; fps = 60; pickT = 0;
  current: ReturnType<Interactions['pick']> = null; loc = ''; wet = 0;
  vehicles: { pos: THREE.Vector3; speed: number }[] = [];
  dragging = false; moved = 0; locked = false; lastTouch: { x: number; y: number } | null = null;
  private disposers: (() => void)[] = [];

  constructor(public el: HTMLElement, onHud: (h: Hud) => void) {
    this.onHud = onHud;
    const w = el.clientWidth || 1280, h = el.clientHeight || 720;
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance', preserveDrawingBuffer: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5)); this.renderer.setSize(w, h);
    this.renderer.shadowMap.enabled = true; this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    el.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.touchAction = 'none';
    setAnisotropy(Math.min(8, this.renderer.capabilities.getMaxAnisotropy()));
    this.camera = new THREE.PerspectiveCamera(72, w / h, 0.05, 2400);
    this.scene.add(this.camera);
    this.sky = new SkySys(this.scene, this.renderer);
    this.scene.environment = makeEnvMap(this.renderer);
    this.player = new Player(this.camera, this.phys);
    const eye = new THREE.Vector3();
    this.ctx = {
      root: new THREE.Group(), phys: this.phys, inter: this.inter, roomLights: [], dyn: [], env: this.env, eye, houses: this.houses,
      sfx: this.audio, player: { sit: (p, y, e, l) => { this.player.sit(p, y, e, l); } }, rand: mulberry32(7), lamps: [], walkers: [],
    };
    this.scene.add(this.ctx.root);
    this.houses = this.ctx.houses;
    this.audio.start = this.audio.start.bind(this.audio);
    buildNeighborhood(this.ctx);
    this.life = buildLife(this.ctx, this.houses, this.vehicles, this.audio);
    for (let i = 0; i < 6; i++) { const l = new THREE.PointLight(0xffe0b0, 0, 9, 2); l.castShadow = false; this.scene.add(l); this.pool.push(l); }
    for (let i = 0; i < 3; i++) { const l = new THREE.PointLight(0xffd9a0, 0, 24, 2); this.scene.add(l); this.lampPool.push(l); }
    // rain
    const N = 6000, pos = new Float32Array(N * 6), seed = new Float32Array(N * 2);
    for (let i = 0; i < N; i++) {
      const x = Math.random() * 40, y = Math.random() * 26, z = Math.random() * 40;
      const sd = Math.random(); pos.set([x, y, z, x, y, z], i * 6); seed.set([sd, sd], i * 2);
    }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('sd', new THREE.BufferAttribute(seed, 1));
    const m = new THREE.ShaderMaterial({
      uniforms: this.rainU, transparent: true, depthWrite: false,
      vertexShader: `uniform float uTime; uniform vec3 uCam; attribute float sd; varying float vA;
        void main(){ vec3 p = position; float sp = 16.0 + sd*5.0; float ty = mod(p.y - uTime*sp, 26.0);
          vec3 w; w.xz = uCam.xz + mod(p.xz - uCam.xz + 20.0, 40.0) - 20.0; w.y = ty - 0.5 + 0.0;
          w.x += (ty - p.y) * 0.0; float tail = (position.y > 0.0 && false) ? 0.0 : 0.0;
          vec3 q = w; q.y += (gl_VertexID % 2 == 0 ? 0.0 : -0.6); q.x += (gl_VertexID % 2 == 0 ? 0.0 : -0.06);
          vA = 0.55; gl_Position = projectionMatrix * viewMatrix * vec4(q,1.0); }`,
      fragmentShader: `uniform float uOp; varying float vA; void main(){ gl_FragColor = vec4(0.78,0.84,0.9, vA*uOp); }`,
    });
    this.rain = new THREE.LineSegments(g, m); this.rain.frustumCulled = false; this.rain.renderOrder = 10; this.scene.add(this.rain);
    this.initComposer(w, h);
    this.hud = { time: '', hour: this.env.hour, loc: '', prompt: null, indoor: false, fps: 60, rain: 0, sitting: null, tour: false, started: false, timeScale: this.timeScale, muted: false, quality: this.quality, weather: 'Trời quang' };
    this.player.onStep = (s, r) => this.audio.step(s === 'wood' ? 'wood' : s === 'tile' ? 'tile' : 'concrete', r);
    this.bind();
    this.applyQuality('high');
    // first frame update
    this.update(0.016);
    this.renderer.setAnimationLoop(() => this.frame());
  }

  initComposer(w: number, h: number) {
    const rt = new THREE.WebGLRenderTarget(w, h, { type: THREE.HalfFloatType, samples: 4 });
    this.composer = new EffectComposer(this.renderer, rt);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    // ground-truth ambient occlusion from depth+normals: contact darkening under furniture, in corners, under eaves
    this.gtao = new GTAOPass(this.scene, this.camera, w, h);
    this.gtao.updateGtaoMaterial({ radius: 0.55, distanceExponent: 1.6, thickness: 1.0, scale: 1.0, samples: 12, distanceFallOff: 1.0, screenSpaceRadius: false });
    this.gtao.blendIntensity = 0.85;
    this.composer.addPass(this.gtao);
    // sanitise HDR before bloom: one NaN/Inf texel (mirror-like wet surface under a lamp) would smear into a black block through the blur mips
    this.composer.addPass(new ShaderPass({
      uniforms: { tDiffuse: { value: null } },
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader: `uniform sampler2D tDiffuse; varying vec2 vUv;
        void main(){ vec4 c = texture2D(tDiffuse, vUv); vec3 v = c.rgb;
          if (any(isnan(v)) || any(isinf(v))) v = vec3(0.0);
          gl_FragColor = vec4(clamp(v, 0.0, 24.0), 1.0); }`,
    }));
    this.bloom = new UnrealBloomPass(new THREE.Vector2(w, h), 0.14, 0.35, 2.2);
    this.composer.addPass(this.bloom); this.composer.addPass(new OutputPass());
  }
  applyQuality(q: string) {
    this.quality = q;
    const pr = q === 'low' ? 1 : q === 'med' ? 1.25 : Math.min(window.devicePixelRatio, 1.75);
    this.renderer.setPixelRatio(pr); this.resize();
    this.renderer.shadowMap.enabled = q !== 'low';
    const s = q === 'high' ? 4096 : 2048;
    if (this.sky.sun.shadow.mapSize.x !== s) { this.sky.sun.shadow.mapSize.set(s, s); this.sky.sun.shadow.map?.dispose(); (this.sky.sun.shadow as any).map = null; }
    this.scene.traverse((o) => { const m = (o as THREE.Mesh).material as THREE.Material | undefined; if (m) m.needsUpdate = true; });
    this.useBloom = q !== 'low';
    if (this.gtao) this.gtao.enabled = q === 'high';
  }
  useBloom = true;

  resize() {
    const w = this.el.clientWidth, h = this.el.clientHeight; if (!w || !h) return;
    this.renderer.setSize(w, h); this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
    this.composer?.setSize(w, h); this.bloom?.setSize(w, h);
  }

  bind() {
    const on = <K extends keyof WindowEventMap>(t: K, f: (e: WindowEventMap[K]) => void) => { window.addEventListener(t, f as EventListener); this.disposers.push(() => window.removeEventListener(t, f as EventListener)); };
    on('resize', () => this.resize());
    on('keydown', (e) => {
      if (!this.started) return;
      this.player.keys.add(e.code);
      if (e.code === 'KeyE' || e.code === 'Space') { this.interact(); e.preventDefault(); }
      if (e.code === 'KeyT') this.setTimeScale(this.timeScale > 0 ? 0 : 60);
      if (e.code === 'KeyR') this.setRain(this.rainTarget > 0.3 ? 0 : 1);
      if (e.code === 'KeyM') this.toggleMute();
      if (e.code === 'KeyG') this.startTour();
      if (e.code.startsWith('Arrow')) e.preventDefault();
    });
    on('keyup', (e) => this.player.keys.delete(e.code));
    on('blur', () => this.player.keys.clear());
    const cv = this.renderer.domElement;
    document.addEventListener('pointerlockchange', () => { this.locked = document.pointerLockElement === cv; });
    cv.addEventListener('mousedown', () => { this.dragging = true; this.moved = 0; });
    window.addEventListener('mouseup', () => { if (this.dragging && this.moved < 4 && this.started) this.interact(); this.dragging = false; });
    window.addEventListener('mousemove', (e) => {
      if (!this.started) return;
      if (this.locked || this.dragging) { const k = 0.0022; this.player.look.x -= e.movementX * k; this.player.look.y -= e.movementY * k; this.moved += Math.abs(e.movementX) + Math.abs(e.movementY); }
    });
    cv.addEventListener('touchstart', (e) => { const t = e.touches[0]; this.lastTouch = { x: t.clientX, y: t.clientY }; this.moved = 0; }, { passive: true });
    cv.addEventListener('touchmove', (e) => {
      const t = e.touches[e.touches.length - 1]; if (!this.lastTouch) return;
      if (t.clientX > window.innerWidth * 0.35) { this.player.look.x -= (t.clientX - this.lastTouch.x) * 0.005; this.player.look.y -= (t.clientY - this.lastTouch.y) * 0.005; }
      this.moved += Math.abs(t.clientX - this.lastTouch.x); this.lastTouch = { x: t.clientX, y: t.clientY };
    }, { passive: true });
    cv.addEventListener('touchend', () => { if (this.moved < 6) this.interact(); this.lastTouch = null; });
  }

  begin(lock = true) {
    this.started = true; this.audio.start();
    if (lock) { try { const p = this.renderer.domElement.requestPointerLock() as unknown as Promise<void> | undefined; p?.catch?.(() => { /* ignore */ }); } catch { /* ignore */ } }
  }
  interact() {
    if (this.player.sitting) { this.player.stand(); return; }
    const it = this.current; if (it) it.act();
  }
  setTime(h: number) { this.env.hour = ((h % 24) + 24) % 24; }
  setTimeScale(s: number) { this.timeScale = s; }
  setRain(v: number) { this.rainTarget = v; }
  toggleMute() { this.audio.setMuted(!this.audio.muted); }
  setVolume(v: number) { this.audio.setVolume(v); }
  setMove(x: number, y: number) { this.player.joy.set(x, y); }

  facing(h: House, dx: number, dz: number) { const c = Math.cos(h.rot), s = Math.sin(h.rot); const wx = dx * c + dz * s, wz = -dx * s + dz * c; return Math.atan2(-wx, -wz); }
  teleportHouse(idx: number, lx: number, k: number, lz: number, dx: number, dz: number) {
    const h = this.houses[idx]; if (!h) return;
    const p = h.wp(lx, 0, lz); this.player.teleport(p.x, p.z, this.facing(h, dx, dz));
    const fl = this.phys.floorAt(p.x, p.z, h.F(k) + 0.2, 0.6); this.player.pos.y = fl.y;
  }
  teleport(name: string) {
    this.player.auto = null;
    switch (name) {
      case 'street': this.player.teleport(12, 2.4, 2.5); break;
      case 'alley': this.player.teleport(10, 8, Math.PI); break;
      case 'court': this.player.teleport(10, 38, Math.PI); break;
      case 'living': this.teleportHouse(0, 1.2, 0, 0.9, 0, 1); break;
      case 'kitchen': this.teleportHouse(0, 1.3, 0, 10.2, 0, 1); break;
      case 'bedroom': this.teleportHouse(0, 1.2, 1, 3.4, 0, -1); break;
      case 'roof': { const h = this.houses[0]; this.teleportHouse(0, h.xs + 1.0, h.n, 1.0, 0, 1); break; }
      case 'cafe': this.teleportHouse(3, 1.9, 0, 0.8, 0, 1); break;
      case 'pho': this.teleportHouse(4, 2.2, 0, 0.8, 0, 1); break;
      case 'grocery': this.teleportHouse(1, 2.0, 0, 0.8, 0, 1); break;
      case 'cap4': this.teleportHouse(2, 2.6, 0, -1.5, 0, 1); break;
    }
  }
  startTour() {
    const h = this.houses[0]; if (!h) return;
    const world = (pts: { x: number; z: number }[]) => pts.map((p) => { const w = h.wp(p.x, 0, p.z); return { x: w.x, z: w.z }; });
    h.doors.forEach((d) => d.set(true));
    const start = h.wp(h.doorX, 0, -4.2);
    this.player.teleport(start.x, start.z, this.facing(h, 0, 1));
    let pts: { x: number; z: number }[] = [];
    pts = pts.concat(h.route(0, 0, 0, 0, 1.4, 2.2, true));
    pts = pts.concat(h.route(0, 1.4, 2.2, 0, 1.35, 10.6));
    pts = pts.concat(h.route(0, 1.35, 10.6, 0, 1.65, 13.1));
    pts = pts.concat(h.route(0, 1.65, 13.1, 1, 1.4, 2.2));
    pts = pts.concat(h.route(1, 1.4, 2.2, 1, 1.4, 11.5));
    pts = pts.concat(h.route(1, 1.4, 11.5, h.n - 1, 1.4, 2.0));
    pts = pts.concat(h.route(h.n - 1, 1.4, 2.0, h.n, h.xs + 1.0, h.zs - 0.3));
    pts.push({ x: h.xs + 1.0, z: h.zs - 0.9 }, { x: h.xs + 1.0, z: h.zs - 1.9 }, { x: h.W / 2, z: 0.2 });
    this.player.startAuto(world(pts));
  }

  update(dt: number) {
    const e = this.env;
    if (this.started || true) e.hour = (e.hour + (dt * this.timeScale) / 3600) % 24;
    e.rain += (this.rainTarget - e.rain) * Math.min(1, dt * 0.35);
    this.wet += ((this.rainTarget > 0.2 ? 1 : 0) - this.wet) * Math.min(1, dt * (this.rainTarget > 0.2 ? 0.08 : 0.01));
    const t = this.clock.elapsedTime;
    windUniform.value = t;
    // player
    if (this.started) this.player.update(dt, false); else { this.player.camera.position.set(this.player.pos.x, this.player.pos.y + 1.62, this.player.pos.z); this.player.camera.rotation.set(this.player.pitch, this.player.yaw, 0); this.player.pos.y = this.phys.floorAt(this.player.pos.x, this.player.pos.z, 3, 4).y; }
    this.ctx.eye.copy(this.camera.position);
    // indoor
    const cp = this.camera.position;
    let room = null as ReturnType<House['roomAtWorld']>, inH: House | null = null;
    for (const h of this.houses) { if (!h.contains(cp.x, cp.z) || h.spec.lite) continue; const r = h.roomAtWorld(cp.x, cp.y, cp.z); if (r) { room = r; inH = h; break; } }
    const inside = room && room.kind !== 'well' && room.kind !== 'wellup' ? 1 : 0;
    this.indoor += (inside - this.indoor) * Math.min(1, dt * 2.5);
    const openN = inH ? inH.doors.filter((d) => d.on).length : 0; this.openness += ((inH ? clamp(openN / 3, 0, 1) : 0) - this.openness) * Math.min(1, dt * 2);
    // location label
    if (room) this.loc = `${room.name} · ${room.house.spec.no ? 'Nhà số ' + room.house.spec.no : ''} · Tầng ${room.k + 1}`;
    else if (cp.z > 40 && cp.x > -5 && cp.x < 24) this.loc = 'Sân chung cuối hẻm';
    else if (cp.z > 6 && cp.x > 8 && cp.x < 12) this.loc = 'Hẻm 12 – hẻm bê tông';
    else if (Math.abs(cp.z) <= 6.2) this.loc = 'Đường Hoa Phượng';
    else this.loc = 'Khu phố';
    // sim
    this.life?.update(dt, t);
    for (const f of this.ctx.dyn) f(dt, t);
    this.updateLights(dt, t);
    this.sky.update(e, cp, this.indoor);
    setNightEmit(clamp(e.night * 1.0 + 0.0, 0, 1)); setWet(this.wet);
    this.rainU.uTime.value = t; this.rainU.uCam.value.copy(cp); this.rainU.uOp.value = e.rain * (1 - this.indoor) * 0.85;
    this.rain.visible = e.rain > 0.02 && this.indoor < 0.95;
    this.audio.update(dt, e, this.camera, this.indoor, this.openness, this.vehicles);
    // interaction pick
    this.pickT -= dt; if (this.pickT <= 0) { this.pickT = 0.07; this.current = this.player.sitting ? null : this.inter.pick(this.camera, this.phys); }
  }

  updateLights(dt: number, t: number) {
    const cp = this.camera.position, e = this.env;
    const cand: { rl: RoomLight; d: number }[] = [];
    for (const rl of this.ctx.roomLights) {
      const k = Math.min(1, dt * 5); rl.level += (rl.target - rl.level) * k;
      const lvl = rl.level, tv = rl.roomId.endsWith(':tv');
      const fl = tv ? 0.75 + 0.25 * Math.sin(t * 9 + rl.pos.x) * Math.sin(t * 3.7) : 1;
      for (const m of rl.mats) m.emissiveIntensity = lvl * 2.6;
      for (const m of rl.curtainMats) m.emissiveIntensity = lvl * 0.5 * (0.35 + e.night * 0.65);
      if (lvl > 0.02) { const d = rl.pos.distanceTo(cp); if (d < 26) cand.push({ rl, d: d - (tv ? 0 : 0) }); }
      (rl as any)._fl = fl;
    }
    cand.sort((a, b) => a.d - b.d);
    this.pool.forEach((p, i) => {
      const c = cand[i];
      if (!c) { p.intensity += (0 - p.intensity) * Math.min(1, dt * 8); return; }
      p.position.copy(c.rl.pos); p.color.setHex(c.rl.color);
      const tgt = c.rl.level * c.rl.power * 7 * (c.rl as any)._fl;
      p.intensity += (tgt - p.intensity) * Math.min(1, dt * 10);
      p.distance = c.rl.roomId.endsWith(':tv') ? 6 : 8.5;
    });
    const lamps = this.ctx.lamps.slice().sort((a, b) => a.distanceToSquared(cp) - b.distanceToSquared(cp));
    this.lampPool.forEach((p, i) => { if (lamps[i]) p.position.copy(lamps[i]); p.intensity = e.night * 20 * (1 - 0.3 * e.rain) * (lamps[i] ? 1 : 0); });
  }

  frame() {
    const dt = Math.min(this.clock.getDelta(), 0.06);
    this.update(dt);
    if (this.composer && this.useBloom) this.composer.render(dt); else this.renderer.render(this.scene, this.camera);
    this.frames++; this.fpsT += dt;
    if (this.fpsT > 0.5) { this.fps = Math.round(this.frames / this.fpsT); this.frames = 0; this.fpsT = 0; }
    this.hudT -= dt;
    if (this.hudT <= 0) {
      this.hudT = 0.12;
      const h = this.env.hour, hh = Math.floor(h), mm = Math.floor((h % 1) * 60);
      this.hud = {
        time: `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`, hour: h, loc: this.loc, prompt: this.player.sitting ? 'Nhấn phím bất kỳ di chuyển / E để đứng dậy' : this.current ? this.current.label() : null,
        indoor: this.indoor > 0.5, fps: this.fps, rain: this.env.rain, sitting: this.player.sitting?.label ?? null, tour: !!this.player.auto, started: this.started, timeScale: this.timeScale, muted: this.audio.muted, quality: this.quality,
        weather: this.env.rain > 0.5 ? 'Mưa rào' : this.env.night > 0.6 ? 'Đêm' : this.env.sun < 0.5 ? 'Hoàng hôn / bình minh' : 'Trời quang',
      };
      this.onHud(this.hud);
    }
  }

  dispose() { this.renderer.setAnimationLoop(null); this.disposers.forEach((d) => d()); this.renderer.dispose(); this.renderer.domElement.remove(); }
}
