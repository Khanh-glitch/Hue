import { useEffect, useRef, useState } from 'react';
import { Engine, type UIState } from './game/engine';

const initial: UIState = { prompt: null, focus: false, captions: [], inspecting: null, locked: false, fade: 1, ended: null, started: false, seated: false };

export default function App() {
  const mount = useRef<HTMLDivElement>(null);
  const engine = useRef<Engine | null>(null);
  const [ui, setUI] = useState<UIState>(initial);
  const [quality, setQuality] = useState<'high' | 'low'>('high');
  const [loading, setLoading] = useState(true);
  const [showHelp, setShowHelp] = useState(true);

  useEffect(() => {
    if (!mount.current) return;
    setLoading(true);
    // let the loading text paint before heavy texture generation
    const fontsReady = Promise.race([
      Promise.all([document.fonts.load("40px 'Patrick Hand'", 'Tổng đài'), document.fonts.load("16px 'Be Vietnam Pro'")]),
      new Promise((r) => setTimeout(r, 2500)),
    ]);
    let id = 0; let cancelled = false;
    fontsReady.then(() => { if (cancelled) return; id = window.setTimeout(() => {
      if (cancelled) return;
      try {
        engine.current = new Engine(mount.current!, setUI, quality);
      } catch (e) {
        console.error(e);
      }
      setLoading(false);
    }, 60); });
    return () => { cancelled = true; window.clearTimeout(id); engine.current?.dispose(); engine.current = null; };
  }, [quality]);

  useEffect(() => {
    if (!ui.started) return;
    const t = window.setTimeout(() => setShowHelp(false), 22000);
    return () => window.clearTimeout(t);
  }, [ui.started]);

  const start = () => engine.current?.begin();

  return (
    <div className="fixed inset-0 bg-black text-stone-100 select-none overflow-hidden" style={{ fontFamily: "'Be Vietnam Pro', 'Segoe UI', system-ui, sans-serif" }}>
      <div ref={mount} className="absolute inset-0" />

      {/* crosshair + prompt */}
      {ui.started && ui.locked && !ui.inspecting && !ui.ended && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className={`rounded-full transition-all duration-300 ${ui.focus ? 'w-5 h-5 border border-white/70' : 'w-1 h-1 bg-white/60'}`} />
          {ui.prompt && (
            <div className="absolute top-1/2 mt-7 text-[13px] tracking-wide text-white/85 flex items-center gap-2" style={{ textShadow: '0 1px 6px rgba(0,0,0,.9)' }}>
              <span className="px-1.5 py-0.5 rounded border border-white/40 text-[11px] text-white/80">E</span>
              {ui.prompt}
            </div>
          )}
        </div>
      )}

      {/* captions */}
      <div className="pointer-events-none absolute left-0 right-0 bottom-[9%] flex flex-col items-center gap-2 px-6">
        {ui.captions.map((c) => (
          <div key={c.id} className="max-w-2xl text-center animate-[cap_0.9s_ease-out]" style={{ textShadow: '0 2px 10px rgba(0,0,0,.95)' }}>
            {c.voice ? (
              <p className="text-[17px] leading-relaxed text-sky-100/95"><span className="text-sky-300/70 text-xs uppercase tracking-[0.2em] mr-2">điện thoại</span>“{c.text}”</p>
            ) : (
              <p className="text-[17px] leading-relaxed italic text-stone-100/90">{c.text}</p>
            )}
          </div>
        ))}
      </div>

      {/* inspect hints */}
      {ui.inspecting && !ui.ended && (
        <div className="pointer-events-none absolute right-8 bottom-8 flex flex-col items-end gap-1.5 text-[13px] text-white/75" style={{ textShadow: '0 1px 6px rgba(0,0,0,.9)' }}>
          {ui.inspecting.title && <div className="text-[11px] uppercase tracking-[0.25em] text-white/45 mb-1">{ui.inspecting.title}</div>}
          {ui.inspecting.actions.map((a) => (
            <div key={a.key} className="flex items-center gap-2">
              {a.label}
              <span className="px-1.5 py-0.5 rounded border border-white/40 text-[11px]">{a.key}</span>
            </div>
          ))}
        </div>
      )}

      {/* seated hint */}
      {ui.seated && !ui.inspecting && !ui.ended && ui.started && (
        <div className="pointer-events-none absolute right-8 bottom-8 flex flex-col items-end gap-1.5 text-[13px] text-white/75" style={{ textShadow: '0 1px 6px rgba(0,0,0,.9)' }}>
          <div className="text-[11px] uppercase tracking-[0.25em] text-white/45 mb-1">Đang ngồi</div>
          <div className="flex items-center gap-2">Đứng dậy <span className="px-1.5 py-0.5 rounded border border-white/40 text-[11px]">Q</span></div>
        </div>
      )}

      {/* first-minutes controls */}
      {ui.started && showHelp && !ui.inspecting && (
        <div className="pointer-events-none absolute left-7 bottom-7 text-[12px] leading-6 text-white/45">
          <div><b className="text-white/65 font-medium">WASD</b> đi lại · <b className="text-white/65 font-medium">Chuột</b> nhìn · <b className="text-white/65 font-medium">Shift</b> đi nhanh</div>
          <div><b className="text-white/65 font-medium">E / Click</b> tương tác · <b className="text-white/65 font-medium">Q / Chuột phải</b> quay lại</div>
        </div>
      )}

      {/* pause */}
      {ui.started && !ui.locked && !ui.ended && (
        <button onClick={() => engine.current?.lock()} className="absolute inset-0 flex items-center justify-center bg-black/35 backdrop-blur-[1px] cursor-pointer">
          <span className="text-sm tracking-[0.3em] uppercase text-white/70">Nhấn để tiếp tục</span>
        </button>
      )}

      {/* title */}
      {!ui.started && (
        <div className="absolute inset-0 flex items-center justify-center bg-[radial-gradient(ellipse_at_center,rgba(10,12,20,0.55),rgba(0,0,0,0.92))]">
          <div className="max-w-xl px-8 text-center">
            <p className="text-[11px] uppercase tracking-[0.45em] text-amber-200/60 mb-6">Phòng 6.07 · 23:08</p>
            <h1 className="text-5xl md:text-6xl font-extralight tracking-tight text-stone-100">Sau cơn mưa</h1>
            <p className="mt-6 text-stone-300/75 leading-relaxed text-[15px]">
              Mưa vừa tạnh. Thành phố bên ngoài vẫn còn sáng đèn.<br />
              Sau một ngày rất dài, bạn cuối cùng cũng về đến nhà.
            </p>
            <button
              disabled={loading}
              onClick={start}
              className="mt-10 px-8 py-3 rounded-full border border-white/25 text-sm tracking-[0.25em] uppercase text-white/85 hover:bg-white/10 hover:border-white/50 transition disabled:opacity-40"
            >
              {loading ? 'Đang dựng căn phòng…' : 'Mở cửa vào nhà'}
            </button>
            <div className="mt-8 flex items-center justify-center gap-3 text-[12px] text-white/45">
              <span>Chất lượng</span>
              {(['high', 'low'] as const).map((q) => (
                <button key={q} onClick={() => setQuality(q)} className={`px-3 py-1 rounded-full border ${quality === q ? 'border-white/50 text-white/85' : 'border-white/15 hover:border-white/30'}`}>
                  {q === 'high' ? 'Cao' : 'Nhẹ'}
                </button>
              ))}
            </div>
            <p className="mt-6 text-[12px] text-white/35">Nên dùng tai nghe · Bàn phím & chuột</p>
          </div>
        </div>
      )}

      {/* ending */}
      {ui.ended && (
        <div className="absolute inset-0 flex items-center justify-center animate-[cap_2.5s_ease-out]">
          <div className="max-w-lg px-8 text-center">
            <p className="text-[11px] uppercase tracking-[0.45em] text-amber-200/55 mb-5">23:{ui.ended === 'answered' ? '21' : '19'}</p>
            <h2 className="text-3xl md:text-4xl font-extralight text-stone-100 leading-snug">Ngoài kia, thành phố vẫn sáng đèn.</h2>
            <p className="mt-5 text-stone-300/70 text-[15px] leading-relaxed">
              {ui.ended === 'answered'
                ? 'Một giọng nói lạ vừa bước vào căn phòng nhỏ này — và nó cần một con số.'
                : 'Một số máy lạ, một tin nhắn gấp gáp. Căn phòng vẫn vậy, nhưng đêm nay đã khác.'}
            </p>
            <p className="mt-8 text-[11px] uppercase tracking-[0.35em] text-white/35">— Hết phần mở đầu —</p>
            <div className="mt-8 flex gap-3 justify-center">
              <button onClick={() => engine.current?.continueAfterEnd()} className="px-6 py-2.5 rounded-full border border-white/25 text-xs tracking-[0.2em] uppercase text-white/85 hover:bg-white/10">Ở lại thêm một lúc</button>
              <button onClick={() => window.location.reload()} className="px-6 py-2.5 rounded-full border border-white/10 text-xs tracking-[0.2em] uppercase text-white/55 hover:bg-white/5">Bắt đầu lại</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
