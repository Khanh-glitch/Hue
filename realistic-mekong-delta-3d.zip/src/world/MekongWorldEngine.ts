import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { N8AOPass } from 'n8ao';
import {
  clearWorldCollisionRegistry,
  resolveHorizontalCollision,
  sampleTerrainHeight,
  sampleWalkableHeight,
} from './terrain/MekongHeightfield';
import { MekongMaterialLibrary } from './materials/ProceduralPBR';
import { createMekongTerrain } from './terrain/MekongTerrain';
import { createMekongWater, sampleRiverWave } from './water/MekongWater';
import { createMekongAtmosphere } from './atmosphere/MekongSky';
import { createMekongFlora } from './foliage/MekongFlora';
import { createBoatsSystem } from './architecture/Boats';
import { createStiltVillage } from './architecture/StiltVillage';
import { createHeritageMansion } from './architecture/HeritageMansion';
import { createKhmerShrine } from './architecture/KhmerShrine';
import { createBridgesAndLife } from './architecture/BridgesAndLife';
import { MekongAudioEngine } from './audio/MekongAudio';
import { clamp, lerp } from './math/Noise';

export type TraversalMode = 'walk' | 'boat' | 'fly';
export type QualityPreset = 'high' | 'medium';

export interface WorldBookmark {
  id: string;
  name: string;
  subtitle: string;
  mode: TraversalMode;
  pos: [number, number, number];
  yaw: number;
  pitch: number;
}

export const WORLD_BOOKMARKS: WorldBookmark[] = [
  {
    id: 'ben-do',
    name: 'Bến Đò & Chợ Nổi',
    subtitle: 'Toàn cảnh ngã ba sông & ghe cây bẹo',
    mode: 'walk',
    pos: [17.0, 2.8, 27.4],
    yaw: 0.72,
    pitch: -0.06,
  },
  {
    id: 'cho-noi',
    name: 'Giữa Chợ Nổi',
    subtitle: 'Lênh đênh trên xuồng giữa ghe hàng',
    mode: 'boat',
    pos: [-6.5, 1.5, 4.0],
    yaw: 0.25,
    pitch: -0.04,
  },
  {
    id: 'xom-nha-san',
    name: 'Xóm Nhà Sàn',
    subtitle: 'Cầu ván, quán võng & nếp sống ven rạch',
    mode: 'walk',
    pos: [26.4, 3.55, 11.5],
    yaw: 0.22,
    pitch: -0.08,
  },
  {
    id: 'nha-co',
    name: 'Nhà Cổ Bình Thủy',
    subtitle: 'Cổng Tam Quan, sân gạch tàu & mái âm dương',
    mode: 'walk',
    pos: [35.5, 3.35, 48.0],
    yaw: -1.57,
    pitch: 0.03,
  },
  {
    id: 'chua-khmer',
    name: 'Chùa Khmer Cổ',
    subtitle: 'Chánh điện mái tam cấp & tượng Naga',
    mode: 'walk',
    pos: [-42.5, 3.5, 8.2],
    yaw: 1.57,
    pitch: 0.08,
  },
  {
    id: 'cau-khi-vuon',
    name: 'Cầu Khỉ & Ao Sen',
    subtitle: 'Rạch dừa nước, cầu tre & vườn miệt vườn',
    mode: 'walk',
    pos: [48.0, 3.45, -14.2],
    yaw: 0.02,
    pitch: -0.08,
  },
];

export interface HUDTelemetry {
  mode: TraversalMode;
  nearBoat: boolean;
  zoneLabel: string;
  timeOfDay: number;
  fps: number;
  audioOn: boolean;
}

export class MekongWorldEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private composer: EffectComposer;
  private n8aoPass: N8AOPass;
  private bloomPass: UnrealBloomPass;

  private mats: MekongMaterialLibrary;
  private atmosphere: ReturnType<typeof createMekongAtmosphere>;
  private terrain: ReturnType<typeof createMekongTerrain>;
  private water: ReturnType<typeof createMekongWater>;
  private flora: ReturnType<typeof createMekongFlora>;
  private boats: ReturnType<typeof createBoatsSystem>;
  private stiltVillage: ReturnType<typeof createStiltVillage>;
  private mansion: ReturnType<typeof createHeritageMansion>;
  private shrine: ReturnType<typeof createKhmerShrine>;
  private bridgesAndLife: ReturnType<typeof createBridgesAndLife>;
  private audio: MekongAudioEngine;

  private mode: TraversalMode = 'walk';
  private quality: QualityPreset = 'high';
  private playerPos = new THREE.Vector3(17.0, 1.25, 27.4);
  private playerVelY = 0;
  private yaw = 0.72;
  private pitch = -0.06;
  private boatSpeed = 0;
  private boatHeading = Math.PI * 0.9;

  private keys = new Set<string>();
  private dragging = false;
  private lastPointerX = 0;
  private lastPointerY = 0;

  private animId = 0;
  private lastTickMs = performance.now();
  private elapsedTime = 0;
  private fpsFrames = 0;
  private fpsTimer = 0;
  private currentFps = 60;
  private paused = false;
  private disposed = false;

  private onTelemetry?: (data: HUDTelemetry) => void;
  private telemetryTimer = 0;

  constructor(
    container: HTMLElement,
    onTelemetry?: (data: HUDTelemetry) => void,
    initialTimeHours = 6.9,
  ) {
    this.container = container;
    this.onTelemetry = onTelemetry;

    clearWorldCollisionRegistry();

    const width = Math.max(container.clientWidth, 320);
    const height = Math.max(container.clientHeight, 240);

    // 1. WebGLRenderer (linear HDR pipeline feeding EffectComposer -> OutputPass ACES)
    this.renderer = new THREE.WebGLRenderer({
      antialias: false, // Post-processing handles AA/filtering cleanly
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.88;
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(60, width / height, 0.15, 560);
    this.camera.rotation.order = 'YXZ';

    // 2. Build Atmosphere, Materials, Terrain, Water, Flora & Landmarks
    this.mats = new MekongMaterialLibrary();
    this.atmosphere = createMekongAtmosphere(this.scene, this.camera, 2048);
    this.terrain = createMekongTerrain();
    this.scene.add(this.terrain.group);

    this.water = createMekongWater(this.terrain.heightDataTex);
    this.scene.add(this.water.mesh);

    this.flora = createMekongFlora(this.mats);
    this.scene.add(this.flora.group);

    this.boats = createBoatsSystem(this.mats);
    this.scene.add(this.boats.group);

    this.stiltVillage = createStiltVillage(this.mats);
    this.scene.add(this.stiltVillage.group);

    this.mansion = createHeritageMansion(this.mats);
    this.scene.add(this.mansion.group);

    this.shrine = createKhmerShrine(this.mats);
    this.scene.add(this.shrine.group);

    this.bridgesAndLife = createBridgesAndLife(this.mats);
    this.scene.add(this.bridgesAndLife.group);

    this.audio = new MekongAudioEngine();

    // Setup Cascaded Shadow Maps on all MeshStandardMaterials across the world
    this.atmosphere.applyCSMToScene(this.scene);
    this.atmosphere.setTimeOfDay(initialTimeHours, this.renderer, true);

    // 3. Post-Processing Pipeline: N8AO (linear HDR) -> Subtle UnrealBloom -> OutputPass (ACES + sRGB)
    const hdrTarget = new THREE.WebGLRenderTarget(width, height, {
      type: THREE.HalfFloatType,
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      depthBuffer: true,
    });
    this.composer = new EffectComposer(this.renderer, hdrTarget);

    this.n8aoPass = new N8AOPass(this.scene, this.camera, width, height);
    this.n8aoPass.configuration.gammaCorrection = false; // OutputPass handles tone mapping + sRGB!
    this.n8aoPass.configuration.aoRadius = 2.4;
    this.n8aoPass.configuration.distanceFalloff = 0.85;
    this.n8aoPass.configuration.intensity = 2.1;
    this.n8aoPass.configuration.color = new THREE.Color(0x1f1912);
    this.n8aoPass.setQualityMode('Medium');
    this.composer.addPass(this.n8aoPass);

    this.bloomPass = new UnrealBloomPass(
      new THREE.Vector2(width, height),
      0.09, // subtle glint & lantern glow only
      0.28,
      2.2, // keep bright horizon sky from blooming across foreground architecture
    );
    this.composer.addPass(this.bloomPass);

    const outputPass = new OutputPass();
    this.composer.addPass(outputPass);

    // Initialize player position on Ferry Pier facing the Floating Market
    this.applyBookmark(WORLD_BOOKMARKS[0]);
    this.bindEvents();
    this.exposeDebugHook();
    this.startLoop();
  }

  private bindEvents(): void {
    const dom = this.renderer.domElement;

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      const k = e.key.toLowerCase();
      this.keys.add(k);
      if (k === 'b') this.toggleBoatMode();
      if (k === 'f') this.setMode(this.mode === 'fly' ? 'walk' : 'fly');
    };
    const onKeyUp = (e: KeyboardEvent) => {
      this.keys.delete(e.key.toLowerCase());
    };
    const onPointerDown = (e: PointerEvent) => {
      this.dragging = true;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;
    };
    const onPointerMove = (e: PointerEvent) => {
      if (!this.dragging && document.pointerLockElement !== dom) return;
      const dx =
        document.pointerLockElement === dom ? e.movementX : e.clientX - this.lastPointerX;
      const dy =
        document.pointerLockElement === dom ? e.movementY : e.clientY - this.lastPointerY;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;

      this.yaw -= dx * 0.0032;
      this.pitch = clamp(this.pitch - dy * 0.0032, -1.38, 1.38);
    };
    const onPointerUp = () => {
      this.dragging = false;
    };
    const onResize = () => {
      if (this.disposed) return;
      const w = Math.max(this.container.clientWidth, 320);
      const h = Math.max(this.container.clientHeight, 240);
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
      this.composer.setSize(w, h);
      this.water.resize(w, h);
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('resize', onResize);
    dom.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);

    this.cleanupEvents = () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('resize', onResize);
      dom.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
    };
  }
  private cleanupEvents: () => void = () => {};

  private exposeDebugHook(): void {
    (window as unknown as Record<string, unknown>).__MEKONG_WORLD__ = {
      teleport: (x: number, y: number, z: number, yaw: number, pitch: number, mode: TraversalMode = 'fly') => {
        this.mode = mode;
        this.playerPos.set(x, y, z);
        this.yaw = yaw;
        this.pitch = pitch;
        this.syncCamera();
      },
      setTime: (hours: number) => this.setTimeOfDay(hours),
      setQuality: (q: QualityPreset) => this.setQuality(q),
      setPaused: (p: boolean) => {
        this.paused = p;
      },
      renderNow: (stepSeconds = 0.016) => {
        this.renderFrame(stepSeconds);
      },
      applyBookmark: (id: string) => {
        const bm = WORLD_BOOKMARKS.find((b) => b.id === id);
        if (bm) this.applyBookmark(bm);
      },
      getStats: () => ({
        mode: this.mode,
        pos: this.playerPos.toArray(),
        yaw: this.yaw,
        pitch: this.pitch,
        timeOfDay: this.atmosphere.state.timeOfDay,
        fps: this.currentFps,
      }),
    };
  }

  private emitTelemetryNow(): void {
    if (!this.onTelemetry) return;
    const atmo = this.atmosphere.state;
    const distToBoat = this.playerPos.distanceTo(this.boats.playerBoat.position);
    this.onTelemetry({
      mode: this.mode,
      nearBoat: distToBoat < 6.5,
      zoneLabel: this.getZoneLabel(),
      timeOfDay: atmo.timeOfDay,
      fps: this.currentFps,
      audioOn: this.audio.isEnabled(),
    });
  }

  setTimeOfDay(hours: number): void {
    this.atmosphere.setTimeOfDay(hours, this.renderer, true);
    this.emitTelemetryNow();
  }

  setQuality(preset: QualityPreset): void {
    this.quality = preset;
    if (preset === 'high') {
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      this.n8aoPass.configuration.halfRes = false;
      this.n8aoPass.setQualityMode('Medium');
    } else {
      this.renderer.setPixelRatio(1);
      this.n8aoPass.configuration.halfRes = true;
      this.n8aoPass.setQualityMode('Low');
    }
  }

  getQuality(): QualityPreset {
    return this.quality;
  }

  setMode(next: TraversalMode): void {
    if (next === this.mode) return;
    if (next === 'boat') {
      this.mode = 'boat';
      this.boatSpeed = 0;
      const bPos = this.boats.playerBoat.position;
      this.boatHeading = this.boats.playerBoat.rotation.y;
      this.playerPos.set(bPos.x, 1.35, bPos.z);
    } else {
      this.mode = next;
      if (next === 'walk') {
        const surf = sampleWalkableHeight(this.playerPos.x, this.playerPos.z, this.playerPos.y);
        this.playerPos.y = Math.max(surf.y, 0.3) + 1.65;
      }
    }
  }

  toggleBoatMode(): void {
    if (this.mode === 'boat') {
      // Disembark onto nearest pier/bank if shallow/near pier, else just switch to walk/fly
      const bx = this.boats.playerBoat.position.x;
      const bz = this.boats.playerBoat.position.z;
      const surf = sampleWalkableHeight(bx, bz, 3.0);
      if (surf.y > 0.1) {
        this.playerPos.set(bx, surf.y + 1.65, bz);
        this.mode = 'walk';
      } else {
        // Check adjacent bank within 4m
        for (const [dx, dz] of [
          [2.5, 0],
          [-2.5, 0],
          [0, 2.5],
          [0, -2.5],
        ]) {
          const nearSurf = sampleWalkableHeight(bx + dx, bz + dz, 3.0);
          if (nearSurf.y > 0.15) {
            this.playerPos.set(bx + dx, nearSurf.y + 1.65, bz + dz);
            this.mode = 'walk';
            return;
          }
        }
        this.mode = 'fly';
      }
    } else {
      this.setMode('boat');
    }
  }

  toggleAudio(): boolean {
    return this.audio.toggle();
  }

  applyBookmark(bm: WorldBookmark): void {
    if (bm.mode === 'boat') {
      this.boats.playerBoat.position.set(bm.pos[0], 0, bm.pos[2]);
      this.boatHeading = bm.yaw;
      this.boats.playerBoat.rotation.y = bm.yaw;
      this.mode = 'boat';
      this.boatSpeed = 0;
    } else {
      this.mode = bm.mode;
    }
    this.playerPos.set(bm.pos[0], bm.pos[1], bm.pos[2]);
    this.yaw = bm.yaw;
    this.pitch = bm.pitch;
    this.playerVelY = 0;
    this.syncCamera();
    this.emitTelemetryNow();
  }

  private getZoneLabel(): string {
    const x = this.playerPos.x;
    const z = this.playerPos.z;
    if (x < -30 && z > -28 && z < 36) return 'Chùa Khmer Cổ & Miếu Cây Đa';
    if (x > 25 && z > 22 && z < 75) return 'Khu Nhà Cổ Bình Thủy & Phố Cổ';
    if (x > 14 && x < 44 && z >= -18 && z <= 22) return 'Xóm Nhà Sàn Ven Rạch';
    if (x > 20 && z <= -32) return 'Vườn Miệt Vườn & Ao Sen';
    if (x >= 10 && x <= 26 && z >= 22 && z <= 32) return 'Bến Đò Sông Hậu';
    if (x > 10 && z > -36 && z < -12) return 'Rạch Dừa Nước & Cầu Khỉ';
    return 'Chợ Nổi Ngã Ba Sông';
  }

  private updatePlayer(dt: number): void {
    // Arrow keys / Q-E also rotate view gently for accessibility
    if (this.keys.has('arrowleft')) this.yaw += 1.6 * dt;
    if (this.keys.has('arrowright')) this.yaw -= 1.6 * dt;

    const fwd = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const right = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));

    if (this.mode === 'fly') {
      const move = new THREE.Vector3();
      const lookDir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ'));
      if (this.keys.has('w') || this.keys.has('arrowup')) move.add(lookDir);
      if (this.keys.has('s') || this.keys.has('arrowdown')) move.sub(lookDir);
      if (this.keys.has('d')) move.add(right);
      if (this.keys.has('a')) move.sub(right);
      if (this.keys.has(' ') || this.keys.has('e')) move.y += 1;
      if (this.keys.has('q') || this.keys.has('c')) move.y -= 1;

      const speed = this.keys.has('shift') ? 26 : 12;
      if (move.lengthSq() > 0) {
        move.normalize().multiplyScalar(speed * dt);
        this.playerPos.add(move);
      }
      this.playerPos.x = clamp(this.playerPos.x, -210, 210);
      this.playerPos.z = clamp(this.playerPos.z, -210, 210);
      this.playerPos.y = clamp(this.playerPos.y, 0.35, 95);
    } else if (this.mode === 'boat') {
      const throttle = (this.keys.has('w') || this.keys.has('arrowup') ? 1 : 0) - (this.keys.has('s') || this.keys.has('arrowdown') ? 1 : 0);
      const steer = (this.keys.has('a') ? 1 : 0) - (this.keys.has('d') ? 1 : 0);

      this.boatSpeed = lerp(this.boatSpeed, throttle * (this.keys.has('shift') ? 8.5 : 4.8), dt * 2.4);
      this.boatHeading += steer * dt * (1.25 + Math.abs(this.boatSpeed) * 0.08);

      const dirX = Math.sin(this.boatHeading);
      const dirZ = Math.cos(this.boatHeading);
      const bPos = this.boats.playerBoat.position;
      const candX = clamp(bPos.x + dirX * this.boatSpeed * dt, -145, 145);
      const candZ = clamp(bPos.z + dirZ * this.boatSpeed * dt, -145, 145);

      // Keep boat within navigable water (terrain depth < -0.25m)
      if (sampleTerrainHeight(candX, candZ) < -0.26) {
        bPos.x = candX;
        bPos.z = candZ;
      } else {
        this.boatSpeed *= -0.25;
      }

      const w = sampleRiverWave(bPos.x, bPos.z, this.elapsedTime);
      bPos.y = w.height - 0.05;
      this.boats.playerBoat.rotation.set(
        w.slopeZ * 0.65 - this.boatSpeed * 0.015,
        this.boatHeading,
        -w.slopeX * 0.85,
      );

      // Camera seated naturally inside the sampan overlooking bow & Mắt Ghe
      this.playerPos.set(bPos.x - dirX * 0.65, bPos.y + 1.15, bPos.z - dirZ * 0.65);
    } else {
      // Walk Mode with grounded stairs, boardwalks, bridges & Monkey Bridge!
      const move = new THREE.Vector3();
      if (this.keys.has('w') || this.keys.has('arrowup')) move.add(fwd);
      if (this.keys.has('s') || this.keys.has('arrowdown')) move.sub(fwd);
      if (this.keys.has('d')) move.add(right);
      if (this.keys.has('a')) move.sub(right);

      const speed = this.keys.has('shift') ? 7.8 : 4.2;
      if (move.lengthSq() > 0) {
        move.normalize().multiplyScalar(speed * dt);
      }

      const footY = this.playerPos.y - 1.65;
      const nextRawX = this.playerPos.x + move.x;
      const nextRawZ = this.playerPos.z + move.z;

      // Prevent walking straight into deep river water unless stepping onto pier/bridge
      const nextSurf = sampleWalkableHeight(nextRawX, nextRawZ, footY);
      if (nextSurf.y >= -0.05 || nextSurf.onStructure) {
        const resolved = resolveHorizontalCollision(nextRawX, nextRawZ, 0.38, footY);
        this.playerPos.x = resolved.x;
        this.playerPos.z = resolved.z;
      }

      const curSurf = sampleWalkableHeight(this.playerPos.x, this.playerPos.z, footY);
      const targetEyeY = curSurf.y + 1.65;

      if (this.keys.has(' ') && Math.abs(this.playerPos.y - targetEyeY) < 0.08) {
        this.playerVelY = 4.6;
      }
      this.playerVelY -= 14.5 * dt;
      this.playerPos.y += this.playerVelY * dt;
      if (this.playerPos.y <= targetEyeY) {
        this.playerPos.y = lerp(this.playerPos.y, targetEyeY, 0.55);
        if (this.playerPos.y < targetEyeY) this.playerPos.y = targetEyeY;
        this.playerVelY = 0;
      }
    }

    this.syncCamera();
  }

  private syncCamera(): void {
    this.camera.position.copy(this.playerPos);
    this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
  }

  private renderFrame(dt: number): void {
    this.elapsedTime += dt;

    this.updatePlayer(dt);

    // Update world systems
    const atmo = this.atmosphere.state;
    this.atmosphere.update(this.elapsedTime);
    this.flora.update(
      this.elapsedTime,
      atmo.sunDir,
      atmo.sunColor,
      atmo.fogColor,
      atmo.fogDensity,
    );
    this.boats.update(this.elapsedTime, atmo.nightFactor, this.mode === 'boat');
    this.stiltVillage.update(this.elapsedTime, atmo.nightFactor);
    this.mansion.update(this.elapsedTime, atmo.nightFactor);
    this.shrine.update(this.elapsedTime, atmo.nightFactor);
    this.bridgesAndLife.update(this.elapsedTime, atmo.nightFactor);

    this.water.updateUniforms({
      time: this.elapsedTime,
      sunDir: atmo.sunDir,
      sunColor: atmo.sunColor,
      sunIntensity: atmo.sunIntensity,
      skyHorizonColor: atmo.skyHorizonColor,
      skyZenithColor: atmo.skyZenithColor,
      fogColor: atmo.fogColor,
      fogDensity: atmo.fogDensity,
      camera: this.camera,
    });

    // Ensure CSM shadow maps are initialized before planar reflection samples them
    const shadowsReady = this.atmosphere.csm.lights.every((l) => Boolean(l.shadow.map));
    if (shadowsReady) {
      this.water.renderReflection(this.renderer, this.scene, this.camera);
    }

    // Main HDR + N8AO + Subtle Bloom + ACES Filmic Output
    this.composer.render(dt);
  }

  private startLoop(): void {
    this.lastTickMs = performance.now();
    const tick = () => {
      if (this.disposed) return;
      this.animId = requestAnimationFrame(tick);

      const now = performance.now();
      const dt = Math.min((now - this.lastTickMs) / 1000, 0.05);
      this.lastTickMs = now;

      if (this.paused) return;

      this.renderFrame(dt);

      // Audio + Telemetry
      const atmo = this.atmosphere.state;
      const terrainY = sampleTerrainHeight(this.playerPos.x, this.playerPos.z);
      this.audio.update(
        atmo.nightFactor,
        this.mode === 'boat' ? this.boatSpeed : 0,
        Math.max(0, terrainY) * 14,
      );

      this.fpsFrames++;
      this.fpsTimer += dt;
      if (this.fpsTimer >= 0.5) {
        this.currentFps = Math.round(this.fpsFrames / this.fpsTimer);
        this.fpsFrames = 0;
        this.fpsTimer = 0;
      }

      this.telemetryTimer += dt;
      if (this.telemetryTimer >= 0.15 && this.onTelemetry) {
        this.telemetryTimer = 0;
        const distToBoat = this.playerPos.distanceTo(this.boats.playerBoat.position);
        this.onTelemetry({
          mode: this.mode,
          nearBoat: distToBoat < 6.5,
          zoneLabel: this.getZoneLabel(),
          timeOfDay: atmo.timeOfDay,
          fps: this.currentFps,
          audioOn: this.audio.isEnabled(),
        });
      }
    };
    tick();
  }

  dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.animId);
    this.cleanupEvents();
    this.audio.dispose();
    this.atmosphere.dispose();
    this.terrain.dispose();
    this.water.dispose();
    this.flora.dispose();
    this.boats.dispose();
    this.stiltVillage.dispose();
    this.mansion.dispose();
    this.shrine.dispose();
    this.bridgesAndLife.dispose();
    this.mats.dispose();
    this.composer.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
