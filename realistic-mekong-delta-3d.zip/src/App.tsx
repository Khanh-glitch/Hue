import { useEffect, useRef, useState } from 'react';
import {
  Anchor,
  Compass,
  Eye,
  EyeOff,
  Feather,
  Footprints,
  MapPin,
  Moon,
  Sparkles,
  Sun,
  Sunrise,
  Sunset,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  HUDTelemetry,
  MekongWorldEngine,
  QualityPreset,
  TraversalMode,
  WORLD_BOOKMARKS,
} from './world/MekongWorldEngine';

const TIME_PRESETS = [
  { label: 'Bình Minh', hours: 6.25, icon: Sunrise },
  { label: 'Nắng Trưa', hours: 11.5, icon: Sun },
  { label: 'Hoàng Hôn', hours: 17.25, icon: Sunset },
  { label: 'Đêm Đom Đóm', hours: 19.75, icon: Moon },
] as const;

function formatHour(h: number): string {
  const whole = Math.floor(h);
  const mins = Math.round((h - whole) * 60);
  const hh = String(whole).padStart(2, '0');
  const mm = String(mins >= 60 ? 59 : mins).padStart(2, '0');
  return `${hh}:${mm}`;
}

export default function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<MekongWorldEngine | null>(null);

  const [telemetry, setTelemetry] = useState<HUDTelemetry>({
    mode: 'walk',
    nearBoat: false,
    zoneLabel: 'Bến Đò Sông Hậu',
    timeOfDay: 6.9,
    fps: 60,
    audioOn: false,
  });
  const [timeSlider, setTimeSlider] = useState(6.9);
  const [activeBookmark, setActiveBookmark] = useState(WORLD_BOOKMARKS[0].id);
  const [quality, setQuality] = useState<QualityPreset>('high');
  const [hudVisible, setHudVisible] = useState(true);
  const [showControlsHint, setShowControlsHint] = useState(true);

  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;

    const engine = new MekongWorldEngine(
      el,
      (data) => {
        setTelemetry(data);
        setTimeSlider(data.timeOfDay);
      },
      6.9,
    );
    engineRef.current = engine;

    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;
      if (e.key.toLowerCase() === 'h') {
        setHudVisible((v) => !v);
      }
    };
    window.addEventListener('keydown', onKey);

    const hintTimer = window.setTimeout(() => setShowControlsHint(false), 12000);

    return () => {
      window.clearTimeout(hintTimer);
      window.removeEventListener('keydown', onKey);
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  const handleTimeChange = (hours: number) => {
    setTimeSlider(hours);
    engineRef.current?.setTimeOfDay(hours);
  };

  const handleModeChange = (mode: TraversalMode) => {
    engineRef.current?.setMode(mode);
  };

  const handleQualityToggle = () => {
    const next: QualityPreset = quality === 'high' ? 'medium' : 'high';
    setQuality(next);
    engineRef.current?.setQuality(next);
  };

  const handleAudioToggle = () => {
    const on = engineRef.current?.toggleAudio() ?? false;
    setTelemetry((prev) => ({ ...prev, audioOn: on }));
  };

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-stone-950">
      {/* Full-Bleed 3D World Viewport */}
      <div
        ref={mountRef}
        className="h-full w-full cursor-grab active:cursor-grabbing"
      />

      {/* Minimal Photo-Mode Toggle when HUD is hidden */}
      {!hudVisible && (
        <button
          onClick={() => setHudVisible(true)}
          title="Hiện giao diện (H)"
          className="fixed right-4 top-4 z-30 flex items-center gap-2 rounded-full border border-white/15 bg-stone-950/60 px-3.5 py-2 text-xs font-medium text-stone-100 backdrop-blur-md transition hover:bg-stone-900/80"
        >
          <Eye className="h-3.5 w-3.5 text-amber-300" />
          <span>Hiện HUD (H)</span>
        </button>
      )}

      {hudVisible && (
        <>
          {/* Top-Left Title & Current Location */}
          <div className="pointer-events-none fixed left-4 top-4 z-20 flex flex-col gap-2">
            <div className="pointer-events-auto flex items-center gap-3 rounded-2xl border border-amber-200/15 bg-stone-950/65 px-4 py-2.5 shadow-xl backdrop-blur-md">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500/30 to-emerald-700/30 ring-1 ring-amber-300/30">
                <Compass className="h-5 w-5 text-amber-300" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="font-serif-vn text-base font-bold tracking-wide text-amber-50">
                    Sông Nước Cửu Long
                  </h1>
                  <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] font-medium text-emerald-300 ring-1 ring-emerald-400/25">
                    {telemetry.fps} FPS
                  </span>
                </div>
                <div className="mt-0.5 flex items-center gap-1.5 text-xs text-amber-200/85">
                  <MapPin className="h-3 w-3 shrink-0 text-amber-400" />
                  <span>{telemetry.zoneLabel}</span>
                </div>
              </div>
            </div>

            {showControlsHint && (
              <div className="pointer-events-auto max-w-xs rounded-xl border border-white/10 bg-stone-950/55 px-3.5 py-2 text-[11px] leading-relaxed text-stone-200/90 backdrop-blur-md">
                <span className="font-semibold text-amber-300">Khám phá tự do:</span> Kéo chuột xoay
                góc nhìn • <kbd className="rounded bg-white/10 px-1">WASD</kbd> di chuyển •{' '}
                <kbd className="rounded bg-white/10 px-1">Shift</kbd> chạy / chèo nhanh •{' '}
                <kbd className="rounded bg-white/10 px-1">B</kbd> xuồng •{' '}
                <kbd className="rounded bg-white/10 px-1">F</kbd> bay •{' '}
                <kbd className="rounded bg-white/10 px-1">H</kbd> ẩn HUD
              </div>
            )}
          </div>

          {/* Top-Right Mode, Audio, Quality & Hide Controls */}
          <div className="fixed right-4 top-4 z-20 flex flex-wrap items-center justify-end gap-2">
            {/* Traversal Mode Switch */}
            <div className="flex items-center rounded-full border border-white/15 bg-stone-950/65 p-1 backdrop-blur-md">
              <button
                onClick={() => handleModeChange('walk')}
                className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition ${
                  telemetry.mode === 'walk'
                    ? 'bg-amber-500/90 text-stone-950 shadow'
                    : 'text-stone-200 hover:bg-white/10'
                }`}
              >
                <Footprints className="h-3.5 w-3.5" />
                <span>Đi Bộ</span>
              </button>
              <button
                onClick={() => handleModeChange('boat')}
                className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition ${
                  telemetry.mode === 'boat'
                    ? 'bg-amber-500/90 text-stone-950 shadow'
                    : 'text-stone-200 hover:bg-white/10'
                }`}
              >
                <Anchor className="h-3.5 w-3.5" />
                <span>Chèo Xuồng (B)</span>
              </button>
              <button
                onClick={() => handleModeChange('fly')}
                className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition ${
                  telemetry.mode === 'fly'
                    ? 'bg-amber-500/90 text-stone-950 shadow'
                    : 'text-stone-200 hover:bg-white/10'
                }`}
              >
                <Feather className="h-3.5 w-3.5" />
                <span>Bay (F)</span>
              </button>
            </div>

            <button
              onClick={handleAudioToggle}
              title="Âm thanh sông nước"
              className={`flex items-center gap-1.5 rounded-full border px-3 py-2 text-xs font-medium backdrop-blur-md transition ${
                telemetry.audioOn
                  ? 'border-emerald-400/40 bg-emerald-950/60 text-emerald-200'
                  : 'border-white/15 bg-stone-950/65 text-stone-300 hover:bg-stone-900/80'
              }`}
            >
              {telemetry.audioOn ? (
                <Volume2 className="h-3.5 w-3.5 text-emerald-300" />
              ) : (
                <VolumeX className="h-3.5 w-3.5" />
              )}
              <span className="hidden sm:inline">
                {telemetry.audioOn ? 'Âm Thanh: Bật' : 'Âm Thanh'}
              </span>
            </button>

            <button
              onClick={handleQualityToggle}
              title="Chuyển chất lượng đồ họa"
              className="flex items-center gap-1.5 rounded-full border border-white/15 bg-stone-950/65 px-3 py-2 text-xs font-medium text-stone-200 backdrop-blur-md transition hover:bg-stone-900/80"
            >
              <Sparkles className="h-3.5 w-3.5 text-amber-300" />
              <span>{quality === 'high' ? 'Đồ họa: Cao' : 'Đồ họa: Nhẹ'}</span>
            </button>

            <button
              onClick={() => setHudVisible(false)}
              title="Ẩn giao diện (H)"
              className="flex items-center gap-1.5 rounded-full border border-white/15 bg-stone-950/65 px-3 py-2 text-xs font-medium text-stone-200 backdrop-blur-md transition hover:bg-stone-900/80"
            >
              <EyeOff className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* Boat Boarding Context Prompt */}
          {telemetry.mode === 'walk' && telemetry.nearBoat && (
            <div className="fixed bottom-32 left-1/2 z-20 -translate-x-1/2">
              <button
                onClick={() => engineRef.current?.toggleBoatMode()}
                className="flex items-center gap-2 rounded-full border border-amber-300/40 bg-amber-950/80 px-4 py-2 text-xs font-medium text-amber-100 shadow-lg backdrop-blur-md transition hover:bg-amber-900/90"
              >
                <Anchor className="h-3.5 w-3.5 text-amber-300" />
                <span>Nhấn [B] để bước xuống Xuồng Ba Lá dạo sông</span>
              </button>
            </div>
          )}

          {/* Bottom Dock: Location Bookmarks + Time-of-Day Atmospheric Dial */}
          <div className="fixed bottom-4 left-1/2 z-20 flex w-[95vw] max-w-4xl -translate-x-1/2 flex-col gap-2 rounded-2xl border border-white/15 bg-stone-950/65 p-3 shadow-2xl backdrop-blur-md">
            {/* Location Quick-Travel Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
              {WORLD_BOOKMARKS.map((bm) => {
                const isActive = activeBookmark === bm.id;
                return (
                  <button
                    key={bm.id}
                    onClick={() => {
                      setActiveBookmark(bm.id);
                      engineRef.current?.applyBookmark(bm);
                    }}
                    title={bm.subtitle}
                    className={`shrink-0 rounded-xl px-3 py-1.5 text-left transition ${
                      isActive
                        ? 'bg-amber-500/90 text-stone-950 shadow-sm'
                        : 'bg-white/5 text-stone-200 hover:bg-white/12'
                    }`}
                  >
                    <div className="text-xs font-semibold leading-tight">{bm.name}</div>
                  </button>
                );
              })}
            </div>

            {/* Atmospheric Time-of-Day Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/10 pt-2">
              <div className="flex items-center gap-1.5">
                {TIME_PRESETS.map((tp) => {
                  const Icon = tp.icon;
                  const active = Math.abs(timeSlider - tp.hours) < 0.7;
                  return (
                    <button
                      key={tp.label}
                      onClick={() => handleTimeChange(tp.hours)}
                      className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-[11px] font-medium transition ${
                        active
                          ? 'bg-amber-400/20 text-amber-200 ring-1 ring-amber-400/40'
                          : 'text-stone-300 hover:bg-white/10'
                      }`}
                    >
                      <Icon className="h-3 w-3" />
                      <span>{tp.label}</span>
                    </button>
                  );
                })}
              </div>

              <div className="flex min-w-[200px] flex-1 items-center gap-2.5">
                <span className="w-11 text-right font-mono text-xs font-medium text-amber-200">
                  {formatHour(timeSlider)}
                </span>
                <input
                  type="range"
                  min={5.75}
                  max={19.75}
                  step={0.05}
                  value={timeSlider}
                  onChange={(e) => handleTimeChange(parseFloat(e.target.value))}
                  aria-label="Thời gian trong ngày"
                  className="mekong-slider w-full"
                />
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
