"""
Tải bộ PBR 1K (CC0) từ Poly Haven cho các khóa vật liệu trong src/world/materials.ts,
rồi tiền xử lý albedo để màu sơn do khóa vật liệu quyết định (giống quy trình ghi trong README):
  - giảm bão hòa, nén tương phản, đưa độ sáng trung bình về mục tiêu.
Normal dùng bản OpenGL (nor_gl), roughness giữ nguyên.
Kết quả: src/assets/tex/<khóa>_d.jpg | _n.jpg | _r.jpg

Chạy: python3 tools/fetch_polyhaven.py   (cần pillow, numpy)
"""
import json, os, sys, urllib.request
import numpy as np
from PIL import Image
import io

UA = "Mozilla/5.0 (X11; Linux x86_64) HueWorld/1.0"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "src", "assets", "tex")

# khóa (materials.ts / textures.ts)  ->  (asset Poly Haven, độ sáng trung bình mục tiêu, giữ bão hòa, nén tương phản)
SETS = {
    "plx":   ("beige_wall_001",        0.80, 0.50, 0.60),  # vữa tường ngoài
    "pli":   ("beige_wall_002",        0.80, 0.50, 0.60),  # vữa tường trong
    "tile":  ("floor_tiles_06",        0.78, 0.40, 0.70),  # gạch lát sàn
    "paver": ("concrete_pavers",       0.62, 0.50, 0.70),  # gạch bê tông vỉa hè
    "stone": ("granite_wall",          0.62, 0.40, 0.60),  # ốp đá
    "brick": ("brick_wall_02",         0.55, 0.50, 0.60),  # gạch đỏ
    "conc":  ("concrete_wall_008",     0.68, 0.50, 0.60),  # bê tông
    "roof":  ("clay_roof_tiles_02",    0.50, 0.50, 0.70),  # ngói đất nung
    "asph":  ("asphalt_02",            0.42, 0.40, 0.60),  # nhựa đường
    "wood":  ("brown_planks_05",       0.50, 0.40, 0.70),  # ván gỗ
    "woodF": ("oak_veneer_01",         0.62, 0.30, 0.60),  # gỗ veneer nội thất
    "dirt":  ("brown_mud_02",          0.50, 0.40, 0.60),  # đất bùn
    "cloth": ("rough_linen",           0.80, 0.30, 0.50),  # vải lanh
}


def http_get(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=120) as r:
        return r.read()


def normalise_albedo(raw: bytes, target: float, keep_sat: float, contrast: float) -> bytes:
    im = Image.open(io.BytesIO(raw)).convert("RGB")
    a = np.asarray(im).astype(np.float32) / 255.0
    lum = (0.2126 * a[..., 0] + 0.7152 * a[..., 1] + 0.0722 * a[..., 2])[..., None]
    a = lum + (a - lum) * keep_sat                        # bão hòa
    m = float(a.mean())
    a = a * (target / max(m, 1e-4))                       # độ sáng trung bình
    a = target + (a - target) * contrast                  # nén tương phản quanh trung bình
    a = np.clip(a, 0.02, 1.0)
    out = Image.fromarray((a * 255.0 + 0.5).astype(np.uint8))
    buf = io.BytesIO(); out.save(buf, "JPEG", quality=88, optimize=True)
    return buf.getvalue()


def main() -> int:
    os.makedirs(OUT, exist_ok=True)
    ok, bad = [], []
    for key, (asset, target, sat, con) in SETS.items():
        try:
            meta = json.loads(http_get(f"https://api.polyhaven.com/files/{asset}"))
            diff_url = meta["Diffuse"]["1k"]["jpg"]["url"]
            nor_url = meta["nor_gl"]["1k"]["jpg"]["url"]
            rough_url = meta["Rough"]["1k"]["jpg"]["url"]
            d = normalise_albedo(http_get(diff_url), target, sat, con)
            n = http_get(nor_url)
            r = http_get(rough_url)
            # đảm bảo roughness là ảnh xám 1 kênh nhỏ gọn
            rim = Image.open(io.BytesIO(r)).convert("L"); buf = io.BytesIO(); rim.save(buf, "JPEG", quality=88); r = buf.getvalue()
            nim = Image.open(io.BytesIO(n)).convert("RGB"); buf = io.BytesIO(); nim.save(buf, "JPEG", quality=92); n = buf.getvalue()
            for suffix, data in (("_d", d), ("_n", n), ("_r", r)):
                with open(os.path.join(OUT, key + suffix + ".jpg"), "wb") as f:
                    f.write(data)
            ok.append(f"{key}<-{asset} ({len(d)//1024}K/{len(n)//1024}K/{len(r)//1024}K)")
            print("ok", ok[-1], flush=True)
        except Exception as ex:  # giữ đường dự phòng procedural cho khóa lỗi
            bad.append(f"{key}: {ex}")
            print("FAIL", key, ex, file=sys.stderr, flush=True)
    print(f"\n{len(ok)} sets ok, {len(bad)} failed")
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
